lubi(default_p01, default_a01).
lubi(default_p01, default_a04).
lubi(default_p01, default_a05).
lubi(default_p01, default_a08).
lubi(default_p01, default_a10).
lubi(default_p01, default_a11).
lubi(default_p02, default_a03).
lubi(default_p02, default_a04).
lubi(default_p02, default_a06).
lubi(default_p02, default_a08).
lubi(default_p02, default_a09).
lubi(default_p02, default_a11).
lubi(default_p03, default_a01).
lubi(default_p03, default_a05).
lubi(default_p03, default_a06).
lubi(default_p03, default_a08).
lubi(default_p03, default_a11).
lubi(default_p03, default_a12).
lubi(default_p04, default_a01).
lubi(default_p04, default_a03).
lubi(default_p04, default_a06).
lubi(default_p04, default_a07).
lubi(default_p04, default_a08).
lubi(default_p04, default_a12).
lubi(default_p05, default_a01).
lubi(default_p05, default_a03).
lubi(default_p05, default_a05).
lubi(default_p05, default_a08).
lubi(default_p05, default_a09).
lubi(default_p05, default_a12).
lubi(default_p06, default_a04).
lubi(default_p06, default_a07).
lubi(default_p06, default_a08).
lubi(default_p06, default_a09).
lubi(default_p06, default_a10).
lubi(default_p06, default_a12).
lubi(default_p07, default_a02).
lubi(default_p07, default_a03).
lubi(default_p07, default_a04).
lubi(default_p07, default_a05).
lubi(default_p07, default_a09).
lubi(default_p07, default_a11).
lubi(default_p08, default_a02).
lubi(default_p08, default_a04).
lubi(default_p08, default_a07).
lubi(default_p08, default_a08).
lubi(default_p08, default_a09).
lubi(default_p08, default_a11).
lubi(default_p09, default_a01).
lubi(default_p09, default_a02).
lubi(default_p09, default_a04).
lubi(default_p09, default_a07).
lubi(default_p09, default_a08).
lubi(default_p09, default_a09).
lubi(default_p10, default_a02).
lubi(default_p10, default_a03).
lubi(default_p10, default_a07).
lubi(default_p10, default_a10).
lubi(default_p10, default_a11).
lubi(default_p10, default_a12).
lubi(default_p11, default_a02).
lubi(default_p11, default_a03).
lubi(default_p11, default_a04).
lubi(default_p11, default_a05).
lubi(default_p11, default_a06).
lubi(default_p11, default_a09).
lubi(default_p12, default_a04).
lubi(default_p12, default_a05).
lubi(default_p12, default_a08).
lubi(default_p12, default_a10).
lubi(default_p12, default_a11).
lubi(default_p12, default_a12).
lubi(default_p13, default_a01).
lubi(default_p13, default_a02).
lubi(default_p13, default_a03).
lubi(default_p13, default_a07).
lubi(default_p13, default_a09).
lubi(default_p13, default_a11).
lubi(default_p14, default_a02).
lubi(default_p14, default_a03).
lubi(default_p14, default_a05).
lubi(default_p14, default_a07).
lubi(default_p14, default_a08).
lubi(default_p14, default_a10).
lubi(default_p15, default_a01).
lubi(default_p15, default_a03).
lubi(default_p15, default_a04).
lubi(default_p15, default_a05).
lubi(default_p15, default_a08).
lubi(default_p15, default_a09).
lubi(default_p16, default_a01).
lubi(default_p16, default_a07).
lubi(default_p16, default_a08).
lubi(default_p16, default_a09).
lubi(default_p16, default_a10).
lubi(default_p16, default_a11).
lubi(default_p17, default_a02).
lubi(default_p17, default_a03).
lubi(default_p17, default_a05).
lubi(default_p17, default_a06).
lubi(default_p17, default_a08).
lubi(default_p17, default_a11).
lubi(default_p18, default_a02).
lubi(default_p18, default_a03).
lubi(default_p18, default_a04).
lubi(default_p18, default_a05).
lubi(default_p18, default_a06).
lubi(default_p18, default_a12).
lubi(default_p19, default_a06).
lubi(default_p19, default_a07).
lubi(default_p19, default_a08).
lubi(default_p19, default_a09).
lubi(default_p19, default_a11).
lubi(default_p19, default_a12).
lubi(default_p20, default_a02).
lubi(default_p20, default_a04).
lubi(default_p20, default_a07).
lubi(default_p20, default_a10).
lubi(default_p20, default_a11).
lubi(default_p20, default_a12).
capuje(default_k01, default_a02, 3).
capuje(default_k01, default_a05, 1).
capuje(default_k01, default_a07, 2).
capuje(default_k01, default_a08, 3).
capuje(default_k01, default_a11, 3).
capuje(default_k01, default_a12, 3).
capuje(default_k02, default_a01, 2).
capuje(default_k02, default_a03, 2).
capuje(default_k02, default_a06, 4).
capuje(default_k02, default_a07, 2).
capuje(default_k02, default_a08, 3).
capuje(default_k02, default_a09, 2).
capuje(default_k03, default_a01, 2).
capuje(default_k03, default_a02, 3).
capuje(default_k03, default_a03, 2).
capuje(default_k03, default_a06, 4).
capuje(default_k03, default_a07, 2).
capuje(default_k03, default_a10, 3).
capuje(default_k04, default_a01, 2).
capuje(default_k04, default_a02, 3).
capuje(default_k04, default_a03, 2).
capuje(default_k04, default_a06, 4).
capuje(default_k04, default_a08, 3).
capuje(default_k04, default_a12, 3).
capuje(default_k05, default_a01, 2).
capuje(default_k05, default_a03, 2).
capuje(default_k05, default_a08, 3).
capuje(default_k05, default_a09, 2).
capuje(default_k05, default_a10, 3).
capuje(default_k05, default_a11, 3).
capuje(default_k06, default_a01, 2).
capuje(default_k06, default_a04, 4).
capuje(default_k06, default_a06, 4).
capuje(default_k06, default_a07, 2).
capuje(default_k06, default_a09, 2).
capuje(default_k06, default_a11, 3).
capuje(default_k07, default_a03, 2).
capuje(default_k07, default_a04, 4).
capuje(default_k07, default_a06, 4).
capuje(default_k07, default_a07, 2).
capuje(default_k07, default_a10, 3).
capuje(default_k07, default_a11, 3).
capuje(default_k08, default_a02, 3).
capuje(default_k08, default_a04, 4).
capuje(default_k08, default_a08, 3).
capuje(default_k08, default_a09, 2).
capuje(default_k08, default_a10, 3).
capuje(default_k08, default_a12, 3).
capuje(default_k09, default_a01, 2).
capuje(default_k09, default_a02, 3).
capuje(default_k09, default_a08, 3).
capuje(default_k09, default_a09, 2).
capuje(default_k09, default_a10, 3).
capuje(default_k09, default_a11, 3).
capuje(default_k10, default_a01, 2).
capuje(default_k10, default_a04, 4).
capuje(default_k10, default_a05, 1).
capuje(default_k10, default_a06, 4).
capuje(default_k10, default_a07, 2).
capuje(default_k10, default_a11, 3).
capuje(d_k1, default_a01, 2).
navstivil(1, default_p02, default_k01, 46.207237).
navstivil(2, default_p02, default_k01, 46.207237).
navstivil(3, default_p02, default_k01, 46.207237).
navstivil(4, default_p02, default_k02, 13.207283).
navstivil(5, default_p02, default_k02, 13.207283).
navstivil(6, default_p02, default_k02, 13.207283).
navstivil(7, default_p02, default_k03, 62.207317).
navstivil(8, default_p02, default_k03, 62.207317).
navstivil(9, default_p02, default_k03, 62.207317).
navstivil(10, default_p02, default_k04, 14.207351).
navstivil(11, default_p02, default_k04, 14.207351).
navstivil(12, default_p02, default_k04, 14.207351).
navstivil(13, default_p02, default_k05, 75.207382).
navstivil(14, default_p02, default_k05, 75.207382).
navstivil(15, default_p02, default_k05, 75.207382).
navstivil(16, default_p02, default_k06, 32.207412).
navstivil(17, default_p02, default_k06, 32.207412).
navstivil(18, default_p02, default_k06, 32.207412).
navstivil(19, default_p02, default_k07, 14.207443).
navstivil(20, default_p02, default_k07, 14.207443).
navstivil(21, default_p02, default_k07, 14.207443).
navstivil(22, default_p02, default_k08, 6.207472).
navstivil(23, default_p02, default_k08, 6.207472).
navstivil(24, default_p02, default_k08, 6.207472).
navstivil(25, default_p02, default_k09, 4.207502).
navstivil(26, default_p02, default_k09, 4.207502).
navstivil(27, default_p02, default_k09, 4.207502).
navstivil(28, default_p02, default_k10, 63.207532).
navstivil(29, default_p02, default_k10, 63.207532).
navstivil(30, default_p02, default_k10, 63.207532).
navstivil(31, default_p03, default_k01, 8.207564).
navstivil(32, default_p03, default_k01, 8.207564).
navstivil(33, default_p03, default_k01, 8.207564).
navstivil(34, default_p03, default_k01, 4.207592).
navstivil(35, default_p03, default_k01, 4.207592).
navstivil(36, default_p03, default_k01, 4.207592).
navstivil(37, default_p03, default_k02, 80.207623).
navstivil(38, default_p03, default_k02, 80.207623).
navstivil(39, default_p03, default_k02, 80.207623).
navstivil(40, default_p03, default_k02, 5.207652).
navstivil(41, default_p03, default_k02, 5.207652).
navstivil(42, default_p03, default_k02, 5.207652).
navstivil(43, default_p03, default_k03, 46.207681).
navstivil(44, default_p03, default_k03, 46.207681).
navstivil(45, default_p03, default_k03, 46.207681).
navstivil(46, default_p03, default_k03, 81.20771).
navstivil(47, default_p03, default_k03, 81.20771).
navstivil(48, default_p03, default_k03, 81.20771).
navstivil(49, default_p03, default_k04, 41.207741).
navstivil(50, default_p03, default_k04, 41.207741).
navstivil(51, default_p03, default_k04, 41.207741).
navstivil(52, default_p03, default_k04, 51.20777).
navstivil(53, default_p03, default_k04, 51.20777).
navstivil(54, default_p03, default_k04, 51.20777).
navstivil(55, default_p03, default_k05, 88.207798).
navstivil(56, default_p03, default_k05, 88.207798).
navstivil(57, default_p03, default_k05, 88.207798).
navstivil(58, default_p03, default_k05, 60.207827).
navstivil(59, default_p03, default_k05, 60.207827).
navstivil(60, default_p03, default_k05, 60.207827).
navstivil(61, default_p03, default_k06, 76.207858).
navstivil(62, default_p03, default_k06, 76.207858).
navstivil(63, default_p03, default_k06, 76.207858).
navstivil(64, default_p03, default_k06, 38.207886).
navstivil(65, default_p03, default_k06, 38.207886).
navstivil(66, default_p03, default_k06, 38.207886).
navstivil(67, default_p03, default_k07, 32.207915).
navstivil(68, default_p03, default_k07, 32.207915).
navstivil(69, default_p03, default_k07, 32.207915).
navstivil(70, default_p03, default_k07, 61.207945).
navstivil(71, default_p03, default_k07, 61.207945).
navstivil(72, default_p03, default_k07, 61.207945).
navstivil(73, default_p03, default_k08, 23.207976).
navstivil(74, default_p03, default_k08, 23.207976).
navstivil(75, default_p03, default_k08, 23.207976).
navstivil(76, default_p03, default_k08, 92.208005).
navstivil(77, default_p03, default_k08, 92.208005).
navstivil(78, default_p03, default_k08, 92.208005).
navstivil(79, default_p03, default_k09, 55.208078).
navstivil(80, default_p03, default_k09, 55.208078).
navstivil(81, default_p03, default_k09, 55.208078).
navstivil(82, default_p03, default_k09, 55.208155).
navstivil(83, default_p03, default_k09, 55.208155).
navstivil(84, default_p03, default_k09, 55.208155).
navstivil(85, default_p03, default_k10, 38.208184).
navstivil(86, default_p03, default_k10, 38.208184).
navstivil(87, default_p03, default_k10, 38.208184).
navstivil(88, default_p03, default_k10, 73.208216).
navstivil(89, default_p03, default_k10, 73.208216).
navstivil(90, default_p03, default_k10, 73.208216).
navstivil(91, default_p04, default_k01, 14.208274).
navstivil(92, default_p04, default_k01, 14.208274).
navstivil(93, default_p04, default_k01, 14.208274).
navstivil(94, default_p04, default_k01, 35.208329).
navstivil(95, default_p04, default_k01, 35.208329).
navstivil(96, default_p04, default_k01, 35.208329).
navstivil(97, default_p04, default_k01, 42.208387).
navstivil(98, default_p04, default_k01, 42.208387).
navstivil(99, default_p04, default_k01, 42.208387).
navstivil(100, default_p04, default_k02, 32.208426).
navstivil(101, default_p04, default_k02, 32.208426).
navstivil(102, default_p04, default_k02, 32.208426).
navstivil(103, default_p04, default_k02, 11.208456).
navstivil(104, default_p04, default_k02, 11.208456).
navstivil(105, default_p04, default_k02, 11.208456).
navstivil(106, default_p04, default_k02, 41.208485).
navstivil(107, default_p04, default_k02, 41.208485).
navstivil(108, default_p04, default_k02, 41.208485).
navstivil(109, default_p04, default_k03, 58.208515).
navstivil(110, default_p04, default_k03, 58.208515).
navstivil(111, default_p04, default_k03, 58.208515).
navstivil(112, default_p04, default_k03, 56.208548).
navstivil(113, default_p04, default_k03, 56.208548).
navstivil(114, default_p04, default_k03, 56.208548).
navstivil(115, default_p04, default_k03, 14.2086).
navstivil(116, default_p04, default_k03, 14.2086).
navstivil(117, default_p04, default_k03, 14.2086).
navstivil(118, default_p04, default_k04, 97.208653).
navstivil(119, default_p04, default_k04, 97.208653).
navstivil(120, default_p04, default_k04, 97.208653).
navstivil(121, default_p04, default_k04, 74.208708).
navstivil(122, default_p04, default_k04, 74.208708).
navstivil(123, default_p04, default_k04, 74.208708).
navstivil(124, default_p04, default_k04, 81.208762).
navstivil(125, default_p04, default_k04, 81.208762).
navstivil(126, default_p04, default_k04, 81.208762).
navstivil(127, default_p04, default_k05, 7.208816).
navstivil(128, default_p04, default_k05, 7.208816).
navstivil(129, default_p04, default_k05, 7.208816).
navstivil(130, default_p04, default_k05, 38.208874).
navstivil(131, default_p04, default_k05, 38.208874).
navstivil(132, default_p04, default_k05, 38.208874).
navstivil(133, default_p04, default_k05, 8.20893).
navstivil(134, default_p04, default_k05, 8.20893).
navstivil(135, default_p04, default_k05, 8.20893).
navstivil(136, default_p04, default_k06, 32.20898).
navstivil(137, default_p04, default_k06, 32.20898).
navstivil(138, default_p04, default_k06, 32.20898).
navstivil(139, default_p04, default_k06, 90.20901).
navstivil(140, default_p04, default_k06, 90.20901).
navstivil(141, default_p04, default_k06, 90.20901).
navstivil(142, default_p04, default_k06, 83.209042).
navstivil(143, default_p04, default_k06, 83.209042).
navstivil(144, default_p04, default_k06, 83.209042).
navstivil(145, default_p04, default_k07, 26.20907).
navstivil(146, default_p04, default_k07, 26.20907).
navstivil(147, default_p04, default_k07, 26.20907).
navstivil(148, default_p04, default_k07, 77.209099).
navstivil(149, default_p04, default_k07, 77.209099).
navstivil(150, default_p04, default_k07, 77.209099).
navstivil(151, default_p04, default_k07, 56.20913).
navstivil(152, default_p04, default_k07, 56.20913).
navstivil(153, default_p04, default_k07, 56.20913).
navstivil(154, default_p04, default_k08, 90.209162).
navstivil(155, default_p04, default_k08, 90.209162).
navstivil(156, default_p04, default_k08, 90.209162).
navstivil(157, default_p04, default_k08, 98.209193).
navstivil(158, default_p04, default_k08, 98.209193).
navstivil(159, default_p04, default_k08, 98.209193).
navstivil(160, default_p04, default_k08, 85.209228).
navstivil(161, default_p04, default_k08, 85.209228).
navstivil(162, default_p04, default_k08, 85.209228).
navstivil(163, default_p04, default_k09, 92.209283).
navstivil(164, default_p04, default_k09, 92.209283).
navstivil(165, default_p04, default_k09, 92.209283).
navstivil(166, default_p04, default_k09, 56.209338).
navstivil(167, default_p04, default_k09, 56.209338).
navstivil(168, default_p04, default_k09, 56.209338).
navstivil(169, default_p04, default_k09, 77.20938).
navstivil(170, default_p04, default_k09, 77.20938).
navstivil(171, default_p04, default_k09, 77.20938).
navstivil(172, default_p04, default_k10, 35.209413).
navstivil(173, default_p04, default_k10, 35.209413).
navstivil(174, default_p04, default_k10, 35.209413).
navstivil(175, default_p04, default_k10, 12.209463).
navstivil(176, default_p04, default_k10, 12.209463).
navstivil(177, default_p04, default_k10, 12.209463).
navstivil(178, default_p04, default_k10, 33.209522).
navstivil(179, default_p04, default_k10, 33.209522).
navstivil(180, default_p04, default_k10, 33.209522).
navstivil(181, default_p05, default_k01, 18.209578).
navstivil(182, default_p05, default_k01, 18.209578).
navstivil(183, default_p05, default_k01, 18.209578).
navstivil(184, default_p05, default_k01, 15.209637).
navstivil(185, default_p05, default_k01, 15.209637).
navstivil(186, default_p05, default_k01, 15.209637).
navstivil(187, default_p05, default_k01, 78.209673).
navstivil(188, default_p05, default_k01, 78.209673).
navstivil(189, default_p05, default_k01, 78.209673).
navstivil(190, default_p05, default_k01, 89.209702).
navstivil(191, default_p05, default_k01, 89.209702).
navstivil(192, default_p05, default_k01, 89.209702).
navstivil(193, default_p05, default_k02, 7.209732).
navstivil(194, default_p05, default_k02, 7.209732).
navstivil(195, default_p05, default_k02, 7.209732).
navstivil(196, default_p05, default_k02, 52.209762).
navstivil(197, default_p05, default_k02, 52.209762).
navstivil(198, default_p05, default_k02, 52.209762).
navstivil(199, default_p05, default_k02, 41.209792).
navstivil(200, default_p05, default_k02, 41.209792).
navstivil(201, default_p05, default_k02, 41.209792).
navstivil(202, default_p05, default_k02, 39.209823).
navstivil(203, default_p05, default_k02, 39.209823).
navstivil(204, default_p05, default_k02, 39.209823).
navstivil(205, default_p05, default_k03, 95.209854).
navstivil(206, default_p05, default_k03, 95.209854).
navstivil(207, default_p05, default_k03, 95.209854).
navstivil(208, default_p05, default_k03, 56.209885).
navstivil(209, default_p05, default_k03, 56.209885).
navstivil(210, default_p05, default_k03, 56.209885).
navstivil(211, default_p05, default_k03, 42.209913).
navstivil(212, default_p05, default_k03, 42.209913).
navstivil(213, default_p05, default_k03, 42.209913).
navstivil(214, default_p05, default_k03, 97.209943).
navstivil(215, default_p05, default_k03, 97.209943).
navstivil(216, default_p05, default_k03, 97.209943).
navstivil(217, default_p05, default_k04, 56.209972).
navstivil(218, default_p05, default_k04, 56.209972).
navstivil(219, default_p05, default_k04, 56.209972).
navstivil(220, default_p05, default_k04, 46.210002).
navstivil(221, default_p05, default_k04, 46.210002).
navstivil(222, default_p05, default_k04, 46.210002).
navstivil(223, default_p05, default_k04, 54.210032).
navstivil(224, default_p05, default_k04, 54.210032).
navstivil(225, default_p05, default_k04, 54.210032).
navstivil(226, default_p05, default_k04, 95.210063).
navstivil(227, default_p05, default_k04, 95.210063).
navstivil(228, default_p05, default_k04, 95.210063).
navstivil(229, default_p05, default_k05, 47.210097).
navstivil(230, default_p05, default_k05, 47.210097).
navstivil(231, default_p05, default_k05, 47.210097).
navstivil(232, default_p05, default_k05, 54.210127).
navstivil(233, default_p05, default_k05, 54.210127).
navstivil(234, default_p05, default_k05, 54.210127).
navstivil(235, default_p05, default_k05, 55.210158).
navstivil(236, default_p05, default_k05, 55.210158).
navstivil(237, default_p05, default_k05, 55.210158).
navstivil(238, default_p05, default_k05, 54.210186).
navstivil(239, default_p05, default_k05, 54.210186).
navstivil(240, default_p05, default_k05, 54.210186).
navstivil(241, default_p05, default_k06, 63.210216).
navstivil(242, default_p05, default_k06, 63.210216).
navstivil(243, default_p05, default_k06, 63.210216).
navstivil(244, default_p05, default_k06, 36.210244).
navstivil(245, default_p05, default_k06, 36.210244).
navstivil(246, default_p05, default_k06, 36.210244).
navstivil(247, default_p05, default_k06, 18.210274).
navstivil(248, default_p05, default_k06, 18.210274).
navstivil(249, default_p05, default_k06, 18.210274).
navstivil(250, default_p05, default_k06, 78.210305).
navstivil(251, default_p05, default_k06, 78.210305).
navstivil(252, default_p05, default_k06, 78.210305).
navstivil(253, default_p05, default_k07, 91.210335).
navstivil(254, default_p05, default_k07, 91.210335).
navstivil(255, default_p05, default_k07, 91.210335).
navstivil(256, default_p05, default_k07, 54.210364).
navstivil(257, default_p05, default_k07, 54.210364).
navstivil(258, default_p05, default_k07, 54.210364).
navstivil(259, default_p05, default_k07, 34.210394).
navstivil(260, default_p05, default_k07, 34.210394).
navstivil(261, default_p05, default_k07, 34.210394).
navstivil(262, default_p05, default_k07, 52.210422).
navstivil(263, default_p05, default_k07, 52.210422).
navstivil(264, default_p05, default_k07, 52.210422).
navstivil(265, default_p05, default_k08, 90.210452).
navstivil(266, default_p05, default_k08, 90.210452).
navstivil(267, default_p05, default_k08, 90.210452).
navstivil(268, default_p05, default_k08, 30.210481).
navstivil(269, default_p05, default_k08, 30.210481).
navstivil(270, default_p05, default_k08, 30.210481).
navstivil(271, default_p05, default_k08, 60.21051).
navstivil(272, default_p05, default_k08, 60.21051).
navstivil(273, default_p05, default_k08, 60.21051).
navstivil(274, default_p05, default_k08, 28.210539).
navstivil(275, default_p05, default_k08, 28.210539).
navstivil(276, default_p05, default_k08, 28.210539).
navstivil(277, default_p05, default_k09, 17.210573).
navstivil(278, default_p05, default_k09, 17.210573).
navstivil(279, default_p05, default_k09, 17.210573).
navstivil(280, default_p05, default_k09, 51.210602).
navstivil(281, default_p05, default_k09, 51.210602).
navstivil(282, default_p05, default_k09, 51.210602).
navstivil(283, default_p05, default_k09, 75.210631).
navstivil(284, default_p05, default_k09, 75.210631).
navstivil(285, default_p05, default_k09, 75.210631).
navstivil(286, default_p05, default_k09, 45.21066).
navstivil(287, default_p05, default_k09, 45.21066).
navstivil(288, default_p05, default_k09, 45.21066).
navstivil(289, default_p05, default_k10, 96.210689).
navstivil(290, default_p05, default_k10, 96.210689).
navstivil(291, default_p05, default_k10, 96.210689).
navstivil(292, default_p05, default_k10, 65.210717).
navstivil(293, default_p05, default_k10, 65.210717).
navstivil(294, default_p05, default_k10, 65.210717).
navstivil(295, default_p05, default_k10, 29.210748).
navstivil(296, default_p05, default_k10, 29.210748).
navstivil(297, default_p05, default_k10, 29.210748).
navstivil(298, default_p05, default_k10, 19.210776).
navstivil(299, default_p05, default_k10, 19.210776).
navstivil(300, default_p05, default_k10, 19.210776).
navstivil(301, default_p06, default_k01, 63.210808).
navstivil(302, default_p06, default_k01, 63.210808).
navstivil(303, default_p06, default_k01, 63.210808).
navstivil(304, default_p06, default_k01, 4.210837).
navstivil(305, default_p06, default_k01, 4.210837).
navstivil(306, default_p06, default_k01, 4.210837).
navstivil(307, default_p06, default_k01, 31.210866).
navstivil(308, default_p06, default_k01, 31.210866).
navstivil(309, default_p06, default_k01, 31.210866).
navstivil(310, default_p06, default_k01, 45.210895).
navstivil(311, default_p06, default_k01, 45.210895).
navstivil(312, default_p06, default_k01, 45.210895).
navstivil(313, default_p06, default_k01, 67.210925).
navstivil(314, default_p06, default_k01, 67.210925).
navstivil(315, default_p06, default_k01, 67.210925).
navstivil(316, default_p06, default_k02, 77.210954).
navstivil(317, default_p06, default_k02, 77.210954).
navstivil(318, default_p06, default_k02, 77.210954).
navstivil(319, default_p06, default_k02, 7.210984).
navstivil(320, default_p06, default_k02, 7.210984).
navstivil(321, default_p06, default_k02, 7.210984).
navstivil(322, default_p06, default_k02, 45.211013).
navstivil(323, default_p06, default_k02, 45.211013).
navstivil(324, default_p06, default_k02, 45.211013).
navstivil(325, default_p06, default_k02, 46.211042).
navstivil(326, default_p06, default_k02, 46.211042).
navstivil(327, default_p06, default_k02, 46.211042).
navstivil(328, default_p06, default_k02, 52.211073).
navstivil(329, default_p06, default_k02, 52.211073).
navstivil(330, default_p06, default_k02, 52.211073).
navstivil(331, default_p06, default_k03, 14.211105).
navstivil(332, default_p06, default_k03, 14.211105).
navstivil(333, default_p06, default_k03, 14.211105).
navstivil(334, default_p06, default_k03, 94.211133).
navstivil(335, default_p06, default_k03, 94.211133).
navstivil(336, default_p06, default_k03, 94.211133).
navstivil(337, default_p06, default_k03, 92.211162).
navstivil(338, default_p06, default_k03, 92.211162).
navstivil(339, default_p06, default_k03, 92.211162).
navstivil(340, default_p06, default_k03, 50.211192).
navstivil(341, default_p06, default_k03, 50.211192).
navstivil(342, default_p06, default_k03, 50.211192).
navstivil(343, default_p06, default_k03, 31.21122).
navstivil(344, default_p06, default_k03, 31.21122).
navstivil(345, default_p06, default_k03, 31.21122).
navstivil(346, default_p06, default_k04, 30.21125).
navstivil(347, default_p06, default_k04, 30.21125).
navstivil(348, default_p06, default_k04, 30.21125).
navstivil(349, default_p06, default_k04, 91.21128).
navstivil(350, default_p06, default_k04, 91.21128).
navstivil(351, default_p06, default_k04, 91.21128).
navstivil(352, default_p06, default_k04, 25.211307).
navstivil(353, default_p06, default_k04, 25.211307).
navstivil(354, default_p06, default_k04, 25.211307).
navstivil(355, default_p06, default_k04, 63.211335).
navstivil(356, default_p06, default_k04, 63.211335).
navstivil(357, default_p06, default_k04, 63.211335).
navstivil(358, default_p06, default_k04, 16.211363).
navstivil(359, default_p06, default_k04, 16.211363).
navstivil(360, default_p06, default_k04, 16.211363).
navstivil(361, default_p06, default_k05, 47.211396).
navstivil(362, default_p06, default_k05, 47.211396).
navstivil(363, default_p06, default_k05, 47.211396).
navstivil(364, default_p06, default_k05, 38.211427).
navstivil(365, default_p06, default_k05, 38.211427).
navstivil(366, default_p06, default_k05, 38.211427).
navstivil(367, default_p06, default_k05, 5.211459).
navstivil(368, default_p06, default_k05, 5.211459).
navstivil(369, default_p06, default_k05, 5.211459).
navstivil(370, default_p06, default_k05, 58.21149).
navstivil(371, default_p06, default_k05, 58.21149).
navstivil(372, default_p06, default_k05, 58.21149).
navstivil(373, default_p06, default_k05, 84.211518).
navstivil(374, default_p06, default_k05, 84.211518).
navstivil(375, default_p06, default_k05, 84.211518).
navstivil(376, default_p06, default_k06, 50.211547).
navstivil(377, default_p06, default_k06, 50.211547).
navstivil(378, default_p06, default_k06, 50.211547).
navstivil(379, default_p06, default_k06, 4.211577).
navstivil(380, default_p06, default_k06, 4.211577).
navstivil(381, default_p06, default_k06, 4.211577).
navstivil(382, default_p06, default_k06, 55.211607).
navstivil(383, default_p06, default_k06, 55.211607).
navstivil(384, default_p06, default_k06, 55.211607).
navstivil(385, default_p06, default_k06, 20.211638).
navstivil(386, default_p06, default_k06, 20.211638).
navstivil(387, default_p06, default_k06, 20.211638).
navstivil(388, default_p06, default_k06, 85.21167).
navstivil(389, default_p06, default_k06, 85.21167).
navstivil(390, default_p06, default_k06, 85.21167).
navstivil(391, default_p06, default_k07, 27.211703).
navstivil(392, default_p06, default_k07, 27.211703).
navstivil(393, default_p06, default_k07, 27.211703).
navstivil(394, default_p06, default_k07, 14.211733).
navstivil(395, default_p06, default_k07, 14.211733).
navstivil(396, default_p06, default_k07, 14.211733).
navstivil(397, default_p06, default_k07, 8.211764).
navstivil(398, default_p06, default_k07, 8.211764).
navstivil(399, default_p06, default_k07, 8.211764).
navstivil(400, default_p06, default_k07, 96.211792).
navstivil(401, default_p06, default_k07, 96.211792).
navstivil(402, default_p06, default_k07, 96.211792).
navstivil(403, default_p06, default_k07, 59.211821).
navstivil(404, default_p06, default_k07, 59.211821).
navstivil(405, default_p06, default_k07, 59.211821).
navstivil(406, default_p06, default_k08, 82.211852).
navstivil(407, default_p06, default_k08, 82.211852).
navstivil(408, default_p06, default_k08, 82.211852).
navstivil(409, default_p06, default_k08, 33.211881).
navstivil(410, default_p06, default_k08, 33.211881).
navstivil(411, default_p06, default_k08, 33.211881).
navstivil(412, default_p06, default_k08, 36.21191).
navstivil(413, default_p06, default_k08, 36.21191).
navstivil(414, default_p06, default_k08, 36.21191).
navstivil(415, default_p06, default_k08, 73.211938).
navstivil(416, default_p06, default_k08, 73.211938).
navstivil(417, default_p06, default_k08, 73.211938).
navstivil(418, default_p06, default_k08, 69.211968).
navstivil(419, default_p06, default_k08, 69.211968).
navstivil(420, default_p06, default_k08, 69.211968).
navstivil(421, default_p06, default_k09, 30.211999).
navstivil(422, default_p06, default_k09, 30.211999).
navstivil(423, default_p06, default_k09, 30.211999).
navstivil(424, default_p06, default_k09, 44.212067).
navstivil(425, default_p06, default_k09, 44.212067).
navstivil(426, default_p06, default_k09, 44.212067).
navstivil(427, default_p06, default_k09, 47.212128).
navstivil(428, default_p06, default_k09, 47.212128).
navstivil(429, default_p06, default_k09, 47.212128).
navstivil(430, default_p06, default_k09, 33.212165).
navstivil(431, default_p06, default_k09, 33.212165).
navstivil(432, default_p06, default_k09, 33.212165).
navstivil(433, default_p06, default_k09, 52.212194).
navstivil(434, default_p06, default_k09, 52.212194).
navstivil(435, default_p06, default_k09, 52.212194).
navstivil(436, default_p06, default_k10, 27.212225).
navstivil(437, default_p06, default_k10, 27.212225).
navstivil(438, default_p06, default_k10, 27.212225).
navstivil(439, default_p06, default_k10, 53.212253).
navstivil(440, default_p06, default_k10, 53.212253).
navstivil(441, default_p06, default_k10, 53.212253).
navstivil(442, default_p06, default_k10, 28.212282).
navstivil(443, default_p06, default_k10, 28.212282).
navstivil(444, default_p06, default_k10, 28.212282).
navstivil(445, default_p06, default_k10, 50.212311).
navstivil(446, default_p06, default_k10, 50.212311).
navstivil(447, default_p06, default_k10, 50.212311).
navstivil(448, default_p06, default_k10, 36.212339).
navstivil(449, default_p06, default_k10, 36.212339).
navstivil(450, default_p06, default_k10, 36.212339).
navstivil(451, default_p07, default_k01, 60.21237).
navstivil(452, default_p07, default_k01, 60.21237).
navstivil(453, default_p07, default_k01, 60.21237).
navstivil(454, default_p07, default_k01, 93.212399).
navstivil(455, default_p07, default_k01, 93.212399).
navstivil(456, default_p07, default_k01, 93.212399).
navstivil(457, default_p07, default_k01, 37.212427).
navstivil(458, default_p07, default_k01, 37.212427).
navstivil(459, default_p07, default_k01, 37.212427).
navstivil(460, default_p07, default_k01, 16.212587).
navstivil(461, default_p07, default_k01, 16.212587).
navstivil(462, default_p07, default_k01, 16.212587).
navstivil(463, default_p07, default_k01, 5.212617).
navstivil(464, default_p07, default_k01, 5.212617).
navstivil(465, default_p07, default_k01, 5.212617).
navstivil(466, default_p07, default_k01, 67.212648).
navstivil(467, default_p07, default_k01, 67.212648).
navstivil(468, default_p07, default_k01, 67.212648).
navstivil(469, default_p07, default_k02, 100.21268).
navstivil(470, default_p07, default_k02, 100.21268).
navstivil(471, default_p07, default_k02, 100.21268).
navstivil(472, default_p07, default_k02, 42.212709).
navstivil(473, default_p07, default_k02, 42.212709).
navstivil(474, default_p07, default_k02, 42.212709).
navstivil(475, default_p07, default_k02, 14.21274).
navstivil(476, default_p07, default_k02, 14.21274).
navstivil(477, default_p07, default_k02, 14.21274).
navstivil(478, default_p07, default_k02, 70.212769).
navstivil(479, default_p07, default_k02, 70.212769).
navstivil(480, default_p07, default_k02, 70.212769).
navstivil(481, default_p07, default_k02, 47.2128).
navstivil(482, default_p07, default_k02, 47.2128).
navstivil(483, default_p07, default_k02, 47.2128).
navstivil(484, default_p07, default_k02, 80.212829).
navstivil(485, default_p07, default_k02, 80.212829).
navstivil(486, default_p07, default_k02, 80.212829).
navstivil(487, default_p07, default_k03, 97.212858).
navstivil(488, default_p07, default_k03, 97.212858).
navstivil(489, default_p07, default_k03, 97.212858).
navstivil(490, default_p07, default_k03, 48.212888).
navstivil(491, default_p07, default_k03, 48.212888).
navstivil(492, default_p07, default_k03, 48.212888).
navstivil(493, default_p07, default_k03, 48.212925).
navstivil(494, default_p07, default_k03, 48.212925).
navstivil(495, default_p07, default_k03, 48.212925).
navstivil(496, default_p07, default_k03, 62.212971).
navstivil(497, default_p07, default_k03, 62.212971).
navstivil(498, default_p07, default_k03, 62.212971).
navstivil(499, default_p07, default_k03, 99.213025).
navstivil(500, default_p07, default_k03, 99.213025).
navstivil(501, default_p07, default_k03, 99.213025).
navstivil(502, default_p07, default_k03, 67.213057).
navstivil(503, default_p07, default_k03, 67.213057).
navstivil(504, default_p07, default_k03, 67.213057).
navstivil(505, default_p07, default_k04, 84.213087).
navstivil(506, default_p07, default_k04, 84.213087).
navstivil(507, default_p07, default_k04, 84.213087).
navstivil(508, default_p07, default_k04, 54.213115).
navstivil(509, default_p07, default_k04, 54.213115).
navstivil(510, default_p07, default_k04, 54.213115).
navstivil(511, default_p07, default_k04, 59.213143).
navstivil(512, default_p07, default_k04, 59.213143).
navstivil(513, default_p07, default_k04, 59.213143).
navstivil(514, default_p07, default_k04, 61.213171).
navstivil(515, default_p07, default_k04, 61.213171).
navstivil(516, default_p07, default_k04, 61.213171).
navstivil(517, default_p07, default_k04, 27.213201).
navstivil(518, default_p07, default_k04, 27.213201).
navstivil(519, default_p07, default_k04, 27.213201).
navstivil(520, default_p07, default_k04, 74.21323).
navstivil(521, default_p07, default_k04, 74.21323).
navstivil(522, default_p07, default_k04, 74.21323).
navstivil(523, default_p07, default_k05, 62.213261).
navstivil(524, default_p07, default_k05, 62.213261).
navstivil(525, default_p07, default_k05, 62.213261).
navstivil(526, default_p07, default_k05, 54.213289).
navstivil(527, default_p07, default_k05, 54.213289).
navstivil(528, default_p07, default_k05, 54.213289).
navstivil(529, default_p07, default_k05, 62.213318).
navstivil(530, default_p07, default_k05, 62.213318).
navstivil(531, default_p07, default_k05, 62.213318).
navstivil(532, default_p07, default_k05, 88.213348).
navstivil(533, default_p07, default_k05, 88.213348).
navstivil(534, default_p07, default_k05, 88.213348).
navstivil(535, default_p07, default_k05, 87.213377).
navstivil(536, default_p07, default_k05, 87.213377).
navstivil(537, default_p07, default_k05, 87.213377).
navstivil(538, default_p07, default_k05, 27.213406).
navstivil(539, default_p07, default_k05, 27.213406).
navstivil(540, default_p07, default_k05, 27.213406).
navstivil(541, default_p07, default_k06, 93.213439).
navstivil(542, default_p07, default_k06, 93.213439).
navstivil(543, default_p07, default_k06, 93.213439).
navstivil(544, default_p07, default_k06, 87.213467).
navstivil(545, default_p07, default_k06, 87.213467).
navstivil(546, default_p07, default_k06, 87.213467).
navstivil(547, default_p07, default_k06, 10.213498).
navstivil(548, default_p07, default_k06, 10.213498).
navstivil(549, default_p07, default_k06, 10.213498).
navstivil(550, default_p07, default_k06, 28.21353).
navstivil(551, default_p07, default_k06, 28.21353).
navstivil(552, default_p07, default_k06, 28.21353).
navstivil(553, default_p07, default_k06, 43.213558).
navstivil(554, default_p07, default_k06, 43.213558).
navstivil(555, default_p07, default_k06, 43.213558).
navstivil(556, default_p07, default_k06, 5.213586).
navstivil(557, default_p07, default_k06, 5.213586).
navstivil(558, default_p07, default_k06, 5.213586).
navstivil(559, default_p07, default_k07, 36.213616).
navstivil(560, default_p07, default_k07, 36.213616).
navstivil(561, default_p07, default_k07, 36.213616).
navstivil(562, default_p07, default_k07, 14.213644).
navstivil(563, default_p07, default_k07, 14.213644).
navstivil(564, default_p07, default_k07, 14.213644).
navstivil(565, default_p07, default_k07, 1.213674).
navstivil(566, default_p07, default_k07, 1.213674).
navstivil(567, default_p07, default_k07, 1.213674).
navstivil(568, default_p07, default_k07, 83.213702).
navstivil(569, default_p07, default_k07, 83.213702).
navstivil(570, default_p07, default_k07, 83.213702).
navstivil(571, default_p07, default_k07, 5.21373).
navstivil(572, default_p07, default_k07, 5.21373).
navstivil(573, default_p07, default_k07, 5.21373).
navstivil(574, default_p07, default_k07, 80.21376).
navstivil(575, default_p07, default_k07, 80.21376).
navstivil(576, default_p07, default_k07, 80.21376).
navstivil(577, default_p07, default_k08, 38.213788).
navstivil(578, default_p07, default_k08, 38.213788).
navstivil(579, default_p07, default_k08, 38.213788).
navstivil(580, default_p07, default_k08, 21.213818).
navstivil(581, default_p07, default_k08, 21.213818).
navstivil(582, default_p07, default_k08, 21.213818).
navstivil(583, default_p07, default_k08, 62.213847).
navstivil(584, default_p07, default_k08, 62.213847).
navstivil(585, default_p07, default_k08, 62.213847).
navstivil(586, default_p07, default_k08, 37.213877).
navstivil(587, default_p07, default_k08, 37.213877).
navstivil(588, default_p07, default_k08, 37.213877).
navstivil(589, default_p07, default_k08, 55.213906).
navstivil(590, default_p07, default_k08, 55.213906).
navstivil(591, default_p07, default_k08, 55.213906).
navstivil(592, default_p07, default_k08, 80.213935).
navstivil(593, default_p07, default_k08, 80.213935).
navstivil(594, default_p07, default_k08, 80.213935).
navstivil(595, default_p07, default_k09, 53.213967).
navstivil(596, default_p07, default_k09, 53.213967).
navstivil(597, default_p07, default_k09, 53.213967).
navstivil(598, default_p07, default_k09, 80.213995).
navstivil(599, default_p07, default_k09, 80.213995).
navstivil(600, default_p07, default_k09, 80.213995).
navstivil(601, default_p07, default_k09, 72.214024).
navstivil(602, default_p07, default_k09, 72.214024).
navstivil(603, default_p07, default_k09, 72.214024).
navstivil(604, default_p07, default_k09, 23.214052).
navstivil(605, default_p07, default_k09, 23.214052).
navstivil(606, default_p07, default_k09, 23.214052).
navstivil(607, default_p07, default_k09, 21.214079).
navstivil(608, default_p07, default_k09, 21.214079).
navstivil(609, default_p07, default_k09, 21.214079).
navstivil(610, default_p07, default_k09, 34.214107).
navstivil(611, default_p07, default_k09, 34.214107).
navstivil(612, default_p07, default_k09, 34.214107).
navstivil(613, default_p07, default_k10, 21.214137).
navstivil(614, default_p07, default_k10, 21.214137).
navstivil(615, default_p07, default_k10, 21.214137).
navstivil(616, default_p07, default_k10, 10.214167).
navstivil(617, default_p07, default_k10, 10.214167).
navstivil(618, default_p07, default_k10, 10.214167).
navstivil(619, default_p07, default_k10, 54.214196).
navstivil(620, default_p07, default_k10, 54.214196).
navstivil(621, default_p07, default_k10, 54.214196).
navstivil(622, default_p07, default_k10, 8.214224).
navstivil(623, default_p07, default_k10, 8.214224).
navstivil(624, default_p07, default_k10, 8.214224).
navstivil(625, default_p07, default_k10, 7.214253).
navstivil(626, default_p07, default_k10, 7.214253).
navstivil(627, default_p07, default_k10, 7.214253).
navstivil(628, default_p07, default_k10, 55.21428).
navstivil(629, default_p07, default_k10, 55.21428).
navstivil(630, default_p07, default_k10, 55.21428).
navstivil(631, default_p08, default_k01, 37.214311).
navstivil(632, default_p08, default_k01, 37.214311).
navstivil(633, default_p08, default_k01, 37.214311).
navstivil(634, default_p08, default_k01, 82.21434).
navstivil(635, default_p08, default_k01, 82.21434).
navstivil(636, default_p08, default_k01, 82.21434).
navstivil(637, default_p08, default_k01, 65.214367).
navstivil(638, default_p08, default_k01, 65.214367).
navstivil(639, default_p08, default_k01, 65.214367).
navstivil(640, default_p08, default_k01, 39.214395).
navstivil(641, default_p08, default_k01, 39.214395).
navstivil(642, default_p08, default_k01, 39.214395).
navstivil(643, default_p08, default_k01, 83.214423).
navstivil(644, default_p08, default_k01, 83.214423).
navstivil(645, default_p08, default_k01, 83.214423).
navstivil(646, default_p08, default_k01, 54.214454).
navstivil(647, default_p08, default_k01, 54.214454).
navstivil(648, default_p08, default_k01, 54.214454).
navstivil(649, default_p08, default_k01, 100.214483).
navstivil(650, default_p08, default_k01, 100.214483).
navstivil(651, default_p08, default_k01, 100.214483).
navstivil(652, default_p08, default_k02, 17.214512).
navstivil(653, default_p08, default_k02, 17.214512).
navstivil(654, default_p08, default_k02, 17.214512).
navstivil(655, default_p08, default_k02, 19.214541).
navstivil(656, default_p08, default_k02, 19.214541).
navstivil(657, default_p08, default_k02, 19.214541).
navstivil(658, default_p08, default_k02, 51.21457).
navstivil(659, default_p08, default_k02, 51.21457).
navstivil(660, default_p08, default_k02, 51.21457).
navstivil(661, default_p08, default_k02, 22.214599).
navstivil(662, default_p08, default_k02, 22.214599).
navstivil(663, default_p08, default_k02, 22.214599).
navstivil(664, default_p08, default_k02, 40.214628).
navstivil(665, default_p08, default_k02, 40.214628).
navstivil(666, default_p08, default_k02, 40.214628).
navstivil(667, default_p08, default_k02, 81.214656).
navstivil(668, default_p08, default_k02, 81.214656).
navstivil(669, default_p08, default_k02, 81.214656).
navstivil(670, default_p08, default_k02, 58.214686).
navstivil(671, default_p08, default_k02, 58.214686).
navstivil(672, default_p08, default_k02, 58.214686).
navstivil(673, default_p08, default_k03, 23.214717).
navstivil(674, default_p08, default_k03, 23.214717).
navstivil(675, default_p08, default_k03, 23.214717).
navstivil(676, default_p08, default_k03, 58.214747).
navstivil(677, default_p08, default_k03, 58.214747).
navstivil(678, default_p08, default_k03, 58.214747).
navstivil(679, default_p08, default_k03, 37.214776).
navstivil(680, default_p08, default_k03, 37.214776).
navstivil(681, default_p08, default_k03, 37.214776).
navstivil(682, default_p08, default_k03, 55.214805).
navstivil(683, default_p08, default_k03, 55.214805).
navstivil(684, default_p08, default_k03, 55.214805).
navstivil(685, default_p08, default_k03, 81.214833).
navstivil(686, default_p08, default_k03, 81.214833).
navstivil(687, default_p08, default_k03, 81.214833).
navstivil(688, default_p08, default_k03, 62.214862).
navstivil(689, default_p08, default_k03, 62.214862).
navstivil(690, default_p08, default_k03, 62.214862).
navstivil(691, default_p08, default_k03, 53.214889).
navstivil(692, default_p08, default_k03, 53.214889).
navstivil(693, default_p08, default_k03, 53.214889).
navstivil(694, default_p08, default_k04, 17.214917).
navstivil(695, default_p08, default_k04, 17.214917).
navstivil(696, default_p08, default_k04, 17.214917).
navstivil(697, default_p08, default_k04, 84.214946).
navstivil(698, default_p08, default_k04, 84.214946).
navstivil(699, default_p08, default_k04, 84.214946).
navstivil(700, default_p08, default_k04, 64.214974).
navstivil(701, default_p08, default_k04, 64.214974).
navstivil(702, default_p08, default_k04, 64.214974).
navstivil(703, default_p08, default_k04, 3.215002).
navstivil(704, default_p08, default_k04, 3.215002).
navstivil(705, default_p08, default_k04, 3.215002).
navstivil(706, default_p08, default_k04, 23.215031).
navstivil(707, default_p08, default_k04, 23.215031).
navstivil(708, default_p08, default_k04, 23.215031).
navstivil(709, default_p08, default_k04, 31.21506).
navstivil(710, default_p08, default_k04, 31.21506).
navstivil(711, default_p08, default_k04, 31.21506).
navstivil(712, default_p08, default_k04, 12.21509).
navstivil(713, default_p08, default_k04, 12.21509).
navstivil(714, default_p08, default_k04, 12.21509).
navstivil(715, default_p08, default_k05, 35.215119).
navstivil(716, default_p08, default_k05, 35.215119).
navstivil(717, default_p08, default_k05, 35.215119).
navstivil(718, default_p08, default_k05, 100.215148).
navstivil(719, default_p08, default_k05, 100.215148).
navstivil(720, default_p08, default_k05, 100.215148).
navstivil(721, default_p08, default_k05, 90.215177).
navstivil(722, default_p08, default_k05, 90.215177).
navstivil(723, default_p08, default_k05, 90.215177).
navstivil(724, default_p08, default_k05, 57.215206).
navstivil(725, default_p08, default_k05, 57.215206).
navstivil(726, default_p08, default_k05, 57.215206).
navstivil(727, default_p08, default_k05, 63.215236).
navstivil(728, default_p08, default_k05, 63.215236).
navstivil(729, default_p08, default_k05, 63.215236).
navstivil(730, default_p08, default_k05, 80.215266).
navstivil(731, default_p08, default_k05, 80.215266).
navstivil(732, default_p08, default_k05, 80.215266).
navstivil(733, default_p08, default_k05, 4.215294).
navstivil(734, default_p08, default_k05, 4.215294).
navstivil(735, default_p08, default_k05, 4.215294).
navstivil(736, default_p08, default_k06, 77.215324).
navstivil(737, default_p08, default_k06, 77.215324).
navstivil(738, default_p08, default_k06, 77.215324).
navstivil(739, default_p08, default_k06, 91.215353).
navstivil(740, default_p08, default_k06, 91.215353).
navstivil(741, default_p08, default_k06, 91.215353).
navstivil(742, default_p08, default_k06, 93.215381).
navstivil(743, default_p08, default_k06, 93.215381).
navstivil(744, default_p08, default_k06, 93.215381).
navstivil(745, default_p08, default_k06, 64.215409).
navstivil(746, default_p08, default_k06, 64.215409).
navstivil(747, default_p08, default_k06, 64.215409).
navstivil(748, default_p08, default_k06, 24.215437).
navstivil(749, default_p08, default_k06, 24.215437).
navstivil(750, default_p08, default_k06, 24.215437).
navstivil(751, default_p08, default_k06, 48.215466).
navstivil(752, default_p08, default_k06, 48.215466).
navstivil(753, default_p08, default_k06, 48.215466).
navstivil(754, default_p08, default_k06, 31.215494).
navstivil(755, default_p08, default_k06, 31.215494).
navstivil(756, default_p08, default_k06, 31.215494).
navstivil(757, default_p08, default_k07, 61.215523).
navstivil(758, default_p08, default_k07, 61.215523).
navstivil(759, default_p08, default_k07, 61.215523).
navstivil(760, default_p08, default_k07, 59.215551).
navstivil(761, default_p08, default_k07, 59.215551).
navstivil(762, default_p08, default_k07, 59.215551).
navstivil(763, default_p08, default_k07, 95.21558).
navstivil(764, default_p08, default_k07, 95.21558).
navstivil(765, default_p08, default_k07, 95.21558).
navstivil(766, default_p08, default_k07, 88.215608).
navstivil(767, default_p08, default_k07, 88.215608).
navstivil(768, default_p08, default_k07, 88.215608).
navstivil(769, default_p08, default_k07, 20.215636).
navstivil(770, default_p08, default_k07, 20.215636).
navstivil(771, default_p08, default_k07, 20.215636).
navstivil(772, default_p08, default_k07, 77.215665).
navstivil(773, default_p08, default_k07, 77.215665).
navstivil(774, default_p08, default_k07, 77.215665).
navstivil(775, default_p08, default_k07, 60.215694).
navstivil(776, default_p08, default_k07, 60.215694).
navstivil(777, default_p08, default_k07, 60.215694).
navstivil(778, default_p08, default_k08, 28.215724).
navstivil(779, default_p08, default_k08, 28.215724).
navstivil(780, default_p08, default_k08, 28.215724).
navstivil(781, default_p08, default_k08, 57.215755).
navstivil(782, default_p08, default_k08, 57.215755).
navstivil(783, default_p08, default_k08, 57.215755).
navstivil(784, default_p08, default_k08, 93.215786).
navstivil(785, default_p08, default_k08, 93.215786).
navstivil(786, default_p08, default_k08, 93.215786).
navstivil(787, default_p08, default_k08, 94.215814).
navstivil(788, default_p08, default_k08, 94.215814).
navstivil(789, default_p08, default_k08, 94.215814).
navstivil(790, default_p08, default_k08, 7.215844).
navstivil(791, default_p08, default_k08, 7.215844).
navstivil(792, default_p08, default_k08, 7.215844).
navstivil(793, default_p08, default_k08, 40.215872).
navstivil(794, default_p08, default_k08, 40.215872).
navstivil(795, default_p08, default_k08, 40.215872).
navstivil(796, default_p08, default_k08, 68.215901).
navstivil(797, default_p08, default_k08, 68.215901).
navstivil(798, default_p08, default_k08, 68.215901).
navstivil(799, default_p08, default_k09, 52.215931).
navstivil(800, default_p08, default_k09, 52.215931).
navstivil(801, default_p08, default_k09, 52.215931).
navstivil(802, default_p08, default_k09, 69.215959).
navstivil(803, default_p08, default_k09, 69.215959).
navstivil(804, default_p08, default_k09, 69.215959).
navstivil(805, default_p08, default_k09, 15.215986000000001).
navstivil(806, default_p08, default_k09, 15.215986000000001).
navstivil(807, default_p08, default_k09, 15.215986000000001).
navstivil(808, default_p08, default_k09, 25.216046).
navstivil(809, default_p08, default_k09, 25.216046).
navstivil(810, default_p08, default_k09, 25.216046).
navstivil(811, default_p08, default_k09, 84.216094).
navstivil(812, default_p08, default_k09, 84.216094).
navstivil(813, default_p08, default_k09, 84.216094).
navstivil(814, default_p08, default_k09, 90.216123).
navstivil(815, default_p08, default_k09, 90.216123).
navstivil(816, default_p08, default_k09, 90.216123).
navstivil(817, default_p08, default_k09, 53.216152).
navstivil(818, default_p08, default_k09, 53.216152).
navstivil(819, default_p08, default_k09, 53.216152).
navstivil(820, default_p08, default_k10, 37.216181).
navstivil(821, default_p08, default_k10, 37.216181).
navstivil(822, default_p08, default_k10, 37.216181).
navstivil(823, default_p08, default_k10, 96.21621).
navstivil(824, default_p08, default_k10, 96.21621).
navstivil(825, default_p08, default_k10, 96.21621).
navstivil(826, default_p08, default_k10, 83.216239).
navstivil(827, default_p08, default_k10, 83.216239).
navstivil(828, default_p08, default_k10, 83.216239).
navstivil(829, default_p08, default_k10, 4.216268).
navstivil(830, default_p08, default_k10, 4.216268).
navstivil(831, default_p08, default_k10, 4.216268).
navstivil(832, default_p08, default_k10, 76.216301).
navstivil(833, default_p08, default_k10, 76.216301).
navstivil(834, default_p08, default_k10, 76.216301).
navstivil(835, default_p08, default_k10, 63.216331).
navstivil(836, default_p08, default_k10, 63.216331).
navstivil(837, default_p08, default_k10, 63.216331).
navstivil(838, default_p08, default_k10, 23.216359).
navstivil(839, default_p08, default_k10, 23.216359).
navstivil(840, default_p08, default_k10, 23.216359).
navstivil(841, default_p09, default_k01, 26.216383).
navstivil(842, default_p09, default_k01, 46.216392).
navstivil(843, default_p09, default_k01, 41.216401).
navstivil(844, default_p09, default_k01, 26.216409).
navstivil(845, default_p09, default_k01, 16.216417).
navstivil(846, default_p09, default_k01, 21.216426).
navstivil(847, default_p09, default_k01, 32.216434).
navstivil(848, default_p09, default_k01, 85.216442).
navstivil(849, default_p10, default_k01, 60.216468).
navstivil(850, default_p10, default_k01, 60.216468).
navstivil(851, default_p10, default_k01, 60.216468).
navstivil(852, default_p10, default_k01, 19.216497).
navstivil(853, default_p10, default_k01, 19.216497).
navstivil(854, default_p10, default_k01, 19.216497).
navstivil(855, default_p10, default_k01, 1.216525).
navstivil(856, default_p10, default_k01, 1.216525).
navstivil(857, default_p10, default_k01, 1.216525).
navstivil(858, default_p10, default_k01, 85.216553).
navstivil(859, default_p10, default_k01, 85.216553).
navstivil(860, default_p10, default_k01, 85.216553).
navstivil(861, default_p10, default_k01, 65.216583).
navstivil(862, default_p10, default_k01, 65.216583).
navstivil(863, default_p10, default_k01, 65.216583).
navstivil(864, default_p10, default_k01, 73.216611).
navstivil(865, default_p10, default_k01, 73.216611).
navstivil(866, default_p10, default_k01, 73.216611).
navstivil(867, default_p10, default_k01, 1.21664).
navstivil(868, default_p10, default_k01, 1.21664).
navstivil(869, default_p10, default_k01, 1.21664).
navstivil(870, default_p10, default_k01, 11.216668).
navstivil(871, default_p10, default_k01, 11.216668).
navstivil(872, default_p10, default_k01, 11.216668).
navstivil(873, default_p10, default_k01, 56.216696).
navstivil(874, default_p10, default_k01, 56.216696).
navstivil(875, default_p10, default_k01, 56.216696).
navstivil(876, default_p10, default_k02, 54.216727).
navstivil(877, default_p10, default_k02, 54.216727).
navstivil(878, default_p10, default_k02, 54.216727).
navstivil(879, default_p10, default_k02, 38.216755).
navstivil(880, default_p10, default_k02, 38.216755).
navstivil(881, default_p10, default_k02, 38.216755).
navstivil(882, default_p10, default_k02, 10.216784).
navstivil(883, default_p10, default_k02, 10.216784).
navstivil(884, default_p10, default_k02, 10.216784).
navstivil(885, default_p10, default_k02, 46.216814).
navstivil(886, default_p10, default_k02, 46.216814).
navstivil(887, default_p10, default_k02, 46.216814).
navstivil(888, default_p10, default_k02, 77.216843).
navstivil(889, default_p10, default_k02, 77.216843).
navstivil(890, default_p10, default_k02, 77.216843).
navstivil(891, default_p10, default_k02, 16.216872).
navstivil(892, default_p10, default_k02, 16.216872).
navstivil(893, default_p10, default_k02, 16.216872).
navstivil(894, default_p10, default_k02, 6.216901).
navstivil(895, default_p10, default_k02, 6.216901).
navstivil(896, default_p10, default_k02, 6.216901).
navstivil(897, default_p10, default_k02, 92.21693).
navstivil(898, default_p10, default_k02, 92.21693).
navstivil(899, default_p10, default_k02, 92.21693).
navstivil(900, default_p10, default_k02, 50.216959).
navstivil(901, default_p10, default_k02, 50.216959).
navstivil(902, default_p10, default_k02, 50.216959).
navstivil(903, default_p10, default_k03, 95.216987).
navstivil(904, default_p10, default_k03, 95.216987).
navstivil(905, default_p10, default_k03, 95.216987).
navstivil(906, default_p10, default_k03, 12.217016).
navstivil(907, default_p10, default_k03, 12.217016).
navstivil(908, default_p10, default_k03, 12.217016).
navstivil(909, default_p10, default_k03, 82.217043).
navstivil(910, default_p10, default_k03, 82.217043).
navstivil(911, default_p10, default_k03, 82.217043).
navstivil(912, default_p10, default_k03, 73.217072).
navstivil(913, default_p10, default_k03, 73.217072).
navstivil(914, default_p10, default_k03, 73.217072).
navstivil(915, default_p10, default_k03, 22.217101).
navstivil(916, default_p10, default_k03, 22.217101).
navstivil(917, default_p10, default_k03, 22.217101).
navstivil(918, default_p10, default_k03, 46.217131).
navstivil(919, default_p10, default_k03, 46.217131).
navstivil(920, default_p10, default_k03, 46.217131).
navstivil(921, default_p10, default_k03, 12.21716).
navstivil(922, default_p10, default_k03, 12.21716).
navstivil(923, default_p10, default_k03, 12.21716).
navstivil(924, default_p10, default_k03, 68.217188).
navstivil(925, default_p10, default_k03, 68.217188).
navstivil(926, default_p10, default_k03, 68.217188).
navstivil(927, default_p10, default_k03, 24.217216).
navstivil(928, default_p10, default_k03, 24.217216).
navstivil(929, default_p10, default_k03, 24.217216).
navstivil(930, default_p10, default_k04, 19.217247).
navstivil(931, default_p10, default_k04, 19.217247).
navstivil(932, default_p10, default_k04, 19.217247).
navstivil(933, default_p10, default_k04, 64.217278).
navstivil(934, default_p10, default_k04, 64.217278).
navstivil(935, default_p10, default_k04, 64.217278).
navstivil(936, default_p10, default_k04, 87.217307).
navstivil(937, default_p10, default_k04, 87.217307).
navstivil(938, default_p10, default_k04, 87.217307).
navstivil(939, default_p10, default_k04, 13.217336).
navstivil(940, default_p10, default_k04, 13.217336).
navstivil(941, default_p10, default_k04, 13.217336).
navstivil(942, default_p10, default_k04, 81.217366).
navstivil(943, default_p10, default_k04, 81.217366).
navstivil(944, default_p10, default_k04, 81.217366).
navstivil(945, default_p10, default_k04, 7.217397).
navstivil(946, default_p10, default_k04, 7.217397).
navstivil(947, default_p10, default_k04, 7.217397).
navstivil(948, default_p10, default_k04, 17.217425).
navstivil(949, default_p10, default_k04, 17.217425).
navstivil(950, default_p10, default_k04, 17.217425).
navstivil(951, default_p10, default_k04, 93.217455).
navstivil(952, default_p10, default_k04, 93.217455).
navstivil(953, default_p10, default_k04, 93.217455).
navstivil(954, default_p10, default_k04, 85.217487).
navstivil(955, default_p10, default_k04, 85.217487).
navstivil(956, default_p10, default_k04, 85.217487).
navstivil(957, default_p10, default_k05, 93.217519).
navstivil(958, default_p10, default_k05, 93.217519).
navstivil(959, default_p10, default_k05, 93.217519).
navstivil(960, default_p10, default_k05, 38.21755).
navstivil(961, default_p10, default_k05, 38.21755).
navstivil(962, default_p10, default_k05, 38.21755).
navstivil(963, default_p10, default_k05, 65.217581).
navstivil(964, default_p10, default_k05, 65.217581).
navstivil(965, default_p10, default_k05, 65.217581).
navstivil(966, default_p10, default_k05, 2.21761).
navstivil(967, default_p10, default_k05, 2.21761).
navstivil(968, default_p10, default_k05, 2.21761).
navstivil(969, default_p10, default_k05, 18.217641).
navstivil(970, default_p10, default_k05, 18.217641).
navstivil(971, default_p10, default_k05, 18.217641).
navstivil(972, default_p10, default_k05, 56.217672).
navstivil(973, default_p10, default_k05, 56.217672).
navstivil(974, default_p10, default_k05, 56.217672).
navstivil(975, default_p10, default_k05, 46.217706).
navstivil(976, default_p10, default_k05, 46.217706).
navstivil(977, default_p10, default_k05, 46.217706).
navstivil(978, default_p10, default_k05, 25.217735).
navstivil(979, default_p10, default_k05, 25.217735).
navstivil(980, default_p10, default_k05, 25.217735).
navstivil(981, default_p10, default_k05, 11.217765).
navstivil(982, default_p10, default_k05, 11.217765).
navstivil(983, default_p10, default_k05, 11.217765).
navstivil(984, default_p10, default_k06, 25.217795).
navstivil(985, default_p10, default_k06, 25.217795).
navstivil(986, default_p10, default_k06, 25.217795).
navstivil(987, default_p10, default_k06, 97.217824).
navstivil(988, default_p10, default_k06, 97.217824).
navstivil(989, default_p10, default_k06, 97.217824).
navstivil(990, default_p10, default_k06, 48.217852).
navstivil(991, default_p10, default_k06, 48.217852).
navstivil(992, default_p10, default_k06, 48.217852).
navstivil(993, default_p10, default_k06, 31.217882).
navstivil(994, default_p10, default_k06, 31.217882).
navstivil(995, default_p10, default_k06, 31.217882).
navstivil(996, default_p10, default_k06, 97.217911).
navstivil(997, default_p10, default_k06, 97.217911).
navstivil(998, default_p10, default_k06, 97.217911).
navstivil(999, default_p10, default_k06, 7.21794).
navstivil(1000, default_p10, default_k06, 7.21794).
navstivil(1001, default_p10, default_k06, 7.21794).
navstivil(1002, default_p10, default_k06, 9.21797).
navstivil(1003, default_p10, default_k06, 9.21797).
navstivil(1004, default_p10, default_k06, 9.21797).
navstivil(1005, default_p10, default_k06, 69.217998).
navstivil(1006, default_p10, default_k06, 69.217998).
navstivil(1007, default_p10, default_k06, 69.217998).
navstivil(1008, default_p10, default_k06, 44.218028).
navstivil(1009, default_p10, default_k06, 44.218028).
navstivil(1010, default_p10, default_k06, 44.218028).
navstivil(1011, default_p10, default_k07, 43.218059).
navstivil(1012, default_p10, default_k07, 43.218059).
navstivil(1013, default_p10, default_k07, 43.218059).
navstivil(1014, default_p10, default_k07, 73.218091).
navstivil(1015, default_p10, default_k07, 73.218091).
navstivil(1016, default_p10, default_k07, 73.218091).
navstivil(1017, default_p10, default_k07, 69.21812).
navstivil(1018, default_p10, default_k07, 69.21812).
navstivil(1019, default_p10, default_k07, 69.21812).
navstivil(1020, default_p10, default_k07, 67.218152).
navstivil(1021, default_p10, default_k07, 67.218152).
navstivil(1022, default_p10, default_k07, 67.218152).
navstivil(1023, default_p10, default_k07, 97.218191).
navstivil(1024, default_p10, default_k07, 97.218191).
navstivil(1025, default_p10, default_k07, 97.218191).
navstivil(1026, default_p10, default_k07, 30.218212).
navstivil(1027, default_p10, default_k07, 30.218212).
navstivil(1028, default_p10, default_k07, 30.218212).
navstivil(1029, default_p10, default_k07, 6.218231).
navstivil(1030, default_p10, default_k07, 6.218231).
navstivil(1031, default_p10, default_k07, 6.218231).
navstivil(1032, default_p10, default_k07, 30.21825).
navstivil(1033, default_p10, default_k07, 30.21825).
navstivil(1034, default_p10, default_k07, 30.21825).
navstivil(1035, default_p10, default_k07, 38.218269).
navstivil(1036, default_p10, default_k07, 38.218269).
navstivil(1037, default_p10, default_k07, 38.218269).
navstivil(1038, default_p10, default_k08, 88.218289).
navstivil(1039, default_p10, default_k08, 88.218289).
navstivil(1040, default_p10, default_k08, 88.218289).
navstivil(1041, default_p10, default_k08, 67.218309).
navstivil(1042, default_p10, default_k08, 67.218309).
navstivil(1043, default_p10, default_k08, 67.218309).
navstivil(1044, default_p10, default_k08, 91.218328).
navstivil(1045, default_p10, default_k08, 91.218328).
navstivil(1046, default_p10, default_k08, 91.218328).
navstivil(1047, default_p10, default_k08, 37.218347).
navstivil(1048, default_p10, default_k08, 37.218347).
navstivil(1049, default_p10, default_k08, 37.218347).
navstivil(1050, default_p10, default_k08, 28.218366).
navstivil(1051, default_p10, default_k08, 28.218366).
navstivil(1052, default_p10, default_k08, 28.218366).
navstivil(1053, default_p10, default_k08, 67.218386).
navstivil(1054, default_p10, default_k08, 67.218386).
navstivil(1055, default_p10, default_k08, 67.218386).
navstivil(1056, default_p10, default_k08, 65.218405).
navstivil(1057, default_p10, default_k08, 65.218405).
navstivil(1058, default_p10, default_k08, 65.218405).
navstivil(1059, default_p10, default_k08, 94.218424).
navstivil(1060, default_p10, default_k08, 94.218424).
navstivil(1061, default_p10, default_k08, 94.218424).
navstivil(1062, default_p10, default_k08, 94.218445).
navstivil(1063, default_p10, default_k08, 94.218445).
navstivil(1064, default_p10, default_k08, 94.218445).
navstivil(1065, default_p10, default_k09, 11.218466).
navstivil(1066, default_p10, default_k09, 11.218466).
navstivil(1067, default_p10, default_k09, 11.218466).
navstivil(1068, default_p10, default_k09, 90.218486).
navstivil(1069, default_p10, default_k09, 90.218486).
navstivil(1070, default_p10, default_k09, 90.218486).
navstivil(1071, default_p10, default_k09, 46.218505).
navstivil(1072, default_p10, default_k09, 46.218505).
navstivil(1073, default_p10, default_k09, 46.218505).
navstivil(1074, default_p10, default_k09, 33.218525).
navstivil(1075, default_p10, default_k09, 33.218525).
navstivil(1076, default_p10, default_k09, 33.218525).
navstivil(1077, default_p10, default_k09, 62.218546).
navstivil(1078, default_p10, default_k09, 62.218546).
navstivil(1079, default_p10, default_k09, 62.218546).
navstivil(1080, default_p10, default_k09, 6.218567).
navstivil(1081, default_p10, default_k09, 6.218567).
navstivil(1082, default_p10, default_k09, 6.218567).
navstivil(1083, default_p10, default_k09, 38.218587).
navstivil(1084, default_p10, default_k09, 38.218587).
navstivil(1085, default_p10, default_k09, 38.218587).
navstivil(1086, default_p10, default_k09, 8.218609).
navstivil(1087, default_p10, default_k09, 8.218609).
navstivil(1088, default_p10, default_k09, 8.218609).
navstivil(1089, default_p10, default_k09, 83.218628).
navstivil(1090, default_p10, default_k09, 83.218628).
navstivil(1091, default_p10, default_k09, 83.218628).
navstivil(1092, default_p10, default_k10, 87.218649).
navstivil(1093, default_p10, default_k10, 87.218649).
navstivil(1094, default_p10, default_k10, 87.218649).
navstivil(1095, default_p10, default_k10, 46.218669).
navstivil(1096, default_p10, default_k10, 46.218669).
navstivil(1097, default_p10, default_k10, 46.218669).
navstivil(1098, default_p10, default_k10, 81.218689).
navstivil(1099, default_p10, default_k10, 81.218689).
navstivil(1100, default_p10, default_k10, 81.218689).
navstivil(1101, default_p10, default_k10, 29.218711).
navstivil(1102, default_p10, default_k10, 29.218711).
navstivil(1103, default_p10, default_k10, 29.218711).
navstivil(1104, default_p10, default_k10, 93.218732).
navstivil(1105, default_p10, default_k10, 93.218732).
navstivil(1106, default_p10, default_k10, 93.218732).
navstivil(1107, default_p10, default_k10, 10.218754).
navstivil(1108, default_p10, default_k10, 10.218754).
navstivil(1109, default_p10, default_k10, 10.218754).
navstivil(1110, default_p10, default_k10, 100.218774).
navstivil(1111, default_p10, default_k10, 100.218774).
navstivil(1112, default_p10, default_k10, 100.218774).
navstivil(1113, default_p10, default_k10, 81.218794).
navstivil(1114, default_p10, default_k10, 81.218794).
navstivil(1115, default_p10, default_k10, 81.218794).
navstivil(1116, default_p10, default_k10, 52.218813).
navstivil(1117, default_p10, default_k10, 52.218813).
navstivil(1118, default_p10, default_k10, 52.218813).
navstivil(1119, default_p11, default_k01, 91.218835).
navstivil(1120, default_p11, default_k01, 91.218835).
navstivil(1121, default_p11, default_k01, 91.218835).
navstivil(1122, default_p11, default_k01, 60.218855).
navstivil(1123, default_p11, default_k01, 60.218855).
navstivil(1124, default_p11, default_k01, 60.218855).
navstivil(1125, default_p11, default_k01, 94.218874).
navstivil(1126, default_p11, default_k01, 94.218874).
navstivil(1127, default_p11, default_k01, 94.218874).
navstivil(1128, default_p11, default_k01, 83.218894).
navstivil(1129, default_p11, default_k01, 83.218894).
navstivil(1130, default_p11, default_k01, 83.218894).
navstivil(1131, default_p11, default_k01, 18.218915).
navstivil(1132, default_p11, default_k01, 18.218915).
navstivil(1133, default_p11, default_k01, 18.218915).
navstivil(1134, default_p11, default_k01, 13.218935).
navstivil(1135, default_p11, default_k01, 13.218935).
navstivil(1136, default_p11, default_k01, 13.218935).
navstivil(1137, default_p11, default_k01, 99.218954).
navstivil(1138, default_p11, default_k01, 99.218954).
navstivil(1139, default_p11, default_k01, 99.218954).
navstivil(1140, default_p11, default_k01, 94.218974).
navstivil(1141, default_p11, default_k01, 94.218974).
navstivil(1142, default_p11, default_k01, 94.218974).
navstivil(1143, default_p11, default_k01, 9.218994).
navstivil(1144, default_p11, default_k01, 9.218994).
navstivil(1145, default_p11, default_k01, 9.218994).
navstivil(1146, default_p11, default_k01, 11.219013).
navstivil(1147, default_p11, default_k01, 11.219013).
navstivil(1148, default_p11, default_k01, 11.219013).
navstivil(1149, default_p11, default_k02, 18.219036).
navstivil(1150, default_p11, default_k02, 18.219036).
navstivil(1151, default_p11, default_k02, 18.219036).
navstivil(1152, default_p11, default_k02, 19.219055).
navstivil(1153, default_p11, default_k02, 19.219055).
navstivil(1154, default_p11, default_k02, 19.219055).
navstivil(1155, default_p11, default_k02, 16.219076).
navstivil(1156, default_p11, default_k02, 16.219076).
navstivil(1157, default_p11, default_k02, 16.219076).
navstivil(1158, default_p11, default_k02, 11.219097).
navstivil(1159, default_p11, default_k02, 11.219097).
navstivil(1160, default_p11, default_k02, 11.219097).
navstivil(1161, default_p11, default_k02, 40.219192).
navstivil(1162, default_p11, default_k02, 40.219192).
navstivil(1163, default_p11, default_k02, 40.219192).
navstivil(1164, default_p11, default_k02, 35.219212).
navstivil(1165, default_p11, default_k02, 35.219212).
navstivil(1166, default_p11, default_k02, 35.219212).
navstivil(1167, default_p11, default_k02, 83.219231).
navstivil(1168, default_p11, default_k02, 83.219231).
navstivil(1169, default_p11, default_k02, 83.219231).
navstivil(1170, default_p11, default_k02, 69.219251).
navstivil(1171, default_p11, default_k02, 69.219251).
navstivil(1172, default_p11, default_k02, 69.219251).
navstivil(1173, default_p11, default_k02, 40.219271).
navstivil(1174, default_p11, default_k02, 40.219271).
navstivil(1175, default_p11, default_k02, 40.219271).
navstivil(1176, default_p11, default_k02, 82.219291).
navstivil(1177, default_p11, default_k02, 82.219291).
navstivil(1178, default_p11, default_k02, 82.219291).
navstivil(1179, default_p11, default_k03, 15.219311).
navstivil(1180, default_p11, default_k03, 15.219311).
navstivil(1181, default_p11, default_k03, 15.219311).
navstivil(1182, default_p11, default_k03, 6.219332).
navstivil(1183, default_p11, default_k03, 6.219332).
navstivil(1184, default_p11, default_k03, 6.219332).
navstivil(1185, default_p11, default_k03, 85.21937).
navstivil(1186, default_p11, default_k03, 85.21937).
navstivil(1187, default_p11, default_k03, 85.21937).
navstivil(1188, default_p11, default_k03, 96.21941).
navstivil(1189, default_p11, default_k03, 96.21941).
navstivil(1190, default_p11, default_k03, 96.21941).
navstivil(1191, default_p11, default_k03, 84.21943).
navstivil(1192, default_p11, default_k03, 84.21943).
navstivil(1193, default_p11, default_k03, 84.21943).
navstivil(1194, default_p11, default_k03, 15.21945).
navstivil(1195, default_p11, default_k03, 15.21945).
navstivil(1196, default_p11, default_k03, 15.21945).
navstivil(1197, default_p11, default_k03, 76.219471).
navstivil(1198, default_p11, default_k03, 76.219471).
navstivil(1199, default_p11, default_k03, 76.219471).
navstivil(1200, default_p11, default_k03, 67.219491).
navstivil(1201, default_p11, default_k03, 67.219491).
navstivil(1202, default_p11, default_k03, 67.219491).
navstivil(1203, default_p11, default_k03, 12.219511).
navstivil(1204, default_p11, default_k03, 12.219511).
navstivil(1205, default_p11, default_k03, 12.219511).
navstivil(1206, default_p11, default_k03, 85.21954).
navstivil(1207, default_p11, default_k03, 85.21954).
navstivil(1208, default_p11, default_k03, 85.21954).
navstivil(1209, default_p11, default_k04, 34.219564).
navstivil(1210, default_p11, default_k04, 34.219564).
navstivil(1211, default_p11, default_k04, 34.219564).
navstivil(1212, default_p11, default_k04, 51.219596).
navstivil(1213, default_p11, default_k04, 51.219596).
navstivil(1214, default_p11, default_k04, 51.219596).
navstivil(1215, default_p11, default_k04, 20.219617).
navstivil(1216, default_p11, default_k04, 20.219617).
navstivil(1217, default_p11, default_k04, 20.219617).
navstivil(1218, default_p11, default_k04, 41.219638).
navstivil(1219, default_p11, default_k04, 41.219638).
navstivil(1220, default_p11, default_k04, 41.219638).
navstivil(1221, default_p11, default_k04, 74.219659).
navstivil(1222, default_p11, default_k04, 74.219659).
navstivil(1223, default_p11, default_k04, 74.219659).
navstivil(1224, default_p11, default_k04, 10.219681).
navstivil(1225, default_p11, default_k04, 10.219681).
navstivil(1226, default_p11, default_k04, 10.219681).
navstivil(1227, default_p11, default_k04, 43.219702).
navstivil(1228, default_p11, default_k04, 43.219702).
navstivil(1229, default_p11, default_k04, 43.219702).
navstivil(1230, default_p11, default_k04, 49.219723).
navstivil(1231, default_p11, default_k04, 49.219723).
navstivil(1232, default_p11, default_k04, 49.219723).
navstivil(1233, default_p11, default_k04, 16.219745).
navstivil(1234, default_p11, default_k04, 16.219745).
navstivil(1235, default_p11, default_k04, 16.219745).
navstivil(1236, default_p11, default_k04, 33.219767).
navstivil(1237, default_p11, default_k04, 33.219767).
navstivil(1238, default_p11, default_k04, 33.219767).
navstivil(1239, default_p11, default_k05, 3.219799).
navstivil(1240, default_p11, default_k05, 3.219799).
navstivil(1241, default_p11, default_k05, 3.219799).
navstivil(1242, default_p11, default_k05, 59.219836).
navstivil(1243, default_p11, default_k05, 59.219836).
navstivil(1244, default_p11, default_k05, 59.219836).
navstivil(1245, default_p11, default_k05, 9.219876).
navstivil(1246, default_p11, default_k05, 9.219876).
navstivil(1247, default_p11, default_k05, 9.219876).
navstivil(1248, default_p11, default_k05, 77.219916).
navstivil(1249, default_p11, default_k05, 77.219916).
navstivil(1250, default_p11, default_k05, 77.219916).
navstivil(1251, default_p11, default_k05, 31.219938).
navstivil(1252, default_p11, default_k05, 31.219938).
navstivil(1253, default_p11, default_k05, 31.219938).
navstivil(1254, default_p11, default_k05, 67.219982).
navstivil(1255, default_p11, default_k05, 67.219982).
navstivil(1256, default_p11, default_k05, 67.219982).
navstivil(1257, default_p11, default_k05, 16.220002).
navstivil(1258, default_p11, default_k05, 16.220002).
navstivil(1259, default_p11, default_k05, 16.220002).
navstivil(1260, default_p11, default_k05, 4.22004).
navstivil(1261, default_p11, default_k05, 4.22004).
navstivil(1262, default_p11, default_k05, 4.22004).
navstivil(1263, default_p11, default_k05, 79.220077).
navstivil(1264, default_p11, default_k05, 79.220077).
navstivil(1265, default_p11, default_k05, 79.220077).
navstivil(1266, default_p11, default_k05, 14.220107).
navstivil(1267, default_p11, default_k05, 14.220107).
navstivil(1268, default_p11, default_k05, 14.220107).
navstivil(1269, default_p11, default_k06, 66.220128).
navstivil(1270, default_p11, default_k06, 66.220128).
navstivil(1271, default_p11, default_k06, 66.220128).
navstivil(1272, default_p11, default_k06, 77.220147).
navstivil(1273, default_p11, default_k06, 77.220147).
navstivil(1274, default_p11, default_k06, 77.220147).
navstivil(1275, default_p11, default_k06, 70.220166).
navstivil(1276, default_p11, default_k06, 70.220166).
navstivil(1277, default_p11, default_k06, 70.220166).
navstivil(1278, default_p11, default_k06, 43.220186).
navstivil(1279, default_p11, default_k06, 43.220186).
navstivil(1280, default_p11, default_k06, 43.220186).
navstivil(1281, default_p11, default_k06, 80.220205).
navstivil(1282, default_p11, default_k06, 80.220205).
navstivil(1283, default_p11, default_k06, 80.220205).
navstivil(1284, default_p11, default_k06, 14.220225).
navstivil(1285, default_p11, default_k06, 14.220225).
navstivil(1286, default_p11, default_k06, 14.220225).
navstivil(1287, default_p11, default_k06, 31.220245).
navstivil(1288, default_p11, default_k06, 31.220245).
navstivil(1289, default_p11, default_k06, 31.220245).
navstivil(1290, default_p11, default_k06, 92.220265).
navstivil(1291, default_p11, default_k06, 92.220265).
navstivil(1292, default_p11, default_k06, 92.220265).
navstivil(1293, default_p11, default_k06, 91.220285).
navstivil(1294, default_p11, default_k06, 91.220285).
navstivil(1295, default_p11, default_k06, 91.220285).
navstivil(1296, default_p11, default_k06, 17.22032).
navstivil(1297, default_p11, default_k06, 17.22032).
navstivil(1298, default_p11, default_k06, 17.22032).
navstivil(1299, default_p11, default_k07, 28.220387).
navstivil(1300, default_p11, default_k07, 28.220387).
navstivil(1301, default_p11, default_k07, 28.220387).
navstivil(1302, default_p11, default_k07, 24.220423).
navstivil(1303, default_p11, default_k07, 24.220423).
navstivil(1304, default_p11, default_k07, 24.220423).
navstivil(1305, default_p11, default_k07, 50.220447).
navstivil(1306, default_p11, default_k07, 50.220447).
navstivil(1307, default_p11, default_k07, 50.220447).
navstivil(1308, default_p11, default_k07, 83.220466).
navstivil(1309, default_p11, default_k07, 83.220466).
navstivil(1310, default_p11, default_k07, 83.220466).
navstivil(1311, default_p11, default_k07, 87.220485).
navstivil(1312, default_p11, default_k07, 87.220485).
navstivil(1313, default_p11, default_k07, 87.220485).
navstivil(1314, default_p11, default_k07, 56.220504).
navstivil(1315, default_p11, default_k07, 56.220504).
navstivil(1316, default_p11, default_k07, 56.220504).
navstivil(1317, default_p11, default_k07, 53.220523).
navstivil(1318, default_p11, default_k07, 53.220523).
navstivil(1319, default_p11, default_k07, 53.220523).
navstivil(1320, default_p11, default_k07, 61.220542).
navstivil(1321, default_p11, default_k07, 61.220542).
navstivil(1322, default_p11, default_k07, 61.220542).
navstivil(1323, default_p11, default_k07, 30.220563).
navstivil(1324, default_p11, default_k07, 30.220563).
navstivil(1325, default_p11, default_k07, 30.220563).
navstivil(1326, default_p11, default_k07, 36.220583).
navstivil(1327, default_p11, default_k07, 36.220583).
navstivil(1328, default_p11, default_k07, 36.220583).
navstivil(1329, default_p11, default_k08, 22.220604).
navstivil(1330, default_p11, default_k08, 22.220604).
navstivil(1331, default_p11, default_k08, 22.220604).
navstivil(1332, default_p11, default_k08, 37.220624).
navstivil(1333, default_p11, default_k08, 37.220624).
navstivil(1334, default_p11, default_k08, 37.220624).
navstivil(1335, default_p11, default_k08, 40.220643).
navstivil(1336, default_p11, default_k08, 40.220643).
navstivil(1337, default_p11, default_k08, 40.220643).
navstivil(1338, default_p11, default_k08, 33.220668).
navstivil(1339, default_p11, default_k08, 33.220668).
navstivil(1340, default_p11, default_k08, 33.220668).
navstivil(1341, default_p11, default_k08, 78.220686).
navstivil(1342, default_p11, default_k08, 78.220686).
navstivil(1343, default_p11, default_k08, 78.220686).
navstivil(1344, default_p11, default_k08, 78.220705).
navstivil(1345, default_p11, default_k08, 78.220705).
navstivil(1346, default_p11, default_k08, 78.220705).
navstivil(1347, default_p11, default_k08, 53.220726).
navstivil(1348, default_p11, default_k08, 53.220726).
navstivil(1349, default_p11, default_k08, 53.220726).
navstivil(1350, default_p11, default_k08, 79.220745).
navstivil(1351, default_p11, default_k08, 79.220745).
navstivil(1352, default_p11, default_k08, 79.220745).
navstivil(1353, default_p11, default_k08, 79.220764).
navstivil(1354, default_p11, default_k08, 79.220764).
navstivil(1355, default_p11, default_k08, 79.220764).
navstivil(1356, default_p11, default_k08, 66.220783).
navstivil(1357, default_p11, default_k08, 66.220783).
navstivil(1358, default_p11, default_k08, 66.220783).
navstivil(1359, default_p11, default_k09, 1.220803).
navstivil(1360, default_p11, default_k09, 1.220803).
navstivil(1361, default_p11, default_k09, 1.220803).
navstivil(1362, default_p11, default_k09, 71.220823).
navstivil(1363, default_p11, default_k09, 71.220823).
navstivil(1364, default_p11, default_k09, 71.220823).
navstivil(1365, default_p11, default_k09, 72.220844).
navstivil(1366, default_p11, default_k09, 72.220844).
navstivil(1367, default_p11, default_k09, 72.220844).
navstivil(1368, default_p11, default_k09, 61.220862).
navstivil(1369, default_p11, default_k09, 61.220862).
navstivil(1370, default_p11, default_k09, 61.220862).
navstivil(1371, default_p11, default_k09, 73.220882).
navstivil(1372, default_p11, default_k09, 73.220882).
navstivil(1373, default_p11, default_k09, 73.220882).
navstivil(1374, default_p11, default_k09, 1.220901).
navstivil(1375, default_p11, default_k09, 1.220901).
navstivil(1376, default_p11, default_k09, 1.220901).
navstivil(1377, default_p11, default_k09, 37.220919).
navstivil(1378, default_p11, default_k09, 37.220919).
navstivil(1379, default_p11, default_k09, 37.220919).
navstivil(1380, default_p11, default_k09, 75.220945).
navstivil(1381, default_p11, default_k09, 75.220945).
navstivil(1382, default_p11, default_k09, 75.220945).
navstivil(1383, default_p11, default_k09, 19.220963).
navstivil(1384, default_p11, default_k09, 19.220963).
navstivil(1385, default_p11, default_k09, 19.220963).
navstivil(1386, default_p11, default_k09, 66.220983).
navstivil(1387, default_p11, default_k09, 66.220983).
navstivil(1388, default_p11, default_k09, 66.220983).
navstivil(1389, default_p11, default_k10, 51.221002).
navstivil(1390, default_p11, default_k10, 51.221002).
navstivil(1391, default_p11, default_k10, 51.221002).
navstivil(1392, default_p11, default_k10, 37.221023).
navstivil(1393, default_p11, default_k10, 37.221023).
navstivil(1394, default_p11, default_k10, 37.221023).
navstivil(1395, default_p11, default_k10, 53.221042).
navstivil(1396, default_p11, default_k10, 53.221042).
navstivil(1397, default_p11, default_k10, 53.221042).
navstivil(1398, default_p11, default_k10, 39.221061).
navstivil(1399, default_p11, default_k10, 39.221061).
navstivil(1400, default_p11, default_k10, 39.221061).
navstivil(1401, default_p11, default_k10, 26.221081).
navstivil(1402, default_p11, default_k10, 26.221081).
navstivil(1403, default_p11, default_k10, 26.221081).
navstivil(1404, default_p11, default_k10, 41.221099).
navstivil(1405, default_p11, default_k10, 41.221099).
navstivil(1406, default_p11, default_k10, 41.221099).
navstivil(1407, default_p11, default_k10, 58.221118).
navstivil(1408, default_p11, default_k10, 58.221118).
navstivil(1409, default_p11, default_k10, 58.221118).
navstivil(1410, default_p11, default_k10, 31.221137).
navstivil(1411, default_p11, default_k10, 31.221137).
navstivil(1412, default_p11, default_k10, 31.221137).
navstivil(1413, default_p11, default_k10, 84.221157).
navstivil(1414, default_p11, default_k10, 84.221157).
navstivil(1415, default_p11, default_k10, 84.221157).
navstivil(1416, default_p11, default_k10, 95.221176).
navstivil(1417, default_p11, default_k10, 95.221176).
navstivil(1418, default_p11, default_k10, 95.221176).
navstivil(1419, default_p12, default_k01, 83.221198).
navstivil(1420, default_p12, default_k01, 83.221198).
navstivil(1421, default_p12, default_k01, 83.221198).
navstivil(1422, default_p12, default_k01, 81.221222).
navstivil(1423, default_p12, default_k01, 81.221222).
navstivil(1424, default_p12, default_k01, 81.221222).
navstivil(1425, default_p12, default_k01, 26.221242).
navstivil(1426, default_p12, default_k01, 26.221242).
navstivil(1427, default_p12, default_k01, 26.221242).
navstivil(1428, default_p12, default_k01, 69.22126).
navstivil(1429, default_p12, default_k01, 69.22126).
navstivil(1430, default_p12, default_k01, 69.22126).
navstivil(1431, default_p12, default_k01, 8.221279).
navstivil(1432, default_p12, default_k01, 8.221279).
navstivil(1433, default_p12, default_k01, 8.221279).
navstivil(1434, default_p12, default_k01, 73.2213).
navstivil(1435, default_p12, default_k01, 73.2213).
navstivil(1436, default_p12, default_k01, 73.2213).
navstivil(1437, default_p12, default_k01, 43.221319).
navstivil(1438, default_p12, default_k01, 43.221319).
navstivil(1439, default_p12, default_k01, 43.221319).
navstivil(1440, default_p12, default_k01, 63.221338).
navstivil(1441, default_p12, default_k01, 63.221338).
navstivil(1442, default_p12, default_k01, 63.221338).
navstivil(1443, default_p12, default_k01, 32.221358).
navstivil(1444, default_p12, default_k01, 32.221358).
navstivil(1445, default_p12, default_k01, 32.221358).
navstivil(1446, default_p12, default_k01, 86.221394).
navstivil(1447, default_p12, default_k01, 86.221394).
navstivil(1448, default_p12, default_k01, 86.221394).
navstivil(1449, default_p12, default_k01, 92.221413).
navstivil(1450, default_p12, default_k01, 92.221413).
navstivil(1451, default_p12, default_k01, 92.221413).
navstivil(1452, default_p12, default_k02, 18.221449).
navstivil(1453, default_p12, default_k02, 18.221449).
navstivil(1454, default_p12, default_k02, 18.221449).
navstivil(1455, default_p12, default_k02, 86.221469).
navstivil(1456, default_p12, default_k02, 86.221469).
navstivil(1457, default_p12, default_k02, 86.221469).
navstivil(1458, default_p12, default_k02, 36.221488).
navstivil(1459, default_p12, default_k02, 36.221488).
navstivil(1460, default_p12, default_k02, 36.221488).
navstivil(1461, default_p12, default_k02, 24.221507).
navstivil(1462, default_p12, default_k02, 24.221507).
navstivil(1463, default_p12, default_k02, 24.221507).
navstivil(1464, default_p12, default_k02, 68.22153).
navstivil(1465, default_p12, default_k02, 68.22153).
navstivil(1466, default_p12, default_k02, 68.22153).
navstivil(1467, default_p12, default_k02, 35.221549).
navstivil(1468, default_p12, default_k02, 35.221549).
navstivil(1469, default_p12, default_k02, 35.221549).
navstivil(1470, default_p12, default_k02, 60.221568).
navstivil(1471, default_p12, default_k02, 60.221568).
navstivil(1472, default_p12, default_k02, 60.221568).
navstivil(1473, default_p12, default_k02, 67.221588).
navstivil(1474, default_p12, default_k02, 67.221588).
navstivil(1475, default_p12, default_k02, 67.221588).
navstivil(1476, default_p12, default_k02, 88.221608).
navstivil(1477, default_p12, default_k02, 88.221608).
navstivil(1478, default_p12, default_k02, 88.221608).
navstivil(1479, default_p12, default_k02, 23.221626).
navstivil(1480, default_p12, default_k02, 23.221626).
navstivil(1481, default_p12, default_k02, 23.221626).
navstivil(1482, default_p12, default_k02, 14.221646).
navstivil(1483, default_p12, default_k02, 14.221646).
navstivil(1484, default_p12, default_k02, 14.221646).
navstivil(1485, default_p12, default_k03, 74.221666).
navstivil(1486, default_p12, default_k03, 74.221666).
navstivil(1487, default_p12, default_k03, 74.221666).
navstivil(1488, default_p12, default_k03, 32.221685).
navstivil(1489, default_p12, default_k03, 32.221685).
navstivil(1490, default_p12, default_k03, 32.221685).
navstivil(1491, default_p12, default_k03, 60.221705).
navstivil(1492, default_p12, default_k03, 60.221705).
navstivil(1493, default_p12, default_k03, 60.221705).
navstivil(1494, default_p12, default_k03, 79.221723).
navstivil(1495, default_p12, default_k03, 79.221723).
navstivil(1496, default_p12, default_k03, 79.221723).
navstivil(1497, default_p12, default_k03, 13.221742).
navstivil(1498, default_p12, default_k03, 13.221742).
navstivil(1499, default_p12, default_k03, 13.221742).
navstivil(1500, default_p12, default_k03, 18.22176).
navstivil(1501, default_p12, default_k03, 18.22176).
navstivil(1502, default_p12, default_k03, 18.22176).
navstivil(1503, default_p12, default_k03, 5.22178).
navstivil(1504, default_p12, default_k03, 5.22178).
navstivil(1505, default_p12, default_k03, 5.22178).
navstivil(1506, default_p12, default_k03, 32.221803).
navstivil(1507, default_p12, default_k03, 32.221803).
navstivil(1508, default_p12, default_k03, 32.221803).
navstivil(1509, default_p12, default_k03, 44.221822).
navstivil(1510, default_p12, default_k03, 44.221822).
navstivil(1511, default_p12, default_k03, 44.221822).
navstivil(1512, default_p12, default_k03, 71.221841).
navstivil(1513, default_p12, default_k03, 71.221841).
navstivil(1514, default_p12, default_k03, 71.221841).
navstivil(1515, default_p12, default_k03, 7.221861).
navstivil(1516, default_p12, default_k03, 7.221861).
navstivil(1517, default_p12, default_k03, 7.221861).
navstivil(1518, default_p12, default_k04, 59.221881).
navstivil(1519, default_p12, default_k04, 59.221881).
navstivil(1520, default_p12, default_k04, 59.221881).
navstivil(1521, default_p12, default_k04, 24.221901).
navstivil(1522, default_p12, default_k04, 24.221901).
navstivil(1523, default_p12, default_k04, 24.221901).
navstivil(1524, default_p12, default_k04, 27.221921).
navstivil(1525, default_p12, default_k04, 27.221921).
navstivil(1526, default_p12, default_k04, 27.221921).
navstivil(1527, default_p12, default_k04, 61.221939).
navstivil(1528, default_p12, default_k04, 61.221939).
navstivil(1529, default_p12, default_k04, 61.221939).
navstivil(1530, default_p12, default_k04, 9.221959).
navstivil(1531, default_p12, default_k04, 9.221959).
navstivil(1532, default_p12, default_k04, 9.221959).
navstivil(1533, default_p12, default_k04, 31.221977).
navstivil(1534, default_p12, default_k04, 31.221977).
navstivil(1535, default_p12, default_k04, 31.221977).
navstivil(1536, default_p12, default_k04, 15.221997).
navstivil(1537, default_p12, default_k04, 15.221997).
navstivil(1538, default_p12, default_k04, 15.221997).
navstivil(1539, default_p12, default_k04, 61.222017).
navstivil(1540, default_p12, default_k04, 61.222017).
navstivil(1541, default_p12, default_k04, 61.222017).
navstivil(1542, default_p12, default_k04, 10.222036).
navstivil(1543, default_p12, default_k04, 10.222036).
navstivil(1544, default_p12, default_k04, 10.222036).
navstivil(1545, default_p12, default_k04, 85.222055).
navstivil(1546, default_p12, default_k04, 85.222055).
navstivil(1547, default_p12, default_k04, 85.222055).
navstivil(1548, default_p12, default_k04, 88.222077).
navstivil(1549, default_p12, default_k04, 88.222077).
navstivil(1550, default_p12, default_k04, 88.222077).
navstivil(1551, default_p12, default_k05, 4.222097).
navstivil(1552, default_p12, default_k05, 4.222097).
navstivil(1553, default_p12, default_k05, 4.222097).
navstivil(1554, default_p12, default_k05, 55.222117).
navstivil(1555, default_p12, default_k05, 55.222117).
navstivil(1556, default_p12, default_k05, 55.222117).
navstivil(1557, default_p12, default_k05, 38.222136).
navstivil(1558, default_p12, default_k05, 38.222136).
navstivil(1559, default_p12, default_k05, 38.222136).
navstivil(1560, default_p12, default_k05, 80.222154).
navstivil(1561, default_p12, default_k05, 80.222154).
navstivil(1562, default_p12, default_k05, 80.222154).
navstivil(1563, default_p12, default_k05, 55.222173).
navstivil(1564, default_p12, default_k05, 55.222173).
navstivil(1565, default_p12, default_k05, 55.222173).
navstivil(1566, default_p12, default_k05, 45.222192).
navstivil(1567, default_p12, default_k05, 45.222192).
navstivil(1568, default_p12, default_k05, 45.222192).
navstivil(1569, default_p12, default_k05, 41.22221).
navstivil(1570, default_p12, default_k05, 41.22221).
navstivil(1571, default_p12, default_k05, 41.22221).
navstivil(1572, default_p12, default_k05, 80.222229).
navstivil(1573, default_p12, default_k05, 80.222229).
navstivil(1574, default_p12, default_k05, 80.222229).
navstivil(1575, default_p12, default_k05, 40.222248).
navstivil(1576, default_p12, default_k05, 40.222248).
navstivil(1577, default_p12, default_k05, 40.222248).
navstivil(1578, default_p12, default_k05, 50.222269).
navstivil(1579, default_p12, default_k05, 50.222269).
navstivil(1580, default_p12, default_k05, 50.222269).
navstivil(1581, default_p12, default_k05, 41.222288).
navstivil(1582, default_p12, default_k05, 41.222288).
navstivil(1583, default_p12, default_k05, 41.222288).
navstivil(1584, default_p12, default_k06, 12.222307).
navstivil(1585, default_p12, default_k06, 12.222307).
navstivil(1586, default_p12, default_k06, 12.222307).
navstivil(1587, default_p12, default_k06, 42.222327).
navstivil(1588, default_p12, default_k06, 42.222327).
navstivil(1589, default_p12, default_k06, 42.222327).
navstivil(1590, default_p12, default_k06, 46.22235).
navstivil(1591, default_p12, default_k06, 46.22235).
navstivil(1592, default_p12, default_k06, 46.22235).
navstivil(1593, default_p12, default_k06, 44.22237).
navstivil(1594, default_p12, default_k06, 44.22237).
navstivil(1595, default_p12, default_k06, 44.22237).
navstivil(1596, default_p12, default_k06, 51.222389).
navstivil(1597, default_p12, default_k06, 51.222389).
navstivil(1598, default_p12, default_k06, 51.222389).
navstivil(1599, default_p12, default_k06, 49.222409).
navstivil(1600, default_p12, default_k06, 49.222409).
navstivil(1601, default_p12, default_k06, 49.222409).
navstivil(1602, default_p12, default_k06, 96.222428).
navstivil(1603, default_p12, default_k06, 96.222428).
navstivil(1604, default_p12, default_k06, 96.222428).
navstivil(1605, default_p12, default_k06, 44.222447).
navstivil(1606, default_p12, default_k06, 44.222447).
navstivil(1607, default_p12, default_k06, 44.222447).
navstivil(1608, default_p12, default_k06, 58.222465).
navstivil(1609, default_p12, default_k06, 58.222465).
navstivil(1610, default_p12, default_k06, 58.222465).
navstivil(1611, default_p12, default_k06, 58.222484).
navstivil(1612, default_p12, default_k06, 58.222484).
navstivil(1613, default_p12, default_k06, 58.222484).
navstivil(1614, default_p12, default_k06, 34.222503).
navstivil(1615, default_p12, default_k06, 34.222503).
navstivil(1616, default_p12, default_k06, 34.222503).
navstivil(1617, default_p12, default_k07, 20.222522).
navstivil(1618, default_p12, default_k07, 20.222522).
navstivil(1619, default_p12, default_k07, 20.222522).
navstivil(1620, default_p12, default_k07, 5.222541).
navstivil(1621, default_p12, default_k07, 5.222541).
navstivil(1622, default_p12, default_k07, 5.222541).
navstivil(1623, default_p12, default_k07, 8.222561).
navstivil(1624, default_p12, default_k07, 8.222561).
navstivil(1625, default_p12, default_k07, 8.222561).
navstivil(1626, default_p12, default_k07, 9.222582).
navstivil(1627, default_p12, default_k07, 9.222582).
navstivil(1628, default_p12, default_k07, 9.222582).
navstivil(1629, default_p12, default_k07, 70.2226).
navstivil(1630, default_p12, default_k07, 70.2226).
navstivil(1631, default_p12, default_k07, 70.2226).
navstivil(1632, default_p12, default_k07, 7.222627).
navstivil(1633, default_p12, default_k07, 7.222627).
navstivil(1634, default_p12, default_k07, 7.222627).
navstivil(1635, default_p12, default_k07, 8.222647).
navstivil(1636, default_p12, default_k07, 8.222647).
navstivil(1637, default_p12, default_k07, 8.222647).
navstivil(1638, default_p12, default_k07, 4.222666).
navstivil(1639, default_p12, default_k07, 4.222666).
navstivil(1640, default_p12, default_k07, 4.222666).
navstivil(1641, default_p12, default_k07, 81.222685).
navstivil(1642, default_p12, default_k07, 81.222685).
navstivil(1643, default_p12, default_k07, 81.222685).
navstivil(1644, default_p12, default_k07, 97.222704).
navstivil(1645, default_p12, default_k07, 97.222704).
navstivil(1646, default_p12, default_k07, 97.222704).
navstivil(1647, default_p12, default_k07, 47.222724).
navstivil(1648, default_p12, default_k07, 47.222724).
navstivil(1649, default_p12, default_k07, 47.222724).
navstivil(1650, default_p12, default_k08, 79.222744).
navstivil(1651, default_p12, default_k08, 79.222744).
navstivil(1652, default_p12, default_k08, 79.222744).
navstivil(1653, default_p12, default_k08, 29.222764).
navstivil(1654, default_p12, default_k08, 29.222764).
navstivil(1655, default_p12, default_k08, 29.222764).
navstivil(1656, default_p12, default_k08, 13.222782).
navstivil(1657, default_p12, default_k08, 13.222782).
navstivil(1658, default_p12, default_k08, 13.222782).
navstivil(1659, default_p12, default_k08, 16.222802).
navstivil(1660, default_p12, default_k08, 16.222802).
navstivil(1661, default_p12, default_k08, 16.222802).
navstivil(1662, default_p12, default_k08, 5.222835).
navstivil(1663, default_p12, default_k08, 5.222835).
navstivil(1664, default_p12, default_k08, 5.222835).
navstivil(1665, default_p12, default_k08, 51.222871).
navstivil(1666, default_p12, default_k08, 51.222871).
navstivil(1667, default_p12, default_k08, 51.222871).
navstivil(1668, default_p12, default_k08, 80.222893).
navstivil(1669, default_p12, default_k08, 80.222893).
navstivil(1670, default_p12, default_k08, 80.222893).
navstivil(1671, default_p12, default_k08, 69.222915).
navstivil(1672, default_p12, default_k08, 69.222915).
navstivil(1673, default_p12, default_k08, 69.222915).
navstivil(1674, default_p12, default_k08, 57.222956).
navstivil(1675, default_p12, default_k08, 57.222956).
navstivil(1676, default_p12, default_k08, 57.222956).
navstivil(1677, default_p12, default_k08, 12.222983).
navstivil(1678, default_p12, default_k08, 12.222983).
navstivil(1679, default_p12, default_k08, 12.222983).
navstivil(1680, default_p12, default_k08, 98.223003).
navstivil(1681, default_p12, default_k08, 98.223003).
navstivil(1682, default_p12, default_k08, 98.223003).
navstivil(1683, default_p12, default_k09, 50.223024).
navstivil(1684, default_p12, default_k09, 50.223024).
navstivil(1685, default_p12, default_k09, 50.223024).
navstivil(1686, default_p12, default_k09, 77.223044).
navstivil(1687, default_p12, default_k09, 77.223044).
navstivil(1688, default_p12, default_k09, 77.223044).
navstivil(1689, default_p12, default_k09, 45.223065).
navstivil(1690, default_p12, default_k09, 45.223065).
navstivil(1691, default_p12, default_k09, 45.223065).
navstivil(1692, default_p12, default_k09, 66.223095).
navstivil(1693, default_p12, default_k09, 66.223095).
navstivil(1694, default_p12, default_k09, 66.223095).
navstivil(1695, default_p12, default_k09, 5.223137).
navstivil(1696, default_p12, default_k09, 5.223137).
navstivil(1697, default_p12, default_k09, 5.223137).
navstivil(1698, default_p12, default_k09, 66.223172).
navstivil(1699, default_p12, default_k09, 66.223172).
navstivil(1700, default_p12, default_k09, 66.223172).
navstivil(1701, default_p12, default_k09, 45.223204).
navstivil(1702, default_p12, default_k09, 45.223204).
navstivil(1703, default_p12, default_k09, 45.223204).
navstivil(1704, default_p12, default_k09, 100.223233).
navstivil(1705, default_p12, default_k09, 100.223233).
navstivil(1706, default_p12, default_k09, 100.223233).
navstivil(1707, default_p12, default_k09, 80.223256).
navstivil(1708, default_p12, default_k09, 80.223256).
navstivil(1709, default_p12, default_k09, 80.223256).
navstivil(1710, default_p12, default_k09, 32.223276).
navstivil(1711, default_p12, default_k09, 32.223276).
navstivil(1712, default_p12, default_k09, 32.223276).
navstivil(1713, default_p12, default_k09, 65.223295).
navstivil(1714, default_p12, default_k09, 65.223295).
navstivil(1715, default_p12, default_k09, 65.223295).
navstivil(1716, default_p12, default_k10, 79.223324).
navstivil(1717, default_p12, default_k10, 79.223324).
navstivil(1718, default_p12, default_k10, 79.223324).
navstivil(1719, default_p12, default_k10, 72.223354).
navstivil(1720, default_p12, default_k10, 72.223354).
navstivil(1721, default_p12, default_k10, 72.223354).
navstivil(1722, default_p12, default_k10, 30.223388).
navstivil(1723, default_p12, default_k10, 30.223388).
navstivil(1724, default_p12, default_k10, 30.223388).
navstivil(1725, default_p12, default_k10, 43.223421).
navstivil(1726, default_p12, default_k10, 43.223421).
navstivil(1727, default_p12, default_k10, 43.223421).
navstivil(1728, default_p12, default_k10, 27.223446).
navstivil(1729, default_p12, default_k10, 27.223446).
navstivil(1730, default_p12, default_k10, 27.223446).
navstivil(1731, default_p12, default_k10, 36.223466).
navstivil(1732, default_p12, default_k10, 36.223466).
navstivil(1733, default_p12, default_k10, 36.223466).
navstivil(1734, default_p12, default_k10, 100.223487).
navstivil(1735, default_p12, default_k10, 100.223487).
navstivil(1736, default_p12, default_k10, 100.223487).
navstivil(1737, default_p12, default_k10, 19.223507).
navstivil(1738, default_p12, default_k10, 19.223507).
navstivil(1739, default_p12, default_k10, 19.223507).
navstivil(1740, default_p12, default_k10, 8.223527).
navstivil(1741, default_p12, default_k10, 8.223527).
navstivil(1742, default_p12, default_k10, 8.223527).
navstivil(1743, default_p12, default_k10, 70.223553).
navstivil(1744, default_p12, default_k10, 70.223553).
navstivil(1745, default_p12, default_k10, 70.223553).
navstivil(1746, default_p12, default_k10, 27.223586).
navstivil(1747, default_p12, default_k10, 27.223586).
navstivil(1748, default_p12, default_k10, 27.223586).
navstivil(1749, default_p13, default_k01, 62.223623).
navstivil(1750, default_p13, default_k01, 62.223623).
navstivil(1751, default_p13, default_k01, 62.223623).
navstivil(1752, default_p13, default_k01, 31.223646).
navstivil(1753, default_p13, default_k01, 31.223646).
navstivil(1754, default_p13, default_k01, 31.223646).
navstivil(1755, default_p13, default_k01, 20.223678).
navstivil(1756, default_p13, default_k01, 20.223678).
navstivil(1757, default_p13, default_k01, 20.223678).
navstivil(1758, default_p13, default_k01, 11.223707).
navstivil(1759, default_p13, default_k01, 11.223707).
navstivil(1760, default_p13, default_k01, 11.223707).
navstivil(1761, default_p13, default_k01, 90.223728).
navstivil(1762, default_p13, default_k01, 90.223728).
navstivil(1763, default_p13, default_k01, 90.223728).
navstivil(1764, default_p13, default_k01, 29.223748).
navstivil(1765, default_p13, default_k01, 29.223748).
navstivil(1766, default_p13, default_k01, 29.223748).
navstivil(1767, default_p13, default_k01, 58.223768).
navstivil(1768, default_p13, default_k01, 58.223768).
navstivil(1769, default_p13, default_k01, 58.223768).
navstivil(1770, default_p13, default_k01, 3.223788).
navstivil(1771, default_p13, default_k01, 3.223788).
navstivil(1772, default_p13, default_k01, 3.223788).
navstivil(1773, default_p13, default_k01, 97.223807).
navstivil(1774, default_p13, default_k01, 97.223807).
navstivil(1775, default_p13, default_k01, 97.223807).
navstivil(1776, default_p13, default_k01, 35.223827).
navstivil(1777, default_p13, default_k01, 35.223827).
navstivil(1778, default_p13, default_k01, 35.223827).
navstivil(1779, default_p13, default_k01, 29.223846).
navstivil(1780, default_p13, default_k01, 29.223846).
navstivil(1781, default_p13, default_k01, 29.223846).
navstivil(1782, default_p13, default_k01, 83.223866).
navstivil(1783, default_p13, default_k01, 83.223866).
navstivil(1784, default_p13, default_k01, 83.223866).
navstivil(1785, default_p13, default_k02, 27.223891).
navstivil(1786, default_p13, default_k02, 27.223891).
navstivil(1787, default_p13, default_k02, 27.223891).
navstivil(1788, default_p13, default_k02, 1.223954).
navstivil(1789, default_p13, default_k02, 1.223954).
navstivil(1790, default_p13, default_k02, 1.223954).
navstivil(1791, default_p13, default_k02, 81.223995).
navstivil(1792, default_p13, default_k02, 81.223995).
navstivil(1793, default_p13, default_k02, 81.223995).
navstivil(1794, default_p13, default_k02, 15.224053).
navstivil(1795, default_p13, default_k02, 15.224053).
navstivil(1796, default_p13, default_k02, 15.224053).
navstivil(1797, default_p13, default_k02, 83.22409).
navstivil(1798, default_p13, default_k02, 83.22409).
navstivil(1799, default_p13, default_k02, 83.22409).
navstivil(1800, default_p13, default_k02, 5.224139).
navstivil(1801, default_p13, default_k02, 5.224139).
navstivil(1802, default_p13, default_k02, 5.224139).
navstivil(1803, default_p13, default_k02, 13.224166).
navstivil(1804, default_p13, default_k02, 13.224166).
navstivil(1805, default_p13, default_k02, 13.224166).
navstivil(1806, default_p13, default_k02, 52.224187).
navstivil(1807, default_p13, default_k02, 52.224187).
navstivil(1808, default_p13, default_k02, 52.224187).
navstivil(1809, default_p13, default_k02, 89.224206).
navstivil(1810, default_p13, default_k02, 89.224206).
navstivil(1811, default_p13, default_k02, 89.224206).
navstivil(1812, default_p13, default_k02, 20.224226).
navstivil(1813, default_p13, default_k02, 20.224226).
navstivil(1814, default_p13, default_k02, 20.224226).
navstivil(1815, default_p13, default_k02, 83.224246).
navstivil(1816, default_p13, default_k02, 83.224246).
navstivil(1817, default_p13, default_k02, 83.224246).
navstivil(1818, default_p13, default_k02, 5.224266).
navstivil(1819, default_p13, default_k02, 5.224266).
navstivil(1820, default_p13, default_k02, 5.224266).
navstivil(1821, default_p13, default_k03, 72.224286).
navstivil(1822, default_p13, default_k03, 72.224286).
navstivil(1823, default_p13, default_k03, 72.224286).
navstivil(1824, default_p13, default_k03, 80.224305).
navstivil(1825, default_p13, default_k03, 80.224305).
navstivil(1826, default_p13, default_k03, 80.224305).
navstivil(1827, default_p13, default_k03, 65.224324).
navstivil(1828, default_p13, default_k03, 65.224324).
navstivil(1829, default_p13, default_k03, 65.224324).
navstivil(1830, default_p13, default_k03, 58.224344).
navstivil(1831, default_p13, default_k03, 58.224344).
navstivil(1832, default_p13, default_k03, 58.224344).
navstivil(1833, default_p13, default_k03, 78.224363).
navstivil(1834, default_p13, default_k03, 78.224363).
navstivil(1835, default_p13, default_k03, 78.224363).
navstivil(1836, default_p13, default_k03, 79.224383).
navstivil(1837, default_p13, default_k03, 79.224383).
navstivil(1838, default_p13, default_k03, 79.224383).
navstivil(1839, default_p13, default_k03, 58.224402).
navstivil(1840, default_p13, default_k03, 58.224402).
navstivil(1841, default_p13, default_k03, 58.224402).
navstivil(1842, default_p13, default_k03, 50.224428).
navstivil(1843, default_p13, default_k03, 50.224428).
navstivil(1844, default_p13, default_k03, 50.224428).
navstivil(1845, default_p13, default_k03, 33.224446).
navstivil(1846, default_p13, default_k03, 33.224446).
navstivil(1847, default_p13, default_k03, 33.224446).
navstivil(1848, default_p13, default_k03, 73.224466).
navstivil(1849, default_p13, default_k03, 73.224466).
navstivil(1850, default_p13, default_k03, 73.224466).
navstivil(1851, default_p13, default_k03, 21.224485).
navstivil(1852, default_p13, default_k03, 21.224485).
navstivil(1853, default_p13, default_k03, 21.224485).
navstivil(1854, default_p13, default_k03, 82.224504).
navstivil(1855, default_p13, default_k03, 82.224504).
navstivil(1856, default_p13, default_k03, 82.224504).
navstivil(1857, default_p13, default_k04, 55.224524).
navstivil(1858, default_p13, default_k04, 55.224524).
navstivil(1859, default_p13, default_k04, 55.224524).
navstivil(1860, default_p13, default_k04, 96.224645).
navstivil(1861, default_p13, default_k04, 96.224645).
navstivil(1862, default_p13, default_k04, 96.224645).
navstivil(1863, default_p13, default_k04, 58.224666).
navstivil(1864, default_p13, default_k04, 58.224666).
navstivil(1865, default_p13, default_k04, 58.224666).
navstivil(1866, default_p13, default_k04, 68.224685).
navstivil(1867, default_p13, default_k04, 68.224685).
navstivil(1868, default_p13, default_k04, 68.224685).
navstivil(1869, default_p13, default_k04, 2.224703).
navstivil(1870, default_p13, default_k04, 2.224703).
navstivil(1871, default_p13, default_k04, 2.224703).
navstivil(1872, default_p13, default_k04, 35.224723).
navstivil(1873, default_p13, default_k04, 35.224723).
navstivil(1874, default_p13, default_k04, 35.224723).
navstivil(1875, default_p13, default_k04, 89.224742).
navstivil(1876, default_p13, default_k04, 89.224742).
navstivil(1877, default_p13, default_k04, 89.224742).
navstivil(1878, default_p13, default_k04, 50.224761).
navstivil(1879, default_p13, default_k04, 50.224761).
navstivil(1880, default_p13, default_k04, 50.224761).
navstivil(1881, default_p13, default_k04, 59.22478).
navstivil(1882, default_p13, default_k04, 59.22478).
navstivil(1883, default_p13, default_k04, 59.22478).
navstivil(1884, default_p13, default_k04, 83.224804).
navstivil(1885, default_p13, default_k04, 83.224804).
navstivil(1886, default_p13, default_k04, 83.224804).
navstivil(1887, default_p13, default_k04, 40.224824).
navstivil(1888, default_p13, default_k04, 40.224824).
navstivil(1889, default_p13, default_k04, 40.224824).
navstivil(1890, default_p13, default_k04, 81.224843).
navstivil(1891, default_p13, default_k04, 81.224843).
navstivil(1892, default_p13, default_k04, 81.224843).
navstivil(1893, default_p13, default_k05, 39.224864).
navstivil(1894, default_p13, default_k05, 39.224864).
navstivil(1895, default_p13, default_k05, 39.224864).
navstivil(1896, default_p13, default_k05, 6.224883).
navstivil(1897, default_p13, default_k05, 6.224883).
navstivil(1898, default_p13, default_k05, 6.224883).
navstivil(1899, default_p13, default_k05, 29.224903).
navstivil(1900, default_p13, default_k05, 29.224903).
navstivil(1901, default_p13, default_k05, 29.224903).
navstivil(1902, default_p13, default_k05, 93.224923).
navstivil(1903, default_p13, default_k05, 93.224923).
navstivil(1904, default_p13, default_k05, 93.224923).
navstivil(1905, default_p13, default_k05, 46.224942).
navstivil(1906, default_p13, default_k05, 46.224942).
navstivil(1907, default_p13, default_k05, 46.224942).
navstivil(1908, default_p13, default_k05, 9.224961).
navstivil(1909, default_p13, default_k05, 9.224961).
navstivil(1910, default_p13, default_k05, 9.224961).
navstivil(1911, default_p13, default_k05, 27.224979).
navstivil(1912, default_p13, default_k05, 27.224979).
navstivil(1913, default_p13, default_k05, 27.224979).
navstivil(1914, default_p13, default_k05, 2.224998).
navstivil(1915, default_p13, default_k05, 2.224998).
navstivil(1916, default_p13, default_k05, 2.224998).
navstivil(1917, default_p13, default_k05, 70.225018).
navstivil(1918, default_p13, default_k05, 70.225018).
navstivil(1919, default_p13, default_k05, 70.225018).
navstivil(1920, default_p13, default_k05, 30.225038).
navstivil(1921, default_p13, default_k05, 30.225038).
navstivil(1922, default_p13, default_k05, 30.225038).
navstivil(1923, default_p13, default_k05, 44.225056).
navstivil(1924, default_p13, default_k05, 44.225056).
navstivil(1925, default_p13, default_k05, 44.225056).
navstivil(1926, default_p13, default_k05, 53.22508).
navstivil(1927, default_p13, default_k05, 53.22508).
navstivil(1928, default_p13, default_k05, 53.22508).
navstivil(1929, default_p13, default_k06, 53.225099).
navstivil(1930, default_p13, default_k06, 53.225099).
navstivil(1931, default_p13, default_k06, 53.225099).
navstivil(1932, default_p13, default_k06, 37.225121).
navstivil(1933, default_p13, default_k06, 37.225121).
navstivil(1934, default_p13, default_k06, 37.225121).
navstivil(1935, default_p13, default_k06, 77.22514).
navstivil(1936, default_p13, default_k06, 77.22514).
navstivil(1937, default_p13, default_k06, 77.22514).
navstivil(1938, default_p13, default_k06, 98.225159).
navstivil(1939, default_p13, default_k06, 98.225159).
navstivil(1940, default_p13, default_k06, 98.225159).
navstivil(1941, default_p13, default_k06, 93.225178).
navstivil(1942, default_p13, default_k06, 93.225178).
navstivil(1943, default_p13, default_k06, 93.225178).
navstivil(1944, default_p13, default_k06, 66.225198).
navstivil(1945, default_p13, default_k06, 66.225198).
navstivil(1946, default_p13, default_k06, 66.225198).
navstivil(1947, default_p13, default_k06, 44.225217).
navstivil(1948, default_p13, default_k06, 44.225217).
navstivil(1949, default_p13, default_k06, 44.225217).
navstivil(1950, default_p13, default_k06, 54.225237).
navstivil(1951, default_p13, default_k06, 54.225237).
navstivil(1952, default_p13, default_k06, 54.225237).
navstivil(1953, default_p13, default_k06, 49.225256).
navstivil(1954, default_p13, default_k06, 49.225256).
navstivil(1955, default_p13, default_k06, 49.225256).
navstivil(1956, default_p13, default_k06, 97.225276).
navstivil(1957, default_p13, default_k06, 97.225276).
navstivil(1958, default_p13, default_k06, 97.225276).
navstivil(1959, default_p13, default_k06, 28.225295).
navstivil(1960, default_p13, default_k06, 28.225295).
navstivil(1961, default_p13, default_k06, 28.225295).
navstivil(1962, default_p13, default_k06, 29.225314).
navstivil(1963, default_p13, default_k06, 29.225314).
navstivil(1964, default_p13, default_k06, 29.225314).
navstivil(1965, default_p13, default_k07, 12.225334).
navstivil(1966, default_p13, default_k07, 12.225334).
navstivil(1967, default_p13, default_k07, 12.225334).
navstivil(1968, default_p13, default_k07, 62.225358).
navstivil(1969, default_p13, default_k07, 62.225358).
navstivil(1970, default_p13, default_k07, 62.225358).
navstivil(1971, default_p13, default_k07, 5.225378).
navstivil(1972, default_p13, default_k07, 5.225378).
navstivil(1973, default_p13, default_k07, 5.225378).
navstivil(1974, default_p13, default_k07, 85.225397).
navstivil(1975, default_p13, default_k07, 85.225397).
navstivil(1976, default_p13, default_k07, 85.225397).
navstivil(1977, default_p13, default_k07, 73.225416).
navstivil(1978, default_p13, default_k07, 73.225416).
navstivil(1979, default_p13, default_k07, 73.225416).
navstivil(1980, default_p13, default_k07, 56.225435).
navstivil(1981, default_p13, default_k07, 56.225435).
navstivil(1982, default_p13, default_k07, 56.225435).
navstivil(1983, default_p13, default_k07, 42.225455).
navstivil(1984, default_p13, default_k07, 42.225455).
navstivil(1985, default_p13, default_k07, 42.225455).
navstivil(1986, default_p13, default_k07, 12.225474).
navstivil(1987, default_p13, default_k07, 12.225474).
navstivil(1988, default_p13, default_k07, 12.225474).
navstivil(1989, default_p13, default_k07, 9.225493).
navstivil(1990, default_p13, default_k07, 9.225493).
navstivil(1991, default_p13, default_k07, 9.225493).
navstivil(1992, default_p13, default_k07, 75.225527).
navstivil(1993, default_p13, default_k07, 75.225527).
navstivil(1994, default_p13, default_k07, 75.225527).
navstivil(1995, default_p13, default_k07, 49.225559).
navstivil(1996, default_p13, default_k07, 49.225559).
navstivil(1997, default_p13, default_k07, 49.225559).
navstivil(1998, default_p13, default_k07, 87.225593).
navstivil(1999, default_p13, default_k07, 87.225593).
navstivil(2000, default_p13, default_k07, 87.225593).
navstivil(2001, default_p13, default_k08, 23.22563).
navstivil(2002, default_p13, default_k08, 23.22563).
navstivil(2003, default_p13, default_k08, 23.22563).
navstivil(2004, default_p13, default_k08, 84.225665).
navstivil(2005, default_p13, default_k08, 84.225665).
navstivil(2006, default_p13, default_k08, 84.225665).
navstivil(2007, default_p13, default_k08, 64.225705).
navstivil(2008, default_p13, default_k08, 64.225705).
navstivil(2009, default_p13, default_k08, 64.225705).
navstivil(2010, default_p13, default_k08, 68.225751).
navstivil(2011, default_p13, default_k08, 68.225751).
navstivil(2012, default_p13, default_k08, 68.225751).
navstivil(2013, default_p13, default_k08, 70.225783).
navstivil(2014, default_p13, default_k08, 70.225783).
navstivil(2015, default_p13, default_k08, 70.225783).
navstivil(2016, default_p13, default_k08, 90.22585).
navstivil(2017, default_p13, default_k08, 90.22585).
navstivil(2018, default_p13, default_k08, 90.22585).
navstivil(2019, default_p13, default_k08, 15.22588).
navstivil(2020, default_p13, default_k08, 15.22588).
navstivil(2021, default_p13, default_k08, 15.22588).
navstivil(2022, default_p13, default_k08, 68.225902).
navstivil(2023, default_p13, default_k08, 68.225902).
navstivil(2024, default_p13, default_k08, 68.225902).
navstivil(2025, default_p13, default_k08, 52.225922).
navstivil(2026, default_p13, default_k08, 52.225922).
navstivil(2027, default_p13, default_k08, 52.225922).
navstivil(2028, default_p13, default_k08, 93.225943).
navstivil(2029, default_p13, default_k08, 93.225943).
navstivil(2030, default_p13, default_k08, 93.225943).
navstivil(2031, default_p13, default_k08, 55.225962).
navstivil(2032, default_p13, default_k08, 55.225962).
navstivil(2033, default_p13, default_k08, 55.225962).
navstivil(2034, default_p13, default_k08, 32.225982).
navstivil(2035, default_p13, default_k08, 32.225982).
navstivil(2036, default_p13, default_k08, 32.225982).
navstivil(2037, default_p13, default_k09, 12.226005).
navstivil(2038, default_p13, default_k09, 12.226005).
navstivil(2039, default_p13, default_k09, 12.226005).
navstivil(2040, default_p13, default_k09, 25.226024).
navstivil(2041, default_p13, default_k09, 25.226024).
navstivil(2042, default_p13, default_k09, 25.226024).
navstivil(2043, default_p13, default_k09, 61.226043).
navstivil(2044, default_p13, default_k09, 61.226043).
navstivil(2045, default_p13, default_k09, 61.226043).
navstivil(2046, default_p13, default_k09, 17.226063).
navstivil(2047, default_p13, default_k09, 17.226063).
navstivil(2048, default_p13, default_k09, 17.226063).
navstivil(2049, default_p13, default_k09, 98.226083).
navstivil(2050, default_p13, default_k09, 98.226083).
navstivil(2051, default_p13, default_k09, 98.226083).
navstivil(2052, default_p13, default_k09, 15.226109).
navstivil(2053, default_p13, default_k09, 15.226109).
navstivil(2054, default_p13, default_k09, 15.226109).
navstivil(2055, default_p13, default_k09, 40.226128).
navstivil(2056, default_p13, default_k09, 40.226128).
navstivil(2057, default_p13, default_k09, 40.226128).
navstivil(2058, default_p13, default_k09, 98.226147).
navstivil(2059, default_p13, default_k09, 98.226147).
navstivil(2060, default_p13, default_k09, 98.226147).
navstivil(2061, default_p13, default_k09, 23.226166).
navstivil(2062, default_p13, default_k09, 23.226166).
navstivil(2063, default_p13, default_k09, 23.226166).
navstivil(2064, default_p13, default_k09, 34.226187).
navstivil(2065, default_p13, default_k09, 34.226187).
navstivil(2066, default_p13, default_k09, 34.226187).
navstivil(2067, default_p13, default_k09, 32.226205).
navstivil(2068, default_p13, default_k09, 32.226205).
navstivil(2069, default_p13, default_k09, 32.226205).
navstivil(2070, default_p13, default_k09, 35.226224).
navstivil(2071, default_p13, default_k09, 35.226224).
navstivil(2072, default_p13, default_k09, 35.226224).
navstivil(2073, default_p13, default_k10, 47.226244).
navstivil(2074, default_p13, default_k10, 47.226244).
navstivil(2075, default_p13, default_k10, 47.226244).
navstivil(2076, default_p13, default_k10, 73.226263).
navstivil(2077, default_p13, default_k10, 73.226263).
navstivil(2078, default_p13, default_k10, 73.226263).
navstivil(2079, default_p13, default_k10, 55.226283).
navstivil(2080, default_p13, default_k10, 55.226283).
navstivil(2081, default_p13, default_k10, 55.226283).
navstivil(2082, default_p13, default_k10, 96.226302).
navstivil(2083, default_p13, default_k10, 96.226302).
navstivil(2084, default_p13, default_k10, 96.226302).
navstivil(2085, default_p13, default_k10, 16.226322).
navstivil(2086, default_p13, default_k10, 16.226322).
navstivil(2087, default_p13, default_k10, 16.226322).
navstivil(2088, default_p13, default_k10, 66.226341).
navstivil(2089, default_p13, default_k10, 66.226341).
navstivil(2090, default_p13, default_k10, 66.226341).
navstivil(2091, default_p13, default_k10, 39.22636).
navstivil(2092, default_p13, default_k10, 39.22636).
navstivil(2093, default_p13, default_k10, 39.22636).
navstivil(2094, default_p13, default_k10, 19.226401).
navstivil(2095, default_p13, default_k10, 19.226401).
navstivil(2096, default_p13, default_k10, 19.226401).
navstivil(2097, default_p13, default_k10, 88.226421).
navstivil(2098, default_p13, default_k10, 88.226421).
navstivil(2099, default_p13, default_k10, 88.226421).
navstivil(2100, default_p13, default_k10, 5.226441).
navstivil(2101, default_p13, default_k10, 5.226441).
navstivil(2102, default_p13, default_k10, 5.226441).
navstivil(2103, default_p13, default_k10, 8.226476).
navstivil(2104, default_p13, default_k10, 8.226476).
navstivil(2105, default_p13, default_k10, 8.226476).
navstivil(2106, default_p13, default_k10, 40.226497).
navstivil(2107, default_p13, default_k10, 40.226497).
navstivil(2108, default_p13, default_k10, 40.226497).
navstivil(2109, default_p14, default_k01, 75.226518).
navstivil(2110, default_p14, default_k01, 75.226518).
navstivil(2111, default_p14, default_k01, 75.226518).
navstivil(2112, default_p14, default_k01, 41.226538).
navstivil(2113, default_p14, default_k01, 41.226538).
navstivil(2114, default_p14, default_k01, 41.226538).
navstivil(2115, default_p14, default_k01, 13.226557).
navstivil(2116, default_p14, default_k01, 13.226557).
navstivil(2117, default_p14, default_k01, 13.226557).
navstivil(2118, default_p14, default_k01, 24.226578).
navstivil(2119, default_p14, default_k01, 24.226578).
navstivil(2120, default_p14, default_k01, 24.226578).
navstivil(2121, default_p14, default_k01, 10.226596).
navstivil(2122, default_p14, default_k01, 10.226596).
navstivil(2123, default_p14, default_k01, 10.226596).
navstivil(2124, default_p14, default_k01, 6.226616).
navstivil(2125, default_p14, default_k01, 6.226616).
navstivil(2126, default_p14, default_k01, 6.226616).
navstivil(2127, default_p14, default_k01, 14.226635).
navstivil(2128, default_p14, default_k01, 14.226635).
navstivil(2129, default_p14, default_k01, 14.226635).
navstivil(2130, default_p14, default_k01, 89.226655).
navstivil(2131, default_p14, default_k01, 89.226655).
navstivil(2132, default_p14, default_k01, 89.226655).
navstivil(2133, default_p14, default_k01, 51.226674).
navstivil(2134, default_p14, default_k01, 51.226674).
navstivil(2135, default_p14, default_k01, 51.226674).
navstivil(2136, default_p14, default_k01, 96.226697).
navstivil(2137, default_p14, default_k01, 96.226697).
navstivil(2138, default_p14, default_k01, 96.226697).
navstivil(2139, default_p14, default_k01, 42.226716).
navstivil(2140, default_p14, default_k01, 42.226716).
navstivil(2141, default_p14, default_k01, 42.226716).
navstivil(2142, default_p14, default_k01, 61.226735).
navstivil(2143, default_p14, default_k01, 61.226735).
navstivil(2144, default_p14, default_k01, 61.226735).
navstivil(2145, default_p14, default_k01, 51.226754).
navstivil(2146, default_p14, default_k01, 51.226754).
navstivil(2147, default_p14, default_k01, 51.226754).
navstivil(2148, default_p14, default_k02, 30.226775).
navstivil(2149, default_p14, default_k02, 30.226775).
navstivil(2150, default_p14, default_k02, 30.226775).
navstivil(2151, default_p14, default_k02, 67.226793).
navstivil(2152, default_p14, default_k02, 67.226793).
navstivil(2153, default_p14, default_k02, 67.226793).
navstivil(2154, default_p14, default_k02, 80.226812).
navstivil(2155, default_p14, default_k02, 80.226812).
navstivil(2156, default_p14, default_k02, 80.226812).
navstivil(2157, default_p14, default_k02, 25.226831).
navstivil(2158, default_p14, default_k02, 25.226831).
navstivil(2159, default_p14, default_k02, 25.226831).
navstivil(2160, default_p14, default_k02, 25.22685).
navstivil(2161, default_p14, default_k02, 25.22685).
navstivil(2162, default_p14, default_k02, 25.22685).
navstivil(2163, default_p14, default_k02, 8.226869).
navstivil(2164, default_p14, default_k02, 8.226869).
navstivil(2165, default_p14, default_k02, 8.226869).
navstivil(2166, default_p14, default_k02, 4.226888).
navstivil(2167, default_p14, default_k02, 4.226888).
navstivil(2168, default_p14, default_k02, 4.226888).
navstivil(2169, default_p14, default_k02, 35.226907).
navstivil(2170, default_p14, default_k02, 35.226907).
navstivil(2171, default_p14, default_k02, 35.226907).
navstivil(2172, default_p14, default_k02, 82.226925).
navstivil(2173, default_p14, default_k02, 82.226925).
navstivil(2174, default_p14, default_k02, 82.226925).
navstivil(2175, default_p14, default_k02, 75.226944).
navstivil(2176, default_p14, default_k02, 75.226944).
navstivil(2177, default_p14, default_k02, 75.226944).
navstivil(2178, default_p14, default_k02, 9.226968).
navstivil(2179, default_p14, default_k02, 9.226968).
navstivil(2180, default_p14, default_k02, 9.226968).
navstivil(2181, default_p14, default_k02, 53.226987).
navstivil(2182, default_p14, default_k02, 53.226987).
navstivil(2183, default_p14, default_k02, 53.226987).
navstivil(2184, default_p14, default_k02, 20.227006).
navstivil(2185, default_p14, default_k02, 20.227006).
navstivil(2186, default_p14, default_k02, 20.227006).
navstivil(2187, default_p14, default_k03, 12.227025).
navstivil(2188, default_p14, default_k03, 12.227025).
navstivil(2189, default_p14, default_k03, 12.227025).
navstivil(2190, default_p14, default_k03, 36.227044).
navstivil(2191, default_p14, default_k03, 36.227044).
navstivil(2192, default_p14, default_k03, 36.227044).
navstivil(2193, default_p14, default_k03, 56.227063).
navstivil(2194, default_p14, default_k03, 56.227063).
navstivil(2195, default_p14, default_k03, 56.227063).
navstivil(2196, default_p14, default_k03, 99.227083).
navstivil(2197, default_p14, default_k03, 99.227083).
navstivil(2198, default_p14, default_k03, 99.227083).
navstivil(2199, default_p14, default_k03, 8.227103).
navstivil(2200, default_p14, default_k03, 8.227103).
navstivil(2201, default_p14, default_k03, 8.227103).
navstivil(2202, default_p14, default_k03, 91.227135).
navstivil(2203, default_p14, default_k03, 91.227135).
navstivil(2204, default_p14, default_k03, 91.227135).
navstivil(2205, default_p14, default_k03, 76.227156).
navstivil(2206, default_p14, default_k03, 76.227156).
navstivil(2207, default_p14, default_k03, 76.227156).
navstivil(2208, default_p14, default_k03, 33.227171).
navstivil(2209, default_p14, default_k03, 33.227171).
navstivil(2210, default_p14, default_k03, 33.227171).
navstivil(2211, default_p14, default_k03, 93.227186).
navstivil(2212, default_p14, default_k03, 93.227186).
navstivil(2213, default_p14, default_k03, 93.227186).
navstivil(2214, default_p14, default_k03, 92.227201).
navstivil(2215, default_p14, default_k03, 92.227201).
navstivil(2216, default_p14, default_k03, 92.227201).
navstivil(2217, default_p14, default_k03, 70.227216).
navstivil(2218, default_p14, default_k03, 70.227216).
navstivil(2219, default_p14, default_k03, 70.227216).
navstivil(2220, default_p14, default_k03, 96.227234).
navstivil(2221, default_p14, default_k03, 96.227234).
navstivil(2222, default_p14, default_k03, 96.227234).
navstivil(2223, default_p14, default_k03, 86.227248).
navstivil(2224, default_p14, default_k03, 86.227248).
navstivil(2225, default_p14, default_k03, 86.227248).
navstivil(2226, default_p14, default_k04, 1.227263).
navstivil(2227, default_p14, default_k04, 1.227263).
navstivil(2228, default_p14, default_k04, 1.227263).
navstivil(2229, default_p14, default_k04, 12.227277).
navstivil(2230, default_p14, default_k04, 12.227277).
navstivil(2231, default_p14, default_k04, 12.227277).
navstivil(2232, default_p14, default_k04, 28.227292).
navstivil(2233, default_p14, default_k04, 28.227292).
navstivil(2234, default_p14, default_k04, 28.227292).
navstivil(2235, default_p14, default_k04, 28.227306).
navstivil(2236, default_p14, default_k04, 28.227306).
navstivil(2237, default_p14, default_k04, 28.227306).
navstivil(2238, default_p14, default_k04, 7.227321).
navstivil(2239, default_p14, default_k04, 7.227321).
navstivil(2240, default_p14, default_k04, 7.227321).
navstivil(2241, default_p14, default_k04, 99.227336).
navstivil(2242, default_p14, default_k04, 99.227336).
navstivil(2243, default_p14, default_k04, 99.227336).
navstivil(2244, default_p14, default_k04, 37.22735).
navstivil(2245, default_p14, default_k04, 37.22735).
navstivil(2246, default_p14, default_k04, 37.22735).
navstivil(2247, default_p14, default_k04, 75.227365).
navstivil(2248, default_p14, default_k04, 75.227365).
navstivil(2249, default_p14, default_k04, 75.227365).
navstivil(2250, default_p14, default_k04, 91.227379).
navstivil(2251, default_p14, default_k04, 91.227379).
navstivil(2252, default_p14, default_k04, 91.227379).
navstivil(2253, default_p14, default_k04, 49.227393).
navstivil(2254, default_p14, default_k04, 49.227393).
navstivil(2255, default_p14, default_k04, 49.227393).
navstivil(2256, default_p14, default_k04, 59.227408).
navstivil(2257, default_p14, default_k04, 59.227408).
navstivil(2258, default_p14, default_k04, 59.227408).
navstivil(2259, default_p14, default_k04, 36.227423).
navstivil(2260, default_p14, default_k04, 36.227423).
navstivil(2261, default_p14, default_k04, 36.227423).
navstivil(2262, default_p14, default_k04, 97.227441).
navstivil(2263, default_p14, default_k04, 97.227441).
navstivil(2264, default_p14, default_k04, 97.227441).
navstivil(2265, default_p14, default_k05, 57.227456).
navstivil(2266, default_p14, default_k05, 57.227456).
navstivil(2267, default_p14, default_k05, 57.227456).
navstivil(2268, default_p14, default_k05, 58.227471).
navstivil(2269, default_p14, default_k05, 58.227471).
navstivil(2270, default_p14, default_k05, 58.227471).
navstivil(2271, default_p14, default_k05, 81.227485).
navstivil(2272, default_p14, default_k05, 81.227485).
navstivil(2273, default_p14, default_k05, 81.227485).
navstivil(2274, default_p14, default_k05, 44.227499).
navstivil(2275, default_p14, default_k05, 44.227499).
navstivil(2276, default_p14, default_k05, 44.227499).
navstivil(2277, default_p14, default_k05, 79.227513).
navstivil(2278, default_p14, default_k05, 79.227513).
navstivil(2279, default_p14, default_k05, 79.227513).
navstivil(2280, default_p14, default_k05, 28.227528).
navstivil(2281, default_p14, default_k05, 28.227528).
navstivil(2282, default_p14, default_k05, 28.227528).
navstivil(2283, default_p14, default_k05, 56.227542).
navstivil(2284, default_p14, default_k05, 56.227542).
navstivil(2285, default_p14, default_k05, 56.227542).
navstivil(2286, default_p14, default_k05, 79.227556).
navstivil(2287, default_p14, default_k05, 79.227556).
navstivil(2288, default_p14, default_k05, 79.227556).
navstivil(2289, default_p14, default_k05, 64.227571).
navstivil(2290, default_p14, default_k05, 64.227571).
navstivil(2291, default_p14, default_k05, 64.227571).
navstivil(2292, default_p14, default_k05, 85.227585).
navstivil(2293, default_p14, default_k05, 85.227585).
navstivil(2294, default_p14, default_k05, 85.227585).
navstivil(2295, default_p14, default_k05, 62.2276).
navstivil(2296, default_p14, default_k05, 62.2276).
navstivil(2297, default_p14, default_k05, 62.2276).
navstivil(2298, default_p14, default_k05, 34.227614).
navstivil(2299, default_p14, default_k05, 34.227614).
navstivil(2300, default_p14, default_k05, 34.227614).
navstivil(2301, default_p14, default_k05, 67.227629).
navstivil(2302, default_p14, default_k05, 67.227629).
navstivil(2303, default_p14, default_k05, 67.227629).
navstivil(2304, default_p14, default_k06, 70.227649).
navstivil(2305, default_p14, default_k06, 70.227649).
navstivil(2306, default_p14, default_k06, 70.227649).
navstivil(2307, default_p14, default_k06, 30.227663).
navstivil(2308, default_p14, default_k06, 30.227663).
navstivil(2309, default_p14, default_k06, 30.227663).
navstivil(2310, default_p14, default_k06, 32.227678).
navstivil(2311, default_p14, default_k06, 32.227678).
navstivil(2312, default_p14, default_k06, 32.227678).
navstivil(2313, default_p14, default_k06, 72.227692).
navstivil(2314, default_p14, default_k06, 72.227692).
navstivil(2315, default_p14, default_k06, 72.227692).
navstivil(2316, default_p14, default_k06, 66.227706).
navstivil(2317, default_p14, default_k06, 66.227706).
navstivil(2318, default_p14, default_k06, 66.227706).
navstivil(2319, default_p14, default_k06, 99.22772).
navstivil(2320, default_p14, default_k06, 99.22772).
navstivil(2321, default_p14, default_k06, 99.22772).
navstivil(2322, default_p14, default_k06, 63.227735).
navstivil(2323, default_p14, default_k06, 63.227735).
navstivil(2324, default_p14, default_k06, 63.227735).
navstivil(2325, default_p14, default_k06, 89.22775).
navstivil(2326, default_p14, default_k06, 89.22775).
navstivil(2327, default_p14, default_k06, 89.22775).
navstivil(2328, default_p14, default_k06, 77.227765).
navstivil(2329, default_p14, default_k06, 77.227765).
navstivil(2330, default_p14, default_k06, 77.227765).
navstivil(2331, default_p14, default_k06, 16.22778).
navstivil(2332, default_p14, default_k06, 16.22778).
navstivil(2333, default_p14, default_k06, 16.22778).
navstivil(2334, default_p14, default_k06, 92.227794).
navstivil(2335, default_p14, default_k06, 92.227794).
navstivil(2336, default_p14, default_k06, 92.227794).
navstivil(2337, default_p14, default_k06, 75.227809).
navstivil(2338, default_p14, default_k06, 75.227809).
navstivil(2339, default_p14, default_k06, 75.227809).
navstivil(2340, default_p14, default_k06, 11.227823).
navstivil(2341, default_p14, default_k06, 11.227823).
navstivil(2342, default_p14, default_k06, 11.227823).
navstivil(2343, default_p14, default_k07, 43.227838).
navstivil(2344, default_p14, default_k07, 43.227838).
navstivil(2345, default_p14, default_k07, 43.227838).
navstivil(2346, default_p14, default_k07, 34.227856).
navstivil(2347, default_p14, default_k07, 34.227856).
navstivil(2348, default_p14, default_k07, 34.227856).
navstivil(2349, default_p14, default_k07, 76.22787).
navstivil(2350, default_p14, default_k07, 76.22787).
navstivil(2351, default_p14, default_k07, 76.22787).
navstivil(2352, default_p14, default_k07, 85.227884).
navstivil(2353, default_p14, default_k07, 85.227884).
navstivil(2354, default_p14, default_k07, 85.227884).
navstivil(2355, default_p14, default_k07, 29.227898).
navstivil(2356, default_p14, default_k07, 29.227898).
navstivil(2357, default_p14, default_k07, 29.227898).
navstivil(2358, default_p14, default_k07, 14.227912).
navstivil(2359, default_p14, default_k07, 14.227912).
navstivil(2360, default_p14, default_k07, 14.227912).
navstivil(2361, default_p14, default_k07, 9.227926).
navstivil(2362, default_p14, default_k07, 9.227926).
navstivil(2363, default_p14, default_k07, 9.227926).
navstivil(2364, default_p14, default_k07, 32.22794).
navstivil(2365, default_p14, default_k07, 32.22794).
navstivil(2366, default_p14, default_k07, 32.22794).
navstivil(2367, default_p14, default_k07, 3.227954).
navstivil(2368, default_p14, default_k07, 3.227954).
navstivil(2369, default_p14, default_k07, 3.227954).
navstivil(2370, default_p14, default_k07, 99.227969).
navstivil(2371, default_p14, default_k07, 99.227969).
navstivil(2372, default_p14, default_k07, 99.227969).
navstivil(2373, default_p14, default_k07, 51.227984).
navstivil(2374, default_p14, default_k07, 51.227984).
navstivil(2375, default_p14, default_k07, 51.227984).
navstivil(2376, default_p14, default_k07, 38.227999).
navstivil(2377, default_p14, default_k07, 38.227999).
navstivil(2378, default_p14, default_k07, 38.227999).
navstivil(2379, default_p14, default_k07, 22.228013).
navstivil(2380, default_p14, default_k07, 22.228013).
navstivil(2381, default_p14, default_k07, 22.228013).
navstivil(2382, default_p14, default_k08, 88.228053).
navstivil(2383, default_p14, default_k08, 88.228053).
navstivil(2384, default_p14, default_k08, 88.228053).
navstivil(2385, default_p14, default_k08, 35.228072).
navstivil(2386, default_p14, default_k08, 35.228072).
navstivil(2387, default_p14, default_k08, 35.228072).
navstivil(2388, default_p14, default_k08, 50.22809).
navstivil(2389, default_p14, default_k08, 50.22809).
navstivil(2390, default_p14, default_k08, 50.22809).
navstivil(2391, default_p14, default_k08, 8.228104).
navstivil(2392, default_p14, default_k08, 8.228104).
navstivil(2393, default_p14, default_k08, 8.228104).
navstivil(2394, default_p14, default_k08, 15.228118).
navstivil(2395, default_p14, default_k08, 15.228118).
navstivil(2396, default_p14, default_k08, 15.228118).
navstivil(2397, default_p14, default_k08, 34.228133).
navstivil(2398, default_p14, default_k08, 34.228133).
navstivil(2399, default_p14, default_k08, 34.228133).
navstivil(2400, default_p14, default_k08, 13.228147).
navstivil(2401, default_p14, default_k08, 13.228147).
navstivil(2402, default_p14, default_k08, 13.228147).
navstivil(2403, default_p14, default_k08, 71.228162).
navstivil(2404, default_p14, default_k08, 71.228162).
navstivil(2405, default_p14, default_k08, 71.228162).
navstivil(2406, default_p14, default_k08, 3.228176).
navstivil(2407, default_p14, default_k08, 3.228176).
navstivil(2408, default_p14, default_k08, 3.228176).
navstivil(2409, default_p14, default_k08, 65.22819).
navstivil(2410, default_p14, default_k08, 65.22819).
navstivil(2411, default_p14, default_k08, 65.22819).
navstivil(2412, default_p14, default_k08, 54.228205).
navstivil(2413, default_p14, default_k08, 54.228205).
navstivil(2414, default_p14, default_k08, 54.228205).
navstivil(2415, default_p14, default_k08, 64.228219).
navstivil(2416, default_p14, default_k08, 64.228219).
navstivil(2417, default_p14, default_k08, 64.228219).
navstivil(2418, default_p14, default_k08, 37.228233).
navstivil(2419, default_p14, default_k08, 37.228233).
navstivil(2420, default_p14, default_k08, 37.228233).
navstivil(2421, default_p14, default_k09, 39.228249).
navstivil(2422, default_p14, default_k09, 39.228249).
navstivil(2423, default_p14, default_k09, 39.228249).
navstivil(2424, default_p14, default_k09, 63.228264).
navstivil(2425, default_p14, default_k09, 63.228264).
navstivil(2426, default_p14, default_k09, 63.228264).
navstivil(2427, default_p14, default_k09, 10.228278).
navstivil(2428, default_p14, default_k09, 10.228278).
navstivil(2429, default_p14, default_k09, 10.228278).
navstivil(2430, default_p14, default_k09, 30.228296).
navstivil(2431, default_p14, default_k09, 30.228296).
navstivil(2432, default_p14, default_k09, 30.228296).
navstivil(2433, default_p14, default_k09, 58.22831).
navstivil(2434, default_p14, default_k09, 58.22831).
navstivil(2435, default_p14, default_k09, 58.22831).
navstivil(2436, default_p14, default_k09, 93.228325).
navstivil(2437, default_p14, default_k09, 93.228325).
navstivil(2438, default_p14, default_k09, 93.228325).
navstivil(2439, default_p14, default_k09, 47.228339).
navstivil(2440, default_p14, default_k09, 47.228339).
navstivil(2441, default_p14, default_k09, 47.228339).
navstivil(2442, default_p14, default_k09, 30.228353).
navstivil(2443, default_p14, default_k09, 30.228353).
navstivil(2444, default_p14, default_k09, 30.228353).
navstivil(2445, default_p14, default_k09, 33.228368).
navstivil(2446, default_p14, default_k09, 33.228368).
navstivil(2447, default_p14, default_k09, 33.228368).
navstivil(2448, default_p14, default_k09, 31.228382).
navstivil(2449, default_p14, default_k09, 31.228382).
navstivil(2450, default_p14, default_k09, 31.228382).
navstivil(2451, default_p14, default_k09, 93.228396).
navstivil(2452, default_p14, default_k09, 93.228396).
navstivil(2453, default_p14, default_k09, 93.228396).
navstivil(2454, default_p14, default_k09, 32.22841).
navstivil(2455, default_p14, default_k09, 32.22841).
navstivil(2456, default_p14, default_k09, 32.22841).
navstivil(2457, default_p14, default_k09, 31.228424).
navstivil(2458, default_p14, default_k09, 31.228424).
navstivil(2459, default_p14, default_k09, 31.228424).
navstivil(2460, default_p14, default_k10, 27.22844).
navstivil(2461, default_p14, default_k10, 27.22844).
navstivil(2462, default_p14, default_k10, 27.22844).
navstivil(2463, default_p14, default_k10, 34.228454).
navstivil(2464, default_p14, default_k10, 34.228454).
navstivil(2465, default_p14, default_k10, 34.228454).
navstivil(2466, default_p14, default_k10, 3.228468).
navstivil(2467, default_p14, default_k10, 3.228468).
navstivil(2468, default_p14, default_k10, 3.228468).
navstivil(2469, default_p14, default_k10, 48.228482).
navstivil(2470, default_p14, default_k10, 48.228482).
navstivil(2471, default_p14, default_k10, 48.228482).
navstivil(2472, default_p14, default_k10, 57.228499).
navstivil(2473, default_p14, default_k10, 57.228499).
navstivil(2474, default_p14, default_k10, 57.228499).
navstivil(2475, default_p14, default_k10, 34.228513).
navstivil(2476, default_p14, default_k10, 34.228513).
navstivil(2477, default_p14, default_k10, 34.228513).
navstivil(2478, default_p14, default_k10, 49.228527).
navstivil(2479, default_p14, default_k10, 49.228527).
navstivil(2480, default_p14, default_k10, 49.228527).
navstivil(2481, default_p14, default_k10, 97.228542).
navstivil(2482, default_p14, default_k10, 97.228542).
navstivil(2483, default_p14, default_k10, 97.228542).
navstivil(2484, default_p14, default_k10, 30.228556).
navstivil(2485, default_p14, default_k10, 30.228556).
navstivil(2486, default_p14, default_k10, 30.228556).
navstivil(2487, default_p14, default_k10, 53.22857).
navstivil(2488, default_p14, default_k10, 53.22857).
navstivil(2489, default_p14, default_k10, 53.22857).
navstivil(2490, default_p14, default_k10, 4.228584).
navstivil(2491, default_p14, default_k10, 4.228584).
navstivil(2492, default_p14, default_k10, 4.228584).
navstivil(2493, default_p14, default_k10, 88.228601).
navstivil(2494, default_p14, default_k10, 88.228601).
navstivil(2495, default_p14, default_k10, 88.228601).
navstivil(2496, default_p14, default_k10, 96.228615).
navstivil(2497, default_p14, default_k10, 96.228615).
navstivil(2498, default_p14, default_k10, 96.228615).
navstivil(2499, default_p15, default_k01, 55.228631).
navstivil(2500, default_p15, default_k01, 55.228631).
navstivil(2501, default_p15, default_k01, 55.228631).
navstivil(2502, default_p15, default_k01, 78.228646).
navstivil(2503, default_p15, default_k01, 78.228646).
navstivil(2504, default_p15, default_k01, 78.228646).
navstivil(2505, default_p15, default_k01, 58.22866).
navstivil(2506, default_p15, default_k01, 58.22866).
navstivil(2507, default_p15, default_k01, 58.22866).
navstivil(2508, default_p15, default_k01, 18.228674).
navstivil(2509, default_p15, default_k01, 18.228674).
navstivil(2510, default_p15, default_k01, 18.228674).
navstivil(2511, default_p15, default_k01, 26.228688).
navstivil(2512, default_p15, default_k01, 26.228688).
navstivil(2513, default_p15, default_k01, 26.228688).
navstivil(2514, default_p15, default_k01, 69.228707).
navstivil(2515, default_p15, default_k01, 69.228707).
navstivil(2516, default_p15, default_k01, 69.228707).
navstivil(2517, default_p15, default_k01, 60.228722).
navstivil(2518, default_p15, default_k01, 60.228722).
navstivil(2519, default_p15, default_k01, 60.228722).
navstivil(2520, default_p15, default_k01, 16.228736).
navstivil(2521, default_p15, default_k01, 16.228736).
navstivil(2522, default_p15, default_k01, 16.228736).
navstivil(2523, default_p15, default_k01, 25.228751).
navstivil(2524, default_p15, default_k01, 25.228751).
navstivil(2525, default_p15, default_k01, 25.228751).
navstivil(2526, default_p15, default_k01, 56.228765).
navstivil(2527, default_p15, default_k01, 56.228765).
navstivil(2528, default_p15, default_k01, 56.228765).
navstivil(2529, default_p15, default_k01, 27.22878).
navstivil(2530, default_p15, default_k01, 27.22878).
navstivil(2531, default_p15, default_k01, 27.22878).
navstivil(2532, default_p15, default_k01, 29.228793).
navstivil(2533, default_p15, default_k01, 29.228793).
navstivil(2534, default_p15, default_k01, 29.228793).
navstivil(2535, default_p15, default_k01, 37.228808).
navstivil(2536, default_p15, default_k01, 37.228808).
navstivil(2537, default_p15, default_k01, 37.228808).
navstivil(2538, default_p15, default_k01, 18.228823).
navstivil(2539, default_p15, default_k01, 18.228823).
navstivil(2540, default_p15, default_k01, 18.228823).
navstivil(2541, default_p15, default_k02, 40.228838).
navstivil(2542, default_p15, default_k02, 40.228838).
navstivil(2543, default_p15, default_k02, 40.228838).
navstivil(2544, default_p15, default_k02, 54.228852).
navstivil(2545, default_p15, default_k02, 54.228852).
navstivil(2546, default_p15, default_k02, 54.228852).
navstivil(2547, default_p15, default_k02, 24.228867).
navstivil(2548, default_p15, default_k02, 24.228867).
navstivil(2549, default_p15, default_k02, 24.228867).
navstivil(2550, default_p15, default_k02, 14.228881).
navstivil(2551, default_p15, default_k02, 14.228881).
navstivil(2552, default_p15, default_k02, 14.228881).
navstivil(2553, default_p15, default_k02, 75.228896).
navstivil(2554, default_p15, default_k02, 75.228896).
navstivil(2555, default_p15, default_k02, 75.228896).
navstivil(2556, default_p15, default_k02, 97.228914).
navstivil(2557, default_p15, default_k02, 97.228914).
navstivil(2558, default_p15, default_k02, 97.228914).
navstivil(2559, default_p15, default_k02, 41.228929).
navstivil(2560, default_p15, default_k02, 41.228929).
navstivil(2561, default_p15, default_k02, 41.228929).
navstivil(2562, default_p15, default_k02, 32.228993).
navstivil(2563, default_p15, default_k02, 32.228993).
navstivil(2564, default_p15, default_k02, 32.228993).
navstivil(2565, default_p15, default_k02, 51.229008).
navstivil(2566, default_p15, default_k02, 51.229008).
navstivil(2567, default_p15, default_k02, 51.229008).
navstivil(2568, default_p15, default_k02, 78.229023).
navstivil(2569, default_p15, default_k02, 78.229023).
navstivil(2570, default_p15, default_k02, 78.229023).
navstivil(2571, default_p15, default_k02, 80.229037).
navstivil(2572, default_p15, default_k02, 80.229037).
navstivil(2573, default_p15, default_k02, 80.229037).
navstivil(2574, default_p15, default_k02, 49.229051).
navstivil(2575, default_p15, default_k02, 49.229051).
navstivil(2576, default_p15, default_k02, 49.229051).
navstivil(2577, default_p15, default_k02, 73.229075).
navstivil(2578, default_p15, default_k02, 73.229075).
navstivil(2579, default_p15, default_k02, 73.229075).
navstivil(2580, default_p15, default_k02, 38.229097).
navstivil(2581, default_p15, default_k02, 38.229097).
navstivil(2582, default_p15, default_k02, 38.229097).
navstivil(2583, default_p15, default_k03, 31.229121).
navstivil(2584, default_p15, default_k03, 31.229121).
navstivil(2585, default_p15, default_k03, 31.229121).
navstivil(2586, default_p15, default_k03, 30.229136).
navstivil(2587, default_p15, default_k03, 30.229136).
navstivil(2588, default_p15, default_k03, 30.229136).
navstivil(2589, default_p15, default_k03, 91.22915).
navstivil(2590, default_p15, default_k03, 91.22915).
navstivil(2591, default_p15, default_k03, 91.22915).
navstivil(2592, default_p15, default_k03, 2.229164).
navstivil(2593, default_p15, default_k03, 2.229164).
navstivil(2594, default_p15, default_k03, 2.229164).
navstivil(2595, default_p15, default_k03, 46.229178).
navstivil(2596, default_p15, default_k03, 46.229178).
navstivil(2597, default_p15, default_k03, 46.229178).
navstivil(2598, default_p15, default_k03, 11.229198).
navstivil(2599, default_p15, default_k03, 11.229198).
navstivil(2600, default_p15, default_k03, 11.229198).
navstivil(2601, default_p15, default_k03, 39.229213).
navstivil(2602, default_p15, default_k03, 39.229213).
navstivil(2603, default_p15, default_k03, 39.229213).
navstivil(2604, default_p15, default_k03, 75.229227).
navstivil(2605, default_p15, default_k03, 75.229227).
navstivil(2606, default_p15, default_k03, 75.229227).
navstivil(2607, default_p15, default_k03, 13.229242).
navstivil(2608, default_p15, default_k03, 13.229242).
navstivil(2609, default_p15, default_k03, 13.229242).
navstivil(2610, default_p15, default_k03, 97.229256).
navstivil(2611, default_p15, default_k03, 97.229256).
navstivil(2612, default_p15, default_k03, 97.229256).
navstivil(2613, default_p15, default_k03, 5.229271).
navstivil(2614, default_p15, default_k03, 5.229271).
navstivil(2615, default_p15, default_k03, 5.229271).
navstivil(2616, default_p15, default_k03, 81.229285).
navstivil(2617, default_p15, default_k03, 81.229285).
navstivil(2618, default_p15, default_k03, 81.229285).
navstivil(2619, default_p15, default_k03, 85.229299).
navstivil(2620, default_p15, default_k03, 85.229299).
navstivil(2621, default_p15, default_k03, 85.229299).
navstivil(2622, default_p15, default_k03, 97.229314).
navstivil(2623, default_p15, default_k03, 97.229314).
navstivil(2624, default_p15, default_k03, 97.229314).
navstivil(2625, default_p15, default_k04, 4.229351).
navstivil(2626, default_p15, default_k04, 4.229351).
navstivil(2627, default_p15, default_k04, 4.229351).
navstivil(2628, default_p15, default_k04, 29.229366).
navstivil(2629, default_p15, default_k04, 29.229366).
navstivil(2630, default_p15, default_k04, 29.229366).
navstivil(2631, default_p15, default_k04, 97.22938).
navstivil(2632, default_p15, default_k04, 97.22938).
navstivil(2633, default_p15, default_k04, 97.22938).
navstivil(2634, default_p15, default_k04, 99.229395).
navstivil(2635, default_p15, default_k04, 99.229395).
navstivil(2636, default_p15, default_k04, 99.229395).
navstivil(2637, default_p15, default_k04, 90.229409).
navstivil(2638, default_p15, default_k04, 90.229409).
navstivil(2639, default_p15, default_k04, 90.229409).
navstivil(2640, default_p15, default_k04, 47.229428).
navstivil(2641, default_p15, default_k04, 47.229428).
navstivil(2642, default_p15, default_k04, 47.229428).
navstivil(2643, default_p15, default_k04, 87.229444).
navstivil(2644, default_p15, default_k04, 87.229444).
navstivil(2645, default_p15, default_k04, 87.229444).
navstivil(2646, default_p15, default_k04, 55.229459).
navstivil(2647, default_p15, default_k04, 55.229459).
navstivil(2648, default_p15, default_k04, 55.229459).
navstivil(2649, default_p15, default_k04, 6.229473).
navstivil(2650, default_p15, default_k04, 6.229473).
navstivil(2651, default_p15, default_k04, 6.229473).
navstivil(2652, default_p15, default_k04, 59.229487).
navstivil(2653, default_p15, default_k04, 59.229487).
navstivil(2654, default_p15, default_k04, 59.229487).
navstivil(2655, default_p15, default_k04, 78.229501).
navstivil(2656, default_p15, default_k04, 78.229501).
navstivil(2657, default_p15, default_k04, 78.229501).
navstivil(2658, default_p15, default_k04, 70.229516).
navstivil(2659, default_p15, default_k04, 70.229516).
navstivil(2660, default_p15, default_k04, 70.229516).
navstivil(2661, default_p15, default_k04, 13.229531).
navstivil(2662, default_p15, default_k04, 13.229531).
navstivil(2663, default_p15, default_k04, 13.229531).
navstivil(2664, default_p15, default_k04, 70.229545).
navstivil(2665, default_p15, default_k04, 70.229545).
navstivil(2666, default_p15, default_k04, 70.229545).
navstivil(2667, default_p15, default_k05, 57.22956).
navstivil(2668, default_p15, default_k05, 57.22956).
navstivil(2669, default_p15, default_k05, 57.22956).
navstivil(2670, default_p15, default_k05, 11.229573).
navstivil(2671, default_p15, default_k05, 11.229573).
navstivil(2672, default_p15, default_k05, 11.229573).
navstivil(2673, default_p15, default_k05, 29.229588).
navstivil(2674, default_p15, default_k05, 29.229588).
navstivil(2675, default_p15, default_k05, 29.229588).
navstivil(2676, default_p15, default_k05, 17.229602).
navstivil(2677, default_p15, default_k05, 17.229602).
navstivil(2678, default_p15, default_k05, 17.229602).
navstivil(2679, default_p15, default_k05, 3.229618).
navstivil(2680, default_p15, default_k05, 3.229618).
navstivil(2681, default_p15, default_k05, 3.229618).
navstivil(2682, default_p15, default_k05, 90.229637).
navstivil(2683, default_p15, default_k05, 90.229637).
navstivil(2684, default_p15, default_k05, 90.229637).
navstivil(2685, default_p15, default_k05, 56.229653).
navstivil(2686, default_p15, default_k05, 56.229653).
navstivil(2687, default_p15, default_k05, 56.229653).
navstivil(2688, default_p15, default_k05, 15.229667).
navstivil(2689, default_p15, default_k05, 15.229667).
navstivil(2690, default_p15, default_k05, 15.229667).
navstivil(2691, default_p15, default_k05, 26.229682).
navstivil(2692, default_p15, default_k05, 26.229682).
navstivil(2693, default_p15, default_k05, 26.229682).
navstivil(2694, default_p15, default_k05, 45.229696).
navstivil(2695, default_p15, default_k05, 45.229696).
navstivil(2696, default_p15, default_k05, 45.229696).
navstivil(2697, default_p15, default_k05, 66.229711).
navstivil(2698, default_p15, default_k05, 66.229711).
navstivil(2699, default_p15, default_k05, 66.229711).
navstivil(2700, default_p15, default_k05, 28.229725).
navstivil(2701, default_p15, default_k05, 28.229725).
navstivil(2702, default_p15, default_k05, 28.229725).
navstivil(2703, default_p15, default_k05, 98.22974).
navstivil(2704, default_p15, default_k05, 98.22974).
navstivil(2705, default_p15, default_k05, 98.22974).
navstivil(2706, default_p15, default_k05, 7.229755).
navstivil(2707, default_p15, default_k05, 7.229755).
navstivil(2708, default_p15, default_k05, 7.229755).
navstivil(2709, default_p15, default_k06, 87.229773).
navstivil(2710, default_p15, default_k06, 87.229773).
navstivil(2711, default_p15, default_k06, 87.229773).
navstivil(2712, default_p15, default_k06, 67.229787).
navstivil(2713, default_p15, default_k06, 67.229787).
navstivil(2714, default_p15, default_k06, 67.229787).
navstivil(2715, default_p15, default_k06, 49.229802).
navstivil(2716, default_p15, default_k06, 49.229802).
navstivil(2717, default_p15, default_k06, 49.229802).
navstivil(2718, default_p15, default_k06, 10.229816).
navstivil(2719, default_p15, default_k06, 10.229816).
navstivil(2720, default_p15, default_k06, 10.229816).
navstivil(2721, default_p15, default_k06, 20.22983).
navstivil(2722, default_p15, default_k06, 20.22983).
navstivil(2723, default_p15, default_k06, 20.22983).
navstivil(2724, default_p15, default_k06, 99.229848).
navstivil(2725, default_p15, default_k06, 99.229848).
navstivil(2726, default_p15, default_k06, 99.229848).
navstivil(2727, default_p15, default_k06, 35.229862).
navstivil(2728, default_p15, default_k06, 35.229862).
navstivil(2729, default_p15, default_k06, 35.229862).
navstivil(2730, default_p15, default_k06, 40.229877).
navstivil(2731, default_p15, default_k06, 40.229877).
navstivil(2732, default_p15, default_k06, 40.229877).
navstivil(2733, default_p15, default_k06, 45.229891).
navstivil(2734, default_p15, default_k06, 45.229891).
navstivil(2735, default_p15, default_k06, 45.229891).
navstivil(2736, default_p15, default_k06, 56.229905).
navstivil(2737, default_p15, default_k06, 56.229905).
navstivil(2738, default_p15, default_k06, 56.229905).
navstivil(2739, default_p15, default_k06, 62.22992).
navstivil(2740, default_p15, default_k06, 62.22992).
navstivil(2741, default_p15, default_k06, 62.22992).
navstivil(2742, default_p15, default_k06, 27.229934).
navstivil(2743, default_p15, default_k06, 27.229934).
navstivil(2744, default_p15, default_k06, 27.229934).
navstivil(2745, default_p15, default_k06, 15.229949).
navstivil(2746, default_p15, default_k06, 15.229949).
navstivil(2747, default_p15, default_k06, 15.229949).
navstivil(2748, default_p15, default_k06, 36.229963).
navstivil(2749, default_p15, default_k06, 36.229963).
navstivil(2750, default_p15, default_k06, 36.229963).
navstivil(2751, default_p15, default_k07, 99.229978).
navstivil(2752, default_p15, default_k07, 99.229978).
navstivil(2753, default_p15, default_k07, 99.229978).
navstivil(2754, default_p15, default_k07, 48.229992).
navstivil(2755, default_p15, default_k07, 48.229992).
navstivil(2756, default_p15, default_k07, 48.229992).
navstivil(2757, default_p15, default_k07, 65.230007).
navstivil(2758, default_p15, default_k07, 65.230007).
navstivil(2759, default_p15, default_k07, 65.230007).
navstivil(2760, default_p15, default_k07, 100.230021).
navstivil(2761, default_p15, default_k07, 100.230021).
navstivil(2762, default_p15, default_k07, 100.230021).
navstivil(2763, default_p15, default_k07, 70.230036).
navstivil(2764, default_p15, default_k07, 70.230036).
navstivil(2765, default_p15, default_k07, 70.230036).
navstivil(2766, default_p15, default_k07, 4.230053).
navstivil(2767, default_p15, default_k07, 4.230053).
navstivil(2768, default_p15, default_k07, 4.230053).
navstivil(2769, default_p15, default_k07, 57.230068).
navstivil(2770, default_p15, default_k07, 57.230068).
navstivil(2771, default_p15, default_k07, 57.230068).
navstivil(2772, default_p15, default_k07, 79.230115).
navstivil(2773, default_p15, default_k07, 79.230115).
navstivil(2774, default_p15, default_k07, 79.230115).
navstivil(2775, default_p15, default_k07, 21.230129).
navstivil(2776, default_p15, default_k07, 21.230129).
navstivil(2777, default_p15, default_k07, 21.230129).
navstivil(2778, default_p15, default_k07, 24.230142999999998).
navstivil(2779, default_p15, default_k07, 24.230142999999998).
navstivil(2780, default_p15, default_k07, 24.230142999999998).
navstivil(2781, default_p15, default_k07, 3.230158).
navstivil(2782, default_p15, default_k07, 3.230158).
navstivil(2783, default_p15, default_k07, 3.230158).
navstivil(2784, default_p15, default_k07, 89.230173).
navstivil(2785, default_p15, default_k07, 89.230173).
navstivil(2786, default_p15, default_k07, 89.230173).
navstivil(2787, default_p15, default_k07, 65.230188).
navstivil(2788, default_p15, default_k07, 65.230188).
navstivil(2789, default_p15, default_k07, 65.230188).
navstivil(2790, default_p15, default_k07, 35.230202).
navstivil(2791, default_p15, default_k07, 35.230202).
navstivil(2792, default_p15, default_k07, 35.230202).
navstivil(2793, default_p15, default_k08, 41.230217).
navstivil(2794, default_p15, default_k08, 41.230217).
navstivil(2795, default_p15, default_k08, 41.230217).
navstivil(2796, default_p15, default_k08, 41.230231).
navstivil(2797, default_p15, default_k08, 41.230231).
navstivil(2798, default_p15, default_k08, 41.230231).
navstivil(2799, default_p15, default_k08, 49.230245).
navstivil(2800, default_p15, default_k08, 49.230245).
navstivil(2801, default_p15, default_k08, 49.230245).
navstivil(2802, default_p15, default_k08, 72.23026).
navstivil(2803, default_p15, default_k08, 72.23026).
navstivil(2804, default_p15, default_k08, 72.23026).
navstivil(2805, default_p15, default_k08, 58.230273).
navstivil(2806, default_p15, default_k08, 58.230273).
navstivil(2807, default_p15, default_k08, 58.230273).
navstivil(2808, default_p15, default_k08, 7.230291).
navstivil(2809, default_p15, default_k08, 7.230291).
navstivil(2810, default_p15, default_k08, 7.230291).
navstivil(2811, default_p15, default_k08, 83.230305).
navstivil(2812, default_p15, default_k08, 83.230305).
navstivil(2813, default_p15, default_k08, 83.230305).
navstivil(2814, default_p15, default_k08, 77.230319).
navstivil(2815, default_p15, default_k08, 77.230319).
navstivil(2816, default_p15, default_k08, 77.230319).
navstivil(2817, default_p15, default_k08, 32.230333).
navstivil(2818, default_p15, default_k08, 32.230333).
navstivil(2819, default_p15, default_k08, 32.230333).
navstivil(2820, default_p15, default_k08, 73.230347).
navstivil(2821, default_p15, default_k08, 73.230347).
navstivil(2822, default_p15, default_k08, 73.230347).
navstivil(2823, default_p15, default_k08, 29.230361).
navstivil(2824, default_p15, default_k08, 29.230361).
navstivil(2825, default_p15, default_k08, 29.230361).
navstivil(2826, default_p15, default_k08, 53.230375).
navstivil(2827, default_p15, default_k08, 53.230375).
navstivil(2828, default_p15, default_k08, 53.230375).
navstivil(2829, default_p15, default_k08, 49.230389).
navstivil(2830, default_p15, default_k08, 49.230389).
navstivil(2831, default_p15, default_k08, 49.230389).
navstivil(2832, default_p15, default_k08, 51.230404).
navstivil(2833, default_p15, default_k08, 51.230404).
navstivil(2834, default_p15, default_k08, 51.230404).
navstivil(2835, default_p15, default_k09, 49.230419).
navstivil(2836, default_p15, default_k09, 49.230419).
navstivil(2837, default_p15, default_k09, 49.230419).
navstivil(2838, default_p15, default_k09, 30.230433).
navstivil(2839, default_p15, default_k09, 30.230433).
navstivil(2840, default_p15, default_k09, 30.230433).
navstivil(2841, default_p15, default_k09, 93.230447).
navstivil(2842, default_p15, default_k09, 93.230447).
navstivil(2843, default_p15, default_k09, 93.230447).
navstivil(2844, default_p15, default_k09, 21.230462).
navstivil(2845, default_p15, default_k09, 21.230462).
navstivil(2846, default_p15, default_k09, 21.230462).
navstivil(2847, default_p15, default_k09, 38.230477).
navstivil(2848, default_p15, default_k09, 38.230477).
navstivil(2849, default_p15, default_k09, 38.230477).
navstivil(2850, default_p15, default_k09, 55.230495).
navstivil(2851, default_p15, default_k09, 55.230495).
navstivil(2852, default_p15, default_k09, 55.230495).
navstivil(2853, default_p15, default_k09, 62.230509).
navstivil(2854, default_p15, default_k09, 62.230509).
navstivil(2855, default_p15, default_k09, 62.230509).
navstivil(2856, default_p15, default_k09, 38.230523).
navstivil(2857, default_p15, default_k09, 38.230523).
navstivil(2858, default_p15, default_k09, 38.230523).
navstivil(2859, default_p15, default_k09, 51.230537).
navstivil(2860, default_p15, default_k09, 51.230537).
navstivil(2861, default_p15, default_k09, 51.230537).
navstivil(2862, default_p15, default_k09, 81.230552).
navstivil(2863, default_p15, default_k09, 81.230552).
navstivil(2864, default_p15, default_k09, 81.230552).
navstivil(2865, default_p15, default_k09, 17.230567).
navstivil(2866, default_p15, default_k09, 17.230567).
navstivil(2867, default_p15, default_k09, 17.230567).
navstivil(2868, default_p15, default_k09, 91.230582).
navstivil(2869, default_p15, default_k09, 91.230582).
navstivil(2870, default_p15, default_k09, 91.230582).
navstivil(2871, default_p15, default_k09, 6.230598).
navstivil(2872, default_p15, default_k09, 6.230598).
navstivil(2873, default_p15, default_k09, 6.230598).
navstivil(2874, default_p15, default_k09, 50.230613).
navstivil(2875, default_p15, default_k09, 50.230613).
navstivil(2876, default_p15, default_k09, 50.230613).
navstivil(2877, default_p15, default_k10, 43.230628).
navstivil(2878, default_p15, default_k10, 43.230628).
navstivil(2879, default_p15, default_k10, 43.230628).
navstivil(2880, default_p15, default_k10, 9.230642).
navstivil(2881, default_p15, default_k10, 9.230642).
navstivil(2882, default_p15, default_k10, 9.230642).
navstivil(2883, default_p15, default_k10, 32.230656).
navstivil(2884, default_p15, default_k10, 32.230656).
navstivil(2885, default_p15, default_k10, 32.230656).
navstivil(2886, default_p15, default_k10, 96.23067).
navstivil(2887, default_p15, default_k10, 96.23067).
navstivil(2888, default_p15, default_k10, 96.23067).
navstivil(2889, default_p15, default_k10, 2.230685).
navstivil(2890, default_p15, default_k10, 2.230685).
navstivil(2891, default_p15, default_k10, 2.230685).
navstivil(2892, default_p15, default_k10, 46.230703).
navstivil(2893, default_p15, default_k10, 46.230703).
navstivil(2894, default_p15, default_k10, 46.230703).
navstivil(2895, default_p15, default_k10, 36.230717).
navstivil(2896, default_p15, default_k10, 36.230717).
navstivil(2897, default_p15, default_k10, 36.230717).
navstivil(2898, default_p15, default_k10, 14.230732).
navstivil(2899, default_p15, default_k10, 14.230732).
navstivil(2900, default_p15, default_k10, 14.230732).
navstivil(2901, default_p15, default_k10, 79.230748).
navstivil(2902, default_p15, default_k10, 79.230748).
navstivil(2903, default_p15, default_k10, 79.230748).
navstivil(2904, default_p15, default_k10, 23.230763).
navstivil(2905, default_p15, default_k10, 23.230763).
navstivil(2906, default_p15, default_k10, 23.230763).
navstivil(2907, default_p15, default_k10, 53.230777).
navstivil(2908, default_p15, default_k10, 53.230777).
navstivil(2909, default_p15, default_k10, 53.230777).
navstivil(2910, default_p15, default_k10, 62.230791).
navstivil(2911, default_p15, default_k10, 62.230791).
navstivil(2912, default_p15, default_k10, 62.230791).
navstivil(2913, default_p15, default_k10, 11.230805).
navstivil(2914, default_p15, default_k10, 11.230805).
navstivil(2915, default_p15, default_k10, 11.230805).
navstivil(2916, default_p15, default_k10, 60.230819).
navstivil(2917, default_p15, default_k10, 60.230819).
navstivil(2918, default_p15, default_k10, 60.230819).
navstivil(2919, default_p16, default_k01, 55.230835).
navstivil(2920, default_p16, default_k01, 55.230835).
navstivil(2921, default_p16, default_k01, 55.230835).
navstivil(2922, default_p16, default_k01, 9.230848).
navstivil(2923, default_p16, default_k01, 9.230848).
navstivil(2924, default_p16, default_k01, 9.230848).
navstivil(2925, default_p16, default_k01, 87.230863).
navstivil(2926, default_p16, default_k01, 87.230863).
navstivil(2927, default_p16, default_k01, 87.230863).
navstivil(2928, default_p16, default_k01, 3.230878).
navstivil(2929, default_p16, default_k01, 3.230878).
navstivil(2930, default_p16, default_k01, 3.230878).
navstivil(2931, default_p16, default_k01, 72.230893).
navstivil(2932, default_p16, default_k01, 72.230893).
navstivil(2933, default_p16, default_k01, 72.230893).
navstivil(2934, default_p16, default_k01, 5.23091).
navstivil(2935, default_p16, default_k01, 5.23091).
navstivil(2936, default_p16, default_k01, 5.23091).
navstivil(2937, default_p16, default_k01, 26.230924).
navstivil(2938, default_p16, default_k01, 26.230924).
navstivil(2939, default_p16, default_k01, 26.230924).
navstivil(2940, default_p16, default_k01, 13.230937).
navstivil(2941, default_p16, default_k01, 13.230937).
navstivil(2942, default_p16, default_k01, 13.230937).
navstivil(2943, default_p16, default_k01, 46.230952).
navstivil(2944, default_p16, default_k01, 46.230952).
navstivil(2945, default_p16, default_k01, 46.230952).
navstivil(2946, default_p16, default_k01, 72.230967).
navstivil(2947, default_p16, default_k01, 72.230967).
navstivil(2948, default_p16, default_k01, 72.230967).
navstivil(2949, default_p16, default_k01, 15.230982).
navstivil(2950, default_p16, default_k01, 15.230982).
navstivil(2951, default_p16, default_k01, 15.230982).
navstivil(2952, default_p16, default_k01, 49.230998).
navstivil(2953, default_p16, default_k01, 49.230998).
navstivil(2954, default_p16, default_k01, 49.230998).
navstivil(2955, default_p16, default_k01, 15.231013).
navstivil(2956, default_p16, default_k01, 15.231013).
navstivil(2957, default_p16, default_k01, 15.231013).
navstivil(2958, default_p16, default_k01, 62.231027).
navstivil(2959, default_p16, default_k01, 62.231027).
navstivil(2960, default_p16, default_k01, 62.231027).
navstivil(2961, default_p16, default_k01, 69.231045).
navstivil(2962, default_p16, default_k01, 69.231045).
navstivil(2963, default_p16, default_k01, 69.231045).
navstivil(2964, default_p16, default_k02, 26.23106).
navstivil(2965, default_p16, default_k02, 26.23106).
navstivil(2966, default_p16, default_k02, 26.23106).
navstivil(2967, default_p16, default_k02, 22.231075).
navstivil(2968, default_p16, default_k02, 22.231075).
navstivil(2969, default_p16, default_k02, 22.231075).
navstivil(2970, default_p16, default_k02, 99.231089).
navstivil(2971, default_p16, default_k02, 99.231089).
navstivil(2972, default_p16, default_k02, 99.231089).
navstivil(2973, default_p16, default_k02, 30.231103).
navstivil(2974, default_p16, default_k02, 30.231103).
navstivil(2975, default_p16, default_k02, 30.231103).
navstivil(2976, default_p16, default_k02, 81.231122).
navstivil(2977, default_p16, default_k02, 81.231122).
navstivil(2978, default_p16, default_k02, 81.231122).
navstivil(2979, default_p16, default_k02, 18.231136).
navstivil(2980, default_p16, default_k02, 18.231136).
navstivil(2981, default_p16, default_k02, 18.231136).
navstivil(2982, default_p16, default_k02, 14.231152).
navstivil(2983, default_p16, default_k02, 14.231152).
navstivil(2984, default_p16, default_k02, 14.231152).
navstivil(2985, default_p16, default_k02, 38.231166).
navstivil(2986, default_p16, default_k02, 38.231166).
navstivil(2987, default_p16, default_k02, 38.231166).
navstivil(2988, default_p16, default_k02, 17.23118).
navstivil(2989, default_p16, default_k02, 17.23118).
navstivil(2990, default_p16, default_k02, 17.23118).
navstivil(2991, default_p16, default_k02, 58.231195).
navstivil(2992, default_p16, default_k02, 58.231195).
navstivil(2993, default_p16, default_k02, 58.231195).
navstivil(2994, default_p16, default_k02, 91.231209).
navstivil(2995, default_p16, default_k02, 91.231209).
navstivil(2996, default_p16, default_k02, 91.231209).
navstivil(2997, default_p16, default_k02, 34.231224).
navstivil(2998, default_p16, default_k02, 34.231224).
navstivil(2999, default_p16, default_k02, 34.231224).
navstivil(3000, default_p16, default_k02, 2.231238).
navstivil(3001, default_p16, default_k02, 2.231238).
navstivil(3002, default_p16, default_k02, 2.231238).
navstivil(3003, default_p16, default_k02, 86.231253).
navstivil(3004, default_p16, default_k02, 86.231253).
navstivil(3005, default_p16, default_k02, 86.231253).
navstivil(3006, default_p16, default_k02, 16.231268).
navstivil(3007, default_p16, default_k02, 16.231268).
navstivil(3008, default_p16, default_k02, 16.231268).
navstivil(3009, default_p16, default_k03, 91.231283).
navstivil(3010, default_p16, default_k03, 91.231283).
navstivil(3011, default_p16, default_k03, 91.231283).
navstivil(3012, default_p16, default_k03, 72.231298).
navstivil(3013, default_p16, default_k03, 72.231298).
navstivil(3014, default_p16, default_k03, 72.231298).
navstivil(3015, default_p16, default_k03, 83.231312).
navstivil(3016, default_p16, default_k03, 83.231312).
navstivil(3017, default_p16, default_k03, 83.231312).
navstivil(3018, default_p16, default_k03, 55.23133).
navstivil(3019, default_p16, default_k03, 55.23133).
navstivil(3020, default_p16, default_k03, 55.23133).
navstivil(3021, default_p16, default_k03, 54.231344).
navstivil(3022, default_p16, default_k03, 54.231344).
navstivil(3023, default_p16, default_k03, 54.231344).
navstivil(3024, default_p16, default_k03, 11.231358).
navstivil(3025, default_p16, default_k03, 11.231358).
navstivil(3026, default_p16, default_k03, 11.231358).
navstivil(3027, default_p16, default_k03, 9.231373).
navstivil(3028, default_p16, default_k03, 9.231373).
navstivil(3029, default_p16, default_k03, 9.231373).
navstivil(3030, default_p16, default_k03, 85.231387).
navstivil(3031, default_p16, default_k03, 85.231387).
navstivil(3032, default_p16, default_k03, 85.231387).
navstivil(3033, default_p16, default_k03, 37.231402).
navstivil(3034, default_p16, default_k03, 37.231402).
navstivil(3035, default_p16, default_k03, 37.231402).
navstivil(3036, default_p16, default_k03, 70.231416).
navstivil(3037, default_p16, default_k03, 70.231416).
navstivil(3038, default_p16, default_k03, 70.231416).
navstivil(3039, default_p16, default_k03, 51.231431).
navstivil(3040, default_p16, default_k03, 51.231431).
navstivil(3041, default_p16, default_k03, 51.231431).
navstivil(3042, default_p16, default_k03, 63.231446).
navstivil(3043, default_p16, default_k03, 63.231446).
navstivil(3044, default_p16, default_k03, 63.231446).
navstivil(3045, default_p16, default_k03, 55.23146).
navstivil(3046, default_p16, default_k03, 55.23146).
navstivil(3047, default_p16, default_k03, 55.23146).
navstivil(3048, default_p16, default_k03, 37.231476).
navstivil(3049, default_p16, default_k03, 37.231476).
navstivil(3050, default_p16, default_k03, 37.231476).
navstivil(3051, default_p16, default_k03, 82.23149).
navstivil(3052, default_p16, default_k03, 82.23149).
navstivil(3053, default_p16, default_k03, 82.23149).
navstivil(3054, default_p16, default_k04, 64.231505).
navstivil(3055, default_p16, default_k04, 64.231505).
navstivil(3056, default_p16, default_k04, 64.231505).
navstivil(3057, default_p16, default_k04, 21.23152).
navstivil(3058, default_p16, default_k04, 21.23152).
navstivil(3059, default_p16, default_k04, 21.23152).
navstivil(3060, default_p16, default_k04, 99.231537).
navstivil(3061, default_p16, default_k04, 99.231537).
navstivil(3062, default_p16, default_k04, 99.231537).
navstivil(3063, default_p16, default_k04, 33.231551).
navstivil(3064, default_p16, default_k04, 33.231551).
navstivil(3065, default_p16, default_k04, 33.231551).
navstivil(3066, default_p16, default_k04, 36.231566).
navstivil(3067, default_p16, default_k04, 36.231566).
navstivil(3068, default_p16, default_k04, 36.231566).
navstivil(3069, default_p16, default_k04, 9.23158).
navstivil(3070, default_p16, default_k04, 9.23158).
navstivil(3071, default_p16, default_k04, 9.23158).
navstivil(3072, default_p16, default_k04, 30.231594).
navstivil(3073, default_p16, default_k04, 30.231594).
navstivil(3074, default_p16, default_k04, 30.231594).
navstivil(3075, default_p16, default_k04, 90.231608).
navstivil(3076, default_p16, default_k04, 90.231608).
navstivil(3077, default_p16, default_k04, 90.231608).
navstivil(3078, default_p16, default_k04, 20.231623).
navstivil(3079, default_p16, default_k04, 20.231623).
navstivil(3080, default_p16, default_k04, 20.231623).
navstivil(3081, default_p16, default_k04, 44.231637).
navstivil(3082, default_p16, default_k04, 44.231637).
navstivil(3083, default_p16, default_k04, 44.231637).
navstivil(3084, default_p16, default_k04, 2.231652).
navstivil(3085, default_p16, default_k04, 2.231652).
navstivil(3086, default_p16, default_k04, 2.231652).
navstivil(3087, default_p16, default_k04, 14.231666).
navstivil(3088, default_p16, default_k04, 14.231666).
navstivil(3089, default_p16, default_k04, 14.231666).
navstivil(3090, default_p16, default_k04, 3.23168).
navstivil(3091, default_p16, default_k04, 3.23168).
navstivil(3092, default_p16, default_k04, 3.23168).
navstivil(3093, default_p16, default_k04, 35.231694).
navstivil(3094, default_p16, default_k04, 35.231694).
navstivil(3095, default_p16, default_k04, 35.231694).
navstivil(3096, default_p16, default_k04, 59.231709).
navstivil(3097, default_p16, default_k04, 59.231709).
navstivil(3098, default_p16, default_k04, 59.231709).
navstivil(3099, default_p16, default_k05, 47.231724).
navstivil(3100, default_p16, default_k05, 47.231724).
navstivil(3101, default_p16, default_k05, 47.231724).
navstivil(3102, default_p16, default_k05, 56.231741).
navstivil(3103, default_p16, default_k05, 56.231741).
navstivil(3104, default_p16, default_k05, 56.231741).
navstivil(3105, default_p16, default_k05, 8.231756).
navstivil(3106, default_p16, default_k05, 8.231756).
navstivil(3107, default_p16, default_k05, 8.231756).
navstivil(3108, default_p16, default_k05, 25.23177).
navstivil(3109, default_p16, default_k05, 25.23177).
navstivil(3110, default_p16, default_k05, 25.23177).
navstivil(3111, default_p16, default_k05, 90.231784).
navstivil(3112, default_p16, default_k05, 90.231784).
navstivil(3113, default_p16, default_k05, 90.231784).
navstivil(3114, default_p16, default_k05, 78.231799).
navstivil(3115, default_p16, default_k05, 78.231799).
navstivil(3116, default_p16, default_k05, 78.231799).
navstivil(3117, default_p16, default_k05, 35.231814).
navstivil(3118, default_p16, default_k05, 35.231814).
navstivil(3119, default_p16, default_k05, 35.231814).
navstivil(3120, default_p16, default_k05, 47.231828).
navstivil(3121, default_p16, default_k05, 47.231828).
navstivil(3122, default_p16, default_k05, 47.231828).
navstivil(3123, default_p16, default_k05, 25.231842).
navstivil(3124, default_p16, default_k05, 25.231842).
navstivil(3125, default_p16, default_k05, 25.231842).
navstivil(3126, default_p16, default_k05, 17.231856).
navstivil(3127, default_p16, default_k05, 17.231856).
navstivil(3128, default_p16, default_k05, 17.231856).
navstivil(3129, default_p16, default_k05, 70.23187).
navstivil(3130, default_p16, default_k05, 70.23187).
navstivil(3131, default_p16, default_k05, 70.23187).
navstivil(3132, default_p16, default_k05, 13.231885).
navstivil(3133, default_p16, default_k05, 13.231885).
navstivil(3134, default_p16, default_k05, 13.231885).
navstivil(3135, default_p16, default_k05, 84.231899).
navstivil(3136, default_p16, default_k05, 84.231899).
navstivil(3137, default_p16, default_k05, 84.231899).
navstivil(3138, default_p16, default_k05, 1.231916).
navstivil(3139, default_p16, default_k05, 1.231916).
navstivil(3140, default_p16, default_k05, 1.231916).
navstivil(3141, default_p16, default_k05, 30.23194).
navstivil(3142, default_p16, default_k05, 30.23194).
navstivil(3143, default_p16, default_k05, 30.23194).
navstivil(3144, default_p16, default_k06, 24.231975).
navstivil(3145, default_p16, default_k06, 24.231975).
navstivil(3146, default_p16, default_k06, 24.231975).
navstivil(3147, default_p16, default_k06, 96.231992).
navstivil(3148, default_p16, default_k06, 96.231992).
navstivil(3149, default_p16, default_k06, 96.231992).
navstivil(3150, default_p16, default_k06, 52.232007).
navstivil(3151, default_p16, default_k06, 52.232007).
navstivil(3152, default_p16, default_k06, 52.232007).
navstivil(3153, default_p16, default_k06, 95.232058).
navstivil(3154, default_p16, default_k06, 95.232058).
navstivil(3155, default_p16, default_k06, 95.232058).
navstivil(3156, default_p16, default_k06, 8.232075).
navstivil(3157, default_p16, default_k06, 8.232075).
navstivil(3158, default_p16, default_k06, 8.232075).
navstivil(3159, default_p16, default_k06, 55.232096).
navstivil(3160, default_p16, default_k06, 55.232096).
navstivil(3161, default_p16, default_k06, 55.232096).
navstivil(3162, default_p16, default_k06, 86.23212).
navstivil(3163, default_p16, default_k06, 86.23212).
navstivil(3164, default_p16, default_k06, 86.23212).
navstivil(3165, default_p16, default_k06, 61.232143).
navstivil(3166, default_p16, default_k06, 61.232143).
navstivil(3167, default_p16, default_k06, 61.232143).
navstivil(3168, default_p16, default_k06, 27.232164).
navstivil(3169, default_p16, default_k06, 27.232164).
navstivil(3170, default_p16, default_k06, 27.232164).
navstivil(3171, default_p16, default_k06, 17.232187).
navstivil(3172, default_p16, default_k06, 17.232187).
navstivil(3173, default_p16, default_k06, 17.232187).
navstivil(3174, default_p16, default_k06, 63.232215).
navstivil(3175, default_p16, default_k06, 63.232215).
navstivil(3176, default_p16, default_k06, 63.232215).
navstivil(3177, default_p16, default_k06, 3.23224).
navstivil(3178, default_p16, default_k06, 3.23224).
navstivil(3179, default_p16, default_k06, 3.23224).
navstivil(3180, default_p16, default_k06, 100.232266).
navstivil(3181, default_p16, default_k06, 100.232266).
navstivil(3182, default_p16, default_k06, 100.232266).
navstivil(3183, default_p16, default_k06, 15.232293).
navstivil(3184, default_p16, default_k06, 15.232293).
navstivil(3185, default_p16, default_k06, 15.232293).
navstivil(3186, default_p16, default_k06, 1.232327).
navstivil(3187, default_p16, default_k06, 1.232327).
navstivil(3188, default_p16, default_k06, 1.232327).
navstivil(3189, default_p16, default_k07, 68.232356).
navstivil(3190, default_p16, default_k07, 68.232356).
navstivil(3191, default_p16, default_k07, 68.232356).
navstivil(3192, default_p16, default_k07, 78.232383).
navstivil(3193, default_p16, default_k07, 78.232383).
navstivil(3194, default_p16, default_k07, 78.232383).
navstivil(3195, default_p16, default_k07, 23.232411).
navstivil(3196, default_p16, default_k07, 23.232411).
navstivil(3197, default_p16, default_k07, 23.232411).
navstivil(3198, default_p16, default_k07, 44.232438).
navstivil(3199, default_p16, default_k07, 44.232438).
navstivil(3200, default_p16, default_k07, 44.232438).
navstivil(3201, default_p16, default_k07, 28.232464).
navstivil(3202, default_p16, default_k07, 28.232464).
navstivil(3203, default_p16, default_k07, 28.232464).
navstivil(3204, default_p16, default_k07, 29.232489).
navstivil(3205, default_p16, default_k07, 29.232489).
navstivil(3206, default_p16, default_k07, 29.232489).
navstivil(3207, default_p16, default_k07, 14.232514).
navstivil(3208, default_p16, default_k07, 14.232514).
navstivil(3209, default_p16, default_k07, 14.232514).
navstivil(3210, default_p16, default_k07, 93.232536).
navstivil(3211, default_p16, default_k07, 93.232536).
navstivil(3212, default_p16, default_k07, 93.232536).
navstivil(3213, default_p16, default_k07, 95.232564).
navstivil(3214, default_p16, default_k07, 95.232564).
navstivil(3215, default_p16, default_k07, 95.232564).
navstivil(3216, default_p16, default_k07, 93.23259).
navstivil(3217, default_p16, default_k07, 93.23259).
navstivil(3218, default_p16, default_k07, 93.23259).
navstivil(3219, default_p16, default_k07, 61.232614).
navstivil(3220, default_p16, default_k07, 61.232614).
navstivil(3221, default_p16, default_k07, 61.232614).
navstivil(3222, default_p16, default_k07, 17.232639).
navstivil(3223, default_p16, default_k07, 17.232639).
navstivil(3224, default_p16, default_k07, 17.232639).
navstivil(3225, default_p16, default_k07, 56.232664).
navstivil(3226, default_p16, default_k07, 56.232664).
navstivil(3227, default_p16, default_k07, 56.232664).
navstivil(3228, default_p16, default_k07, 60.232697).
navstivil(3229, default_p16, default_k07, 60.232697).
navstivil(3230, default_p16, default_k07, 60.232697).
navstivil(3231, default_p16, default_k07, 68.232712).
navstivil(3232, default_p16, default_k07, 68.232712).
navstivil(3233, default_p16, default_k07, 68.232712).
navstivil(3234, default_p16, default_k08, 28.232728).
navstivil(3235, default_p16, default_k08, 28.232728).
navstivil(3236, default_p16, default_k08, 28.232728).
navstivil(3237, default_p16, default_k08, 66.232742).
navstivil(3238, default_p16, default_k08, 66.232742).
navstivil(3239, default_p16, default_k08, 66.232742).
navstivil(3240, default_p16, default_k08, 69.232756).
navstivil(3241, default_p16, default_k08, 69.232756).
navstivil(3242, default_p16, default_k08, 69.232756).
navstivil(3243, default_p16, default_k08, 72.232776).
navstivil(3244, default_p16, default_k08, 72.232776).
navstivil(3245, default_p16, default_k08, 72.232776).
navstivil(3246, default_p16, default_k08, 30.232803).
navstivil(3247, default_p16, default_k08, 30.232803).
navstivil(3248, default_p16, default_k08, 30.232803).
navstivil(3249, default_p16, default_k08, 99.232827).
navstivil(3250, default_p16, default_k08, 99.232827).
navstivil(3251, default_p16, default_k08, 99.232827).
navstivil(3252, default_p16, default_k08, 5.232853).
navstivil(3253, default_p16, default_k08, 5.232853).
navstivil(3254, default_p16, default_k08, 5.232853).
navstivil(3255, default_p16, default_k08, 65.232879).
navstivil(3256, default_p16, default_k08, 65.232879).
navstivil(3257, default_p16, default_k08, 65.232879).
navstivil(3258, default_p16, default_k08, 92.232907).
navstivil(3259, default_p16, default_k08, 92.232907).
navstivil(3260, default_p16, default_k08, 92.232907).
navstivil(3261, default_p16, default_k08, 16.232974).
navstivil(3262, default_p16, default_k08, 16.232974).
navstivil(3263, default_p16, default_k08, 16.232974).
navstivil(3264, default_p16, default_k08, 77.232993).
navstivil(3265, default_p16, default_k08, 77.232993).
navstivil(3266, default_p16, default_k08, 77.232993).
navstivil(3267, default_p16, default_k08, 84.233019).
navstivil(3268, default_p16, default_k08, 84.233019).
navstivil(3269, default_p16, default_k08, 84.233019).
navstivil(3270, default_p16, default_k08, 74.233053).
navstivil(3271, default_p16, default_k08, 74.233053).
navstivil(3272, default_p16, default_k08, 74.233053).
navstivil(3273, default_p16, default_k08, 53.23308).
navstivil(3274, default_p16, default_k08, 53.23308).
navstivil(3275, default_p16, default_k08, 53.23308).
navstivil(3276, default_p16, default_k08, 4.233104).
navstivil(3277, default_p16, default_k08, 4.233104).
navstivil(3278, default_p16, default_k08, 4.233104).
navstivil(3279, default_p16, default_k09, 74.233119).
navstivil(3280, default_p16, default_k09, 74.233119).
navstivil(3281, default_p16, default_k09, 74.233119).
navstivil(3282, default_p16, default_k09, 81.233133).
navstivil(3283, default_p16, default_k09, 81.233133).
navstivil(3284, default_p16, default_k09, 81.233133).
navstivil(3285, default_p16, default_k09, 4.233147).
navstivil(3286, default_p16, default_k09, 4.233147).
navstivil(3287, default_p16, default_k09, 4.233147).
navstivil(3288, default_p16, default_k09, 29.233161).
navstivil(3289, default_p16, default_k09, 29.233161).
navstivil(3290, default_p16, default_k09, 29.233161).
navstivil(3291, default_p16, default_k09, 58.233179).
navstivil(3292, default_p16, default_k09, 58.233179).
navstivil(3293, default_p16, default_k09, 58.233179).
navstivil(3294, default_p16, default_k09, 21.233205).
navstivil(3295, default_p16, default_k09, 21.233205).
navstivil(3296, default_p16, default_k09, 21.233205).
navstivil(3297, default_p16, default_k09, 39.233232).
navstivil(3298, default_p16, default_k09, 39.233232).
navstivil(3299, default_p16, default_k09, 39.233232).
navstivil(3300, default_p16, default_k09, 82.233259).
navstivil(3301, default_p16, default_k09, 82.233259).
navstivil(3302, default_p16, default_k09, 82.233259).
navstivil(3303, default_p16, default_k09, 72.233282).
navstivil(3304, default_p16, default_k09, 72.233282).
navstivil(3305, default_p16, default_k09, 72.233282).
navstivil(3306, default_p16, default_k09, 25.233297).
navstivil(3307, default_p16, default_k09, 25.233297).
navstivil(3308, default_p16, default_k09, 25.233297).
navstivil(3309, default_p16, default_k09, 71.233312).
navstivil(3310, default_p16, default_k09, 71.233312).
navstivil(3311, default_p16, default_k09, 71.233312).
navstivil(3312, default_p16, default_k09, 93.233339).
navstivil(3313, default_p16, default_k09, 93.233339).
navstivil(3314, default_p16, default_k09, 93.233339).
navstivil(3315, default_p16, default_k09, 12.23336).
navstivil(3316, default_p16, default_k09, 12.23336).
navstivil(3317, default_p16, default_k09, 12.23336).
navstivil(3318, default_p16, default_k09, 99.233386).
navstivil(3319, default_p16, default_k09, 99.233386).
navstivil(3320, default_p16, default_k09, 99.233386).
navstivil(3321, default_p16, default_k09, 3.233413).
navstivil(3322, default_p16, default_k09, 3.233413).
navstivil(3323, default_p16, default_k09, 3.233413).
navstivil(3324, default_p16, default_k10, 84.233442).
navstivil(3325, default_p16, default_k10, 84.233442).
navstivil(3326, default_p16, default_k10, 84.233442).
navstivil(3327, default_p16, default_k10, 39.23346).
navstivil(3328, default_p16, default_k10, 39.23346).
navstivil(3329, default_p16, default_k10, 39.23346).
navstivil(3330, default_p16, default_k10, 78.233477).
navstivil(3331, default_p16, default_k10, 78.233477).
navstivil(3332, default_p16, default_k10, 78.233477).
navstivil(3333, default_p16, default_k10, 73.233491).
navstivil(3334, default_p16, default_k10, 73.233491).
navstivil(3335, default_p16, default_k10, 73.233491).
navstivil(3336, default_p16, default_k10, 10.233506).
navstivil(3337, default_p16, default_k10, 10.233506).
navstivil(3338, default_p16, default_k10, 10.233506).
navstivil(3339, default_p16, default_k10, 12.233521).
navstivil(3340, default_p16, default_k10, 12.233521).
navstivil(3341, default_p16, default_k10, 12.233521).
navstivil(3342, default_p16, default_k10, 63.233547).
navstivil(3343, default_p16, default_k10, 63.233547).
navstivil(3344, default_p16, default_k10, 63.233547).
navstivil(3345, default_p16, default_k10, 99.233575).
navstivil(3346, default_p16, default_k10, 99.233575).
navstivil(3347, default_p16, default_k10, 99.233575).
navstivil(3348, default_p16, default_k10, 47.233603).
navstivil(3349, default_p16, default_k10, 47.233603).
navstivil(3350, default_p16, default_k10, 47.233603).
navstivil(3351, default_p16, default_k10, 93.233626).
navstivil(3352, default_p16, default_k10, 93.233626).
navstivil(3353, default_p16, default_k10, 93.233626).
navstivil(3354, default_p16, default_k10, 99.233646).
navstivil(3355, default_p16, default_k10, 99.233646).
navstivil(3356, default_p16, default_k10, 99.233646).
navstivil(3357, default_p16, default_k10, 20.23366).
navstivil(3358, default_p16, default_k10, 20.23366).
navstivil(3359, default_p16, default_k10, 20.23366).
navstivil(3360, default_p16, default_k10, 45.233675).
navstivil(3361, default_p16, default_k10, 45.233675).
navstivil(3362, default_p16, default_k10, 45.233675).
navstivil(3363, default_p16, default_k10, 63.23369).
navstivil(3364, default_p16, default_k10, 63.23369).
navstivil(3365, default_p16, default_k10, 63.23369).
navstivil(3366, default_p16, default_k10, 55.233713).
navstivil(3367, default_p16, default_k10, 55.233713).
navstivil(3368, default_p16, default_k10, 55.233713).
navstivil(3369, default_p17, default_k01, 57.233743).
navstivil(3370, default_p17, default_k01, 57.233743).
navstivil(3371, default_p17, default_k01, 57.233743).
navstivil(3372, default_p17, default_k01, 27.233771).
navstivil(3373, default_p17, default_k01, 27.233771).
navstivil(3374, default_p17, default_k01, 27.233771).
navstivil(3375, default_p17, default_k01, 48.233791).
navstivil(3376, default_p17, default_k01, 48.233791).
navstivil(3377, default_p17, default_k01, 48.233791).
navstivil(3378, default_p17, default_k01, 6.233806).
navstivil(3379, default_p17, default_k01, 6.233806).
navstivil(3380, default_p17, default_k01, 6.233806).
navstivil(3381, default_p17, default_k01, 32.23382).
navstivil(3382, default_p17, default_k01, 32.23382).
navstivil(3383, default_p17, default_k01, 32.23382).
navstivil(3384, default_p17, default_k01, 73.233834).
navstivil(3385, default_p17, default_k01, 73.233834).
navstivil(3386, default_p17, default_k01, 73.233834).
navstivil(3387, default_p17, default_k01, 18.233848).
navstivil(3388, default_p17, default_k01, 18.233848).
navstivil(3389, default_p17, default_k01, 18.233848).
navstivil(3390, default_p17, default_k01, 44.233868).
navstivil(3391, default_p17, default_k01, 44.233868).
navstivil(3392, default_p17, default_k01, 44.233868).
navstivil(3393, default_p17, default_k01, 21.233895).
navstivil(3394, default_p17, default_k01, 21.233895).
navstivil(3395, default_p17, default_k01, 21.233895).
navstivil(3396, default_p17, default_k01, 95.23393).
navstivil(3397, default_p17, default_k01, 95.23393).
navstivil(3398, default_p17, default_k01, 95.23393).
navstivil(3399, default_p17, default_k01, 72.233952).
navstivil(3400, default_p17, default_k01, 72.233952).
navstivil(3401, default_p17, default_k01, 72.233952).
navstivil(3402, default_p17, default_k01, 62.233972).
navstivil(3403, default_p17, default_k01, 62.233972).
navstivil(3404, default_p17, default_k01, 62.233972).
navstivil(3405, default_p17, default_k01, 11.234).
navstivil(3406, default_p17, default_k01, 11.234).
navstivil(3407, default_p17, default_k01, 11.234).
navstivil(3408, default_p17, default_k01, 29.234027).
navstivil(3409, default_p17, default_k01, 29.234027).
navstivil(3410, default_p17, default_k01, 29.234027).
navstivil(3411, default_p17, default_k01, 22.234053).
navstivil(3412, default_p17, default_k01, 22.234053).
navstivil(3413, default_p17, default_k01, 22.234053).
navstivil(3414, default_p17, default_k01, 26.234073).
navstivil(3415, default_p17, default_k01, 26.234073).
navstivil(3416, default_p17, default_k01, 26.234073).
navstivil(3417, default_p17, default_k02, 95.234102).
navstivil(3418, default_p17, default_k02, 95.234102).
navstivil(3419, default_p17, default_k02, 95.234102).
navstivil(3420, default_p17, default_k02, 14.234131).
navstivil(3421, default_p17, default_k02, 14.234131).
navstivil(3422, default_p17, default_k02, 14.234131).
navstivil(3423, default_p17, default_k02, 92.234156).
navstivil(3424, default_p17, default_k02, 92.234156).
navstivil(3425, default_p17, default_k02, 92.234156).
navstivil(3426, default_p17, default_k02, 68.234177).
navstivil(3427, default_p17, default_k02, 68.234177).
navstivil(3428, default_p17, default_k02, 68.234177).
navstivil(3429, default_p17, default_k02, 77.234205).
navstivil(3430, default_p17, default_k02, 77.234205).
navstivil(3431, default_p17, default_k02, 77.234205).
navstivil(3432, default_p17, default_k02, 31.234232).
navstivil(3433, default_p17, default_k02, 31.234232).
navstivil(3434, default_p17, default_k02, 31.234232).
navstivil(3435, default_p17, default_k02, 52.234256).
navstivil(3436, default_p17, default_k02, 52.234256).
navstivil(3437, default_p17, default_k02, 52.234256).
navstivil(3438, default_p17, default_k02, 23.234285).
navstivil(3439, default_p17, default_k02, 23.234285).
navstivil(3440, default_p17, default_k02, 23.234285).
navstivil(3441, default_p17, default_k02, 63.234314).
navstivil(3442, default_p17, default_k02, 63.234314).
navstivil(3443, default_p17, default_k02, 63.234314).
navstivil(3444, default_p17, default_k02, 7.234345).
navstivil(3445, default_p17, default_k02, 7.234345).
navstivil(3446, default_p17, default_k02, 7.234345).
navstivil(3447, default_p17, default_k02, 83.234364).
navstivil(3448, default_p17, default_k02, 83.234364).
navstivil(3449, default_p17, default_k02, 83.234364).
navstivil(3450, default_p17, default_k02, 12.234391).
navstivil(3451, default_p17, default_k02, 12.234391).
navstivil(3452, default_p17, default_k02, 12.234391).
navstivil(3453, default_p17, default_k02, 30.234418).
navstivil(3454, default_p17, default_k02, 30.234418).
navstivil(3455, default_p17, default_k02, 30.234418).
navstivil(3456, default_p17, default_k02, 100.234446).
navstivil(3457, default_p17, default_k02, 100.234446).
navstivil(3458, default_p17, default_k02, 100.234446).
navstivil(3459, default_p17, default_k02, 78.234465).
navstivil(3460, default_p17, default_k02, 78.234465).
navstivil(3461, default_p17, default_k02, 78.234465).
navstivil(3462, default_p17, default_k02, 19.234492).
navstivil(3463, default_p17, default_k02, 19.234492).
navstivil(3464, default_p17, default_k02, 19.234492).
navstivil(3465, default_p17, default_k03, 87.23452).
navstivil(3466, default_p17, default_k03, 87.23452).
navstivil(3467, default_p17, default_k03, 87.23452).
navstivil(3468, default_p17, default_k03, 79.234549).
navstivil(3469, default_p17, default_k03, 79.234549).
navstivil(3470, default_p17, default_k03, 79.234549).
navstivil(3471, default_p17, default_k03, 84.234569).
navstivil(3472, default_p17, default_k03, 84.234569).
navstivil(3473, default_p17, default_k03, 84.234569).
navstivil(3474, default_p17, default_k03, 79.234594).
navstivil(3475, default_p17, default_k03, 79.234594).
navstivil(3476, default_p17, default_k03, 79.234594).
navstivil(3477, default_p17, default_k03, 80.234623).
navstivil(3478, default_p17, default_k03, 80.234623).
navstivil(3479, default_p17, default_k03, 80.234623).
navstivil(3480, default_p17, default_k03, 99.234657).
navstivil(3481, default_p17, default_k03, 99.234657).
navstivil(3482, default_p17, default_k03, 99.234657).
navstivil(3483, default_p17, default_k03, 78.234679).
navstivil(3484, default_p17, default_k03, 78.234679).
navstivil(3485, default_p17, default_k03, 78.234679).
navstivil(3486, default_p17, default_k03, 76.234706).
navstivil(3487, default_p17, default_k03, 76.234706).
navstivil(3488, default_p17, default_k03, 76.234706).
navstivil(3489, default_p17, default_k03, 91.234733).
navstivil(3490, default_p17, default_k03, 91.234733).
navstivil(3491, default_p17, default_k03, 91.234733).
navstivil(3492, default_p17, default_k03, 83.234758).
navstivil(3493, default_p17, default_k03, 83.234758).
navstivil(3494, default_p17, default_k03, 83.234758).
navstivil(3495, default_p17, default_k03, 54.234778).
navstivil(3496, default_p17, default_k03, 54.234778).
navstivil(3497, default_p17, default_k03, 54.234778).
navstivil(3498, default_p17, default_k03, 2.234805).
navstivil(3499, default_p17, default_k03, 2.234805).
navstivil(3500, default_p17, default_k03, 2.234805).
navstivil(3501, default_p17, default_k03, 27.234832).
navstivil(3502, default_p17, default_k03, 27.234832).
navstivil(3503, default_p17, default_k03, 27.234832).
navstivil(3504, default_p17, default_k03, 44.234857).
navstivil(3505, default_p17, default_k03, 44.234857).
navstivil(3506, default_p17, default_k03, 44.234857).
navstivil(3507, default_p17, default_k03, 65.234878).
navstivil(3508, default_p17, default_k03, 65.234878).
navstivil(3509, default_p17, default_k03, 65.234878).
navstivil(3510, default_p17, default_k03, 68.234905).
navstivil(3511, default_p17, default_k03, 68.234905).
navstivil(3512, default_p17, default_k03, 68.234905).
navstivil(3513, default_p17, default_k04, 21.234933).
navstivil(3514, default_p17, default_k04, 21.234933).
navstivil(3515, default_p17, default_k04, 21.234933).
navstivil(3516, default_p17, default_k04, 82.234958).
navstivil(3517, default_p17, default_k04, 82.234958).
navstivil(3518, default_p17, default_k04, 82.234958).
navstivil(3519, default_p17, default_k04, 8.234981).
navstivil(3520, default_p17, default_k04, 8.234981).
navstivil(3521, default_p17, default_k04, 8.234981).
navstivil(3522, default_p17, default_k04, 91.235015).
navstivil(3523, default_p17, default_k04, 91.235015).
navstivil(3524, default_p17, default_k04, 91.235015).
navstivil(3525, default_p17, default_k04, 78.235043).
navstivil(3526, default_p17, default_k04, 78.235043).
navstivil(3527, default_p17, default_k04, 78.235043).
navstivil(3528, default_p17, default_k04, 22.235064).
navstivil(3529, default_p17, default_k04, 22.235064).
navstivil(3530, default_p17, default_k04, 22.235064).
navstivil(3531, default_p17, default_k04, 78.23509).
navstivil(3532, default_p17, default_k04, 78.23509).
navstivil(3533, default_p17, default_k04, 78.23509).
navstivil(3534, default_p17, default_k04, 26.235117).
navstivil(3535, default_p17, default_k04, 26.235117).
navstivil(3536, default_p17, default_k04, 26.235117).
navstivil(3537, default_p17, default_k04, 20.235146).
navstivil(3538, default_p17, default_k04, 20.235146).
navstivil(3539, default_p17, default_k04, 20.235146).
navstivil(3540, default_p17, default_k04, 1.235165).
navstivil(3541, default_p17, default_k04, 1.235165).
navstivil(3542, default_p17, default_k04, 1.235165).
navstivil(3543, default_p17, default_k04, 36.235193).
navstivil(3544, default_p17, default_k04, 36.235193).
navstivil(3545, default_p17, default_k04, 36.235193).
navstivil(3546, default_p17, default_k04, 55.235221).
navstivil(3547, default_p17, default_k04, 55.235221).
navstivil(3548, default_p17, default_k04, 55.235221).
navstivil(3549, default_p17, default_k04, 83.235249).
navstivil(3550, default_p17, default_k04, 83.235249).
navstivil(3551, default_p17, default_k04, 83.235249).
navstivil(3552, default_p17, default_k04, 32.235268).
navstivil(3553, default_p17, default_k04, 32.235268).
navstivil(3554, default_p17, default_k04, 32.235268).
navstivil(3555, default_p17, default_k04, 60.235295).
navstivil(3556, default_p17, default_k04, 60.235295).
navstivil(3557, default_p17, default_k04, 60.235295).
navstivil(3558, default_p17, default_k04, 15.235322).
navstivil(3559, default_p17, default_k04, 15.235322).
navstivil(3560, default_p17, default_k04, 15.235322).
navstivil(3561, default_p17, default_k05, 32.23535).
navstivil(3562, default_p17, default_k05, 32.23535).
navstivil(3563, default_p17, default_k05, 32.23535).
navstivil(3564, default_p17, default_k05, 9.235378).
navstivil(3565, default_p17, default_k05, 9.235378).
navstivil(3566, default_p17, default_k05, 9.235378).
navstivil(3567, default_p17, default_k05, 3.235407).
navstivil(3568, default_p17, default_k05, 3.235407).
navstivil(3569, default_p17, default_k05, 3.235407).
navstivil(3570, default_p17, default_k05, 52.235432).
navstivil(3571, default_p17, default_k05, 52.235432).
navstivil(3572, default_p17, default_k05, 52.235432).
navstivil(3573, default_p17, default_k05, 29.23546).
navstivil(3574, default_p17, default_k05, 29.23546).
navstivil(3575, default_p17, default_k05, 29.23546).
navstivil(3576, default_p17, default_k05, 20.235484).
navstivil(3577, default_p17, default_k05, 20.235484).
navstivil(3578, default_p17, default_k05, 20.235484).
navstivil(3579, default_p17, default_k05, 65.235508).
navstivil(3580, default_p17, default_k05, 65.235508).
navstivil(3581, default_p17, default_k05, 65.235508).
navstivil(3582, default_p17, default_k05, 99.235535).
navstivil(3583, default_p17, default_k05, 99.235535).
navstivil(3584, default_p17, default_k05, 99.235535).
navstivil(3585, default_p17, default_k05, 35.235564).
navstivil(3586, default_p17, default_k05, 35.235564).
navstivil(3587, default_p17, default_k05, 35.235564).
navstivil(3588, default_p17, default_k05, 12.235589).
navstivil(3589, default_p17, default_k05, 12.235589).
navstivil(3590, default_p17, default_k05, 12.235589).
navstivil(3591, default_p17, default_k05, 10.235612).
navstivil(3592, default_p17, default_k05, 10.235612).
navstivil(3593, default_p17, default_k05, 10.235612).
navstivil(3594, default_p17, default_k05, 66.235641).
navstivil(3595, default_p17, default_k05, 66.235641).
navstivil(3596, default_p17, default_k05, 66.235641).
navstivil(3597, default_p17, default_k05, 69.235668).
navstivil(3598, default_p17, default_k05, 69.235668).
navstivil(3599, default_p17, default_k05, 69.235668).
navstivil(3600, default_p17, default_k05, 95.235691).
navstivil(3601, default_p17, default_k05, 95.235691).
navstivil(3602, default_p17, default_k05, 95.235691).
navstivil(3603, default_p17, default_k05, 9.235715).
navstivil(3604, default_p17, default_k05, 9.235715).
navstivil(3605, default_p17, default_k05, 9.235715).
navstivil(3606, default_p17, default_k05, 15.23575).
navstivil(3607, default_p17, default_k05, 15.23575).
navstivil(3608, default_p17, default_k05, 15.23575).
navstivil(3609, default_p17, default_k06, 60.235781).
navstivil(3610, default_p17, default_k06, 60.235781).
navstivil(3611, default_p17, default_k06, 60.235781).
navstivil(3612, default_p17, default_k06, 15.2358).
navstivil(3613, default_p17, default_k06, 15.2358).
navstivil(3614, default_p17, default_k06, 15.2358).
navstivil(3615, default_p17, default_k06, 69.235826).
navstivil(3616, default_p17, default_k06, 69.235826).
navstivil(3617, default_p17, default_k06, 69.235826).
navstivil(3618, default_p17, default_k06, 72.235853).
navstivil(3619, default_p17, default_k06, 72.235853).
navstivil(3620, default_p17, default_k06, 72.235853).
navstivil(3621, default_p17, default_k06, 6.235882).
navstivil(3622, default_p17, default_k06, 6.235882).
navstivil(3623, default_p17, default_k06, 6.235882).
navstivil(3624, default_p17, default_k06, 39.235902).
navstivil(3625, default_p17, default_k06, 39.235902).
navstivil(3626, default_p17, default_k06, 39.235902).
navstivil(3627, default_p17, default_k06, 42.235928).
navstivil(3628, default_p17, default_k06, 42.235928).
navstivil(3629, default_p17, default_k06, 42.235928).
navstivil(3630, default_p17, default_k06, 6.235953).
navstivil(3631, default_p17, default_k06, 6.235953).
navstivil(3632, default_p17, default_k06, 6.235953).
navstivil(3633, default_p17, default_k06, 3.235978).
navstivil(3634, default_p17, default_k06, 3.235978).
navstivil(3635, default_p17, default_k06, 3.235978).
navstivil(3636, default_p17, default_k06, 44.236007).
navstivil(3637, default_p17, default_k06, 44.236007).
navstivil(3638, default_p17, default_k06, 44.236007).
navstivil(3639, default_p17, default_k06, 68.236047).
navstivil(3640, default_p17, default_k06, 68.236047).
navstivil(3641, default_p17, default_k06, 68.236047).
navstivil(3642, default_p17, default_k06, 68.236072).
navstivil(3643, default_p17, default_k06, 68.236072).
navstivil(3644, default_p17, default_k06, 68.236072).
navstivil(3645, default_p17, default_k06, 62.236094).
navstivil(3646, default_p17, default_k06, 62.236094).
navstivil(3647, default_p17, default_k06, 62.236094).
navstivil(3648, default_p17, default_k06, 78.236126).
navstivil(3649, default_p17, default_k06, 78.236126).
navstivil(3650, default_p17, default_k06, 78.236126).
navstivil(3651, default_p17, default_k06, 92.236152).
navstivil(3652, default_p17, default_k06, 92.236152).
navstivil(3653, default_p17, default_k06, 92.236152).
navstivil(3654, default_p17, default_k06, 62.236188).
navstivil(3655, default_p17, default_k06, 62.236188).
navstivil(3656, default_p17, default_k06, 62.236188).
navstivil(3657, default_p17, default_k07, 84.236211).
navstivil(3658, default_p17, default_k07, 84.236211).
navstivil(3659, default_p17, default_k07, 84.236211).
navstivil(3660, default_p17, default_k07, 64.236231).
navstivil(3661, default_p17, default_k07, 64.236231).
navstivil(3662, default_p17, default_k07, 64.236231).
navstivil(3663, default_p17, default_k07, 38.236255).
navstivil(3664, default_p17, default_k07, 38.236255).
navstivil(3665, default_p17, default_k07, 38.236255).
navstivil(3666, default_p17, default_k07, 52.236278).
navstivil(3667, default_p17, default_k07, 52.236278).
navstivil(3668, default_p17, default_k07, 52.236278).
navstivil(3669, default_p17, default_k07, 96.236302).
navstivil(3670, default_p17, default_k07, 96.236302).
navstivil(3671, default_p17, default_k07, 96.236302).
navstivil(3672, default_p17, default_k07, 51.236324).
navstivil(3673, default_p17, default_k07, 51.236324).
navstivil(3674, default_p17, default_k07, 51.236324).
navstivil(3675, default_p17, default_k07, 25.236346).
navstivil(3676, default_p17, default_k07, 25.236346).
navstivil(3677, default_p17, default_k07, 25.236346).
navstivil(3678, default_p17, default_k07, 88.236366).
navstivil(3679, default_p17, default_k07, 88.236366).
navstivil(3680, default_p17, default_k07, 88.236366).
navstivil(3681, default_p17, default_k07, 21.236386).
navstivil(3682, default_p17, default_k07, 21.236386).
navstivil(3683, default_p17, default_k07, 21.236386).
navstivil(3684, default_p17, default_k07, 82.23641).
navstivil(3685, default_p17, default_k07, 82.23641).
navstivil(3686, default_p17, default_k07, 82.23641).
navstivil(3687, default_p17, default_k07, 64.236434).
navstivil(3688, default_p17, default_k07, 64.236434).
navstivil(3689, default_p17, default_k07, 64.236434).
navstivil(3690, default_p17, default_k07, 56.236482).
navstivil(3691, default_p17, default_k07, 56.236482).
navstivil(3692, default_p17, default_k07, 56.236482).
navstivil(3693, default_p17, default_k07, 24.236515).
navstivil(3694, default_p17, default_k07, 24.236515).
navstivil(3695, default_p17, default_k07, 24.236515).
navstivil(3696, default_p17, default_k07, 14.236551).
navstivil(3697, default_p17, default_k07, 14.236551).
navstivil(3698, default_p17, default_k07, 14.236551).
navstivil(3699, default_p17, default_k07, 42.236569).
navstivil(3700, default_p17, default_k07, 42.236569).
navstivil(3701, default_p17, default_k07, 42.236569).
navstivil(3702, default_p17, default_k07, 79.236583).
navstivil(3703, default_p17, default_k07, 79.236583).
navstivil(3704, default_p17, default_k07, 79.236583).
navstivil(3705, default_p17, default_k08, 98.236609).
navstivil(3706, default_p17, default_k08, 98.236609).
navstivil(3707, default_p17, default_k08, 98.236609).
navstivil(3708, default_p17, default_k08, 5.236644).
navstivil(3709, default_p17, default_k08, 5.236644).
navstivil(3710, default_p17, default_k08, 5.236644).
navstivil(3711, default_p17, default_k08, 74.236671).
navstivil(3712, default_p17, default_k08, 74.236671).
navstivil(3713, default_p17, default_k08, 74.236671).
navstivil(3714, default_p17, default_k08, 62.236696).
navstivil(3715, default_p17, default_k08, 62.236696).
navstivil(3716, default_p17, default_k08, 62.236696).
navstivil(3717, default_p17, default_k08, 84.236751).
navstivil(3718, default_p17, default_k08, 84.236751).
navstivil(3719, default_p17, default_k08, 84.236751).
navstivil(3720, default_p17, default_k08, 65.236791).
navstivil(3721, default_p17, default_k08, 65.236791).
navstivil(3722, default_p17, default_k08, 65.236791).
navstivil(3723, default_p17, default_k08, 26.236824).
navstivil(3724, default_p17, default_k08, 26.236824).
navstivil(3725, default_p17, default_k08, 26.236824).
navstivil(3726, default_p17, default_k08, 37.236851).
navstivil(3727, default_p17, default_k08, 37.236851).
navstivil(3728, default_p17, default_k08, 37.236851).
navstivil(3729, default_p17, default_k08, 37.236877).
navstivil(3730, default_p17, default_k08, 37.236877).
navstivil(3731, default_p17, default_k08, 37.236877).
navstivil(3732, default_p17, default_k08, 100.237013).
navstivil(3733, default_p17, default_k08, 100.237013).
navstivil(3734, default_p17, default_k08, 100.237013).
navstivil(3735, default_p17, default_k08, 74.23706).
navstivil(3736, default_p17, default_k08, 74.23706).
navstivil(3737, default_p17, default_k08, 74.23706).
navstivil(3738, default_p17, default_k08, 24.237087).
navstivil(3739, default_p17, default_k08, 24.237087).
navstivil(3740, default_p17, default_k08, 24.237087).
navstivil(3741, default_p17, default_k08, 88.237109).
navstivil(3742, default_p17, default_k08, 88.237109).
navstivil(3743, default_p17, default_k08, 88.237109).
navstivil(3744, default_p17, default_k08, 28.237135).
navstivil(3745, default_p17, default_k08, 28.237135).
navstivil(3746, default_p17, default_k08, 28.237135).
navstivil(3747, default_p17, default_k08, 29.237161).
navstivil(3748, default_p17, default_k08, 29.237161).
navstivil(3749, default_p17, default_k08, 29.237161).
navstivil(3750, default_p17, default_k08, 30.237185).
navstivil(3751, default_p17, default_k08, 30.237185).
navstivil(3752, default_p17, default_k08, 30.237185).
navstivil(3753, default_p17, default_k09, 69.237226).
navstivil(3754, default_p17, default_k09, 69.237226).
navstivil(3755, default_p17, default_k09, 69.237226).
navstivil(3756, default_p17, default_k09, 85.237358).
navstivil(3757, default_p17, default_k09, 85.237358).
navstivil(3758, default_p17, default_k09, 85.237358).
navstivil(3759, default_p17, default_k09, 32.237436).
navstivil(3760, default_p17, default_k09, 32.237436).
navstivil(3761, default_p17, default_k09, 32.237436).
navstivil(3762, default_p17, default_k09, 58.237476).
navstivil(3763, default_p17, default_k09, 58.237476).
navstivil(3764, default_p17, default_k09, 58.237476).
navstivil(3765, default_p17, default_k09, 38.237508).
navstivil(3766, default_p17, default_k09, 38.237508).
navstivil(3767, default_p17, default_k09, 38.237508).
navstivil(3768, default_p17, default_k09, 52.23754).
navstivil(3769, default_p17, default_k09, 52.23754).
navstivil(3770, default_p17, default_k09, 52.23754).
navstivil(3771, default_p17, default_k09, 65.237574).
navstivil(3772, default_p17, default_k09, 65.237574).
navstivil(3773, default_p17, default_k09, 65.237574).
navstivil(3774, default_p17, default_k09, 92.237604).
navstivil(3775, default_p17, default_k09, 92.237604).
navstivil(3776, default_p17, default_k09, 92.237604).
navstivil(3777, default_p17, default_k09, 26.237621).
navstivil(3778, default_p17, default_k09, 26.237621).
navstivil(3779, default_p17, default_k09, 26.237621).
navstivil(3780, default_p17, default_k09, 60.237654).
navstivil(3781, default_p17, default_k09, 60.237654).
navstivil(3782, default_p17, default_k09, 60.237654).
navstivil(3783, default_p17, default_k09, 45.237688).
navstivil(3784, default_p17, default_k09, 45.237688).
navstivil(3785, default_p17, default_k09, 45.237688).
navstivil(3786, default_p17, default_k09, 6.237732).
navstivil(3787, default_p17, default_k09, 6.237732).
navstivil(3788, default_p17, default_k09, 6.237732).
navstivil(3789, default_p17, default_k09, 99.23777).
navstivil(3790, default_p17, default_k09, 99.23777).
navstivil(3791, default_p17, default_k09, 99.23777).
navstivil(3792, default_p17, default_k09, 93.237811).
navstivil(3793, default_p17, default_k09, 93.237811).
navstivil(3794, default_p17, default_k09, 93.237811).
navstivil(3795, default_p17, default_k09, 48.237847).
navstivil(3796, default_p17, default_k09, 48.237847).
navstivil(3797, default_p17, default_k09, 48.237847).
navstivil(3798, default_p17, default_k09, 65.237886).
navstivil(3799, default_p17, default_k09, 65.237886).
navstivil(3800, default_p17, default_k09, 65.237886).
navstivil(3801, default_p17, default_k10, 93.237917).
navstivil(3802, default_p17, default_k10, 93.237917).
navstivil(3803, default_p17, default_k10, 93.237917).
navstivil(3804, default_p17, default_k10, 38.237957).
navstivil(3805, default_p17, default_k10, 38.237957).
navstivil(3806, default_p17, default_k10, 38.237957).
navstivil(3807, default_p17, default_k10, 59.237992).
navstivil(3808, default_p17, default_k10, 59.237992).
navstivil(3809, default_p17, default_k10, 59.237992).
navstivil(3810, default_p17, default_k10, 69.23802).
navstivil(3811, default_p17, default_k10, 69.23802).
navstivil(3812, default_p17, default_k10, 69.23802).
navstivil(3813, default_p17, default_k10, 93.238049).
navstivil(3814, default_p17, default_k10, 93.238049).
navstivil(3815, default_p17, default_k10, 93.238049).
navstivil(3816, default_p17, default_k10, 77.238095).
navstivil(3817, default_p17, default_k10, 77.238095).
navstivil(3818, default_p17, default_k10, 77.238095).
navstivil(3819, default_p17, default_k10, 45.238131).
navstivil(3820, default_p17, default_k10, 45.238131).
navstivil(3821, default_p17, default_k10, 45.238131).
navstivil(3822, default_p17, default_k10, 9.238161).
navstivil(3823, default_p17, default_k10, 9.238161).
navstivil(3824, default_p17, default_k10, 9.238161).
navstivil(3825, default_p17, default_k10, 86.238195).
navstivil(3826, default_p17, default_k10, 86.238195).
navstivil(3827, default_p17, default_k10, 86.238195).
navstivil(3828, default_p17, default_k10, 53.238239).
navstivil(3829, default_p17, default_k10, 53.238239).
navstivil(3830, default_p17, default_k10, 53.238239).
navstivil(3831, default_p17, default_k10, 54.238275).
navstivil(3832, default_p17, default_k10, 54.238275).
navstivil(3833, default_p17, default_k10, 54.238275).
navstivil(3834, default_p17, default_k10, 81.238312).
navstivil(3835, default_p17, default_k10, 81.238312).
navstivil(3836, default_p17, default_k10, 81.238312).
navstivil(3837, default_p17, default_k10, 55.238341).
navstivil(3838, default_p17, default_k10, 55.238341).
navstivil(3839, default_p17, default_k10, 55.238341).
navstivil(3840, default_p17, default_k10, 38.238376).
navstivil(3841, default_p17, default_k10, 38.238376).
navstivil(3842, default_p17, default_k10, 38.238376).
navstivil(3843, default_p17, default_k10, 8.238403).
navstivil(3844, default_p17, default_k10, 8.238403).
navstivil(3845, default_p17, default_k10, 8.238403).
navstivil(3846, default_p17, default_k10, 53.238431).
navstivil(3847, default_p17, default_k10, 53.238431).
navstivil(3848, default_p17, default_k10, 53.238431).
navstivil(3849, default_p18, default_k01, 51.238471).
navstivil(3850, default_p18, default_k01, 51.238471).
navstivil(3851, default_p18, default_k01, 51.238471).
navstivil(3852, default_p18, default_k01, 87.238503).
navstivil(3853, default_p18, default_k01, 87.238503).
navstivil(3854, default_p18, default_k01, 87.238503).
navstivil(3855, default_p18, default_k01, 64.238527).
navstivil(3856, default_p18, default_k01, 64.238527).
navstivil(3857, default_p18, default_k01, 64.238527).
navstivil(3858, default_p18, default_k01, 71.238575).
navstivil(3859, default_p18, default_k01, 71.238575).
navstivil(3860, default_p18, default_k01, 71.238575).
navstivil(3861, default_p18, default_k01, 98.238607).
navstivil(3862, default_p18, default_k01, 98.238607).
navstivil(3863, default_p18, default_k01, 98.238607).
navstivil(3864, default_p18, default_k01, 10.238643).
navstivil(3865, default_p18, default_k01, 10.238643).
navstivil(3866, default_p18, default_k01, 10.238643).
navstivil(3867, default_p18, default_k01, 71.238678).
navstivil(3868, default_p18, default_k01, 71.238678).
navstivil(3869, default_p18, default_k01, 71.238678).
navstivil(3870, default_p18, default_k01, 67.23871).
navstivil(3871, default_p18, default_k01, 67.23871).
navstivil(3872, default_p18, default_k01, 67.23871).
navstivil(3873, default_p18, default_k01, 95.238748).
navstivil(3874, default_p18, default_k01, 95.238748).
navstivil(3875, default_p18, default_k01, 95.238748).
navstivil(3876, default_p18, default_k01, 44.23878).
navstivil(3877, default_p18, default_k01, 44.23878).
navstivil(3878, default_p18, default_k01, 44.23878).
navstivil(3879, default_p18, default_k01, 18.238814).
navstivil(3880, default_p18, default_k01, 18.238814).
navstivil(3881, default_p18, default_k01, 18.238814).
navstivil(3882, default_p18, default_k01, 95.23884).
navstivil(3883, default_p18, default_k01, 95.23884).
navstivil(3884, default_p18, default_k01, 95.23884).
navstivil(3885, default_p18, default_k01, 58.238862).
navstivil(3886, default_p18, default_k01, 58.238862).
navstivil(3887, default_p18, default_k01, 58.238862).
navstivil(3888, default_p18, default_k01, 65.238896).
navstivil(3889, default_p18, default_k01, 65.238896).
navstivil(3890, default_p18, default_k01, 65.238896).
navstivil(3891, default_p18, default_k01, 6.238924).
navstivil(3892, default_p18, default_k01, 6.238924).
navstivil(3893, default_p18, default_k01, 6.238924).
navstivil(3894, default_p18, default_k01, 80.238948).
navstivil(3895, default_p18, default_k01, 80.238948).
navstivil(3896, default_p18, default_k01, 80.238948).
navstivil(3897, default_p18, default_k01, 33.238977).
navstivil(3898, default_p18, default_k01, 33.238977).
navstivil(3899, default_p18, default_k01, 33.238977).
navstivil(3900, default_p18, default_k02, 31.239021).
navstivil(3901, default_p18, default_k02, 31.239021).
navstivil(3902, default_p18, default_k02, 31.239021).
navstivil(3903, default_p18, default_k02, 36.239044).
navstivil(3904, default_p18, default_k02, 36.239044).
navstivil(3905, default_p18, default_k02, 36.239044).
navstivil(3906, default_p18, default_k02, 34.239072).
navstivil(3907, default_p18, default_k02, 34.239072).
navstivil(3908, default_p18, default_k02, 34.239072).
navstivil(3909, default_p18, default_k02, 45.239103).
navstivil(3910, default_p18, default_k02, 45.239103).
navstivil(3911, default_p18, default_k02, 45.239103).
navstivil(3912, default_p18, default_k02, 38.239133).
navstivil(3913, default_p18, default_k02, 38.239133).
navstivil(3914, default_p18, default_k02, 38.239133).
navstivil(3915, default_p18, default_k02, 57.239159).
navstivil(3916, default_p18, default_k02, 57.239159).
navstivil(3917, default_p18, default_k02, 57.239159).
navstivil(3918, default_p18, default_k02, 70.239182).
navstivil(3919, default_p18, default_k02, 70.239182).
navstivil(3920, default_p18, default_k02, 70.239182).
navstivil(3921, default_p18, default_k02, 91.239217).
navstivil(3922, default_p18, default_k02, 91.239217).
navstivil(3923, default_p18, default_k02, 91.239217).
navstivil(3924, default_p18, default_k02, 66.23925).
navstivil(3925, default_p18, default_k02, 66.23925).
navstivil(3926, default_p18, default_k02, 66.23925).
navstivil(3927, default_p18, default_k02, 77.239289).
navstivil(3928, default_p18, default_k02, 77.239289).
navstivil(3929, default_p18, default_k02, 77.239289).
navstivil(3930, default_p18, default_k02, 83.239313).
navstivil(3931, default_p18, default_k02, 83.239313).
navstivil(3932, default_p18, default_k02, 83.239313).
navstivil(3933, default_p18, default_k02, 15.239339).
navstivil(3934, default_p18, default_k02, 15.239339).
navstivil(3935, default_p18, default_k02, 15.239339).
navstivil(3936, default_p18, default_k02, 85.239367).
navstivil(3937, default_p18, default_k02, 85.239367).
navstivil(3938, default_p18, default_k02, 85.239367).
navstivil(3939, default_p18, default_k02, 100.239396).
navstivil(3940, default_p18, default_k02, 100.239396).
navstivil(3941, default_p18, default_k02, 100.239396).
navstivil(3942, default_p18, default_k02, 47.239461).
navstivil(3943, default_p18, default_k02, 47.239461).
navstivil(3944, default_p18, default_k02, 47.239461).
navstivil(3945, default_p18, default_k02, 31.239486).
navstivil(3946, default_p18, default_k02, 31.239486).
navstivil(3947, default_p18, default_k02, 31.239486).
navstivil(3948, default_p18, default_k02, 84.239508).
navstivil(3949, default_p18, default_k02, 84.239508).
navstivil(3950, default_p18, default_k02, 84.239508).
navstivil(3951, default_p18, default_k03, 53.239538).
navstivil(3952, default_p18, default_k03, 53.239538).
navstivil(3953, default_p18, default_k03, 53.239538).
navstivil(3954, default_p18, default_k03, 90.239571).
navstivil(3955, default_p18, default_k03, 90.239571).
navstivil(3956, default_p18, default_k03, 90.239571).
navstivil(3957, default_p18, default_k03, 84.239604).
navstivil(3958, default_p18, default_k03, 84.239604).
navstivil(3959, default_p18, default_k03, 84.239604).
navstivil(3960, default_p18, default_k03, 32.239637).
navstivil(3961, default_p18, default_k03, 32.239637).
navstivil(3962, default_p18, default_k03, 32.239637).
navstivil(3963, default_p18, default_k03, 38.239775).
navstivil(3964, default_p18, default_k03, 38.239775).
navstivil(3965, default_p18, default_k03, 38.239775).
navstivil(3966, default_p18, default_k03, 26.239802).
navstivil(3967, default_p18, default_k03, 26.239802).
navstivil(3968, default_p18, default_k03, 26.239802).
navstivil(3969, default_p18, default_k03, 24.239829).
navstivil(3970, default_p18, default_k03, 24.239829).
navstivil(3971, default_p18, default_k03, 24.239829).
navstivil(3972, default_p18, default_k03, 77.239857).
navstivil(3973, default_p18, default_k03, 77.239857).
navstivil(3974, default_p18, default_k03, 77.239857).
navstivil(3975, default_p18, default_k03, 42.239882).
navstivil(3976, default_p18, default_k03, 42.239882).
navstivil(3977, default_p18, default_k03, 42.239882).
navstivil(3978, default_p18, default_k03, 37.239905).
navstivil(3979, default_p18, default_k03, 37.239905).
navstivil(3980, default_p18, default_k03, 37.239905).
navstivil(3981, default_p18, default_k03, 31.239926).
navstivil(3982, default_p18, default_k03, 31.239926).
navstivil(3983, default_p18, default_k03, 31.239926).
navstivil(3984, default_p18, default_k03, 73.239967).
navstivil(3985, default_p18, default_k03, 73.239967).
navstivil(3986, default_p18, default_k03, 73.239967).
navstivil(3987, default_p18, default_k03, 78.239994).
navstivil(3988, default_p18, default_k03, 78.239994).
navstivil(3989, default_p18, default_k03, 78.239994).
navstivil(3990, default_p18, default_k03, 27.240109).
navstivil(3991, default_p18, default_k03, 27.240109).
navstivil(3992, default_p18, default_k03, 27.240109).
navstivil(3993, default_p18, default_k03, 58.24018).
navstivil(3994, default_p18, default_k03, 58.24018).
navstivil(3995, default_p18, default_k03, 58.24018).
navstivil(3996, default_p18, default_k03, 69.240205).
navstivil(3997, default_p18, default_k03, 69.240205).
navstivil(3998, default_p18, default_k03, 69.240205).
navstivil(3999, default_p18, default_k03, 88.240232).
navstivil(4000, default_p18, default_k03, 88.240232).
navstivil(4001, default_p18, default_k03, 88.240232).
navstivil(4002, default_p18, default_k04, 54.240258).
navstivil(4003, default_p18, default_k04, 54.240258).
navstivil(4004, default_p18, default_k04, 54.240258).
navstivil(4005, default_p18, default_k04, 18.240281).
navstivil(4006, default_p18, default_k04, 18.240281).
navstivil(4007, default_p18, default_k04, 18.240281).
navstivil(4008, default_p18, default_k04, 40.240302).
navstivil(4009, default_p18, default_k04, 40.240302).
navstivil(4010, default_p18, default_k04, 40.240302).
navstivil(4011, default_p18, default_k04, 16.240324).
navstivil(4012, default_p18, default_k04, 16.240324).
navstivil(4013, default_p18, default_k04, 16.240324).
navstivil(4014, default_p18, default_k04, 86.240344).
navstivil(4015, default_p18, default_k04, 86.240344).
navstivil(4016, default_p18, default_k04, 86.240344).
navstivil(4017, default_p18, default_k04, 41.240368).
navstivil(4018, default_p18, default_k04, 41.240368).
navstivil(4019, default_p18, default_k04, 41.240368).
navstivil(4020, default_p18, default_k04, 11.240386).
navstivil(4021, default_p18, default_k04, 11.240386).
navstivil(4022, default_p18, default_k04, 11.240386).
navstivil(4023, default_p18, default_k04, 9.240409).
navstivil(4024, default_p18, default_k04, 9.240409).
navstivil(4025, default_p18, default_k04, 9.240409).
navstivil(4026, default_p18, default_k04, 47.240454).
navstivil(4027, default_p18, default_k04, 47.240454).
navstivil(4028, default_p18, default_k04, 47.240454).
navstivil(4029, default_p18, default_k04, 6.2404910000000005).
navstivil(4030, default_p18, default_k04, 6.2404910000000005).
navstivil(4031, default_p18, default_k04, 6.2404910000000005).
navstivil(4032, default_p18, default_k04, 8.240531).
navstivil(4033, default_p18, default_k04, 8.240531).
navstivil(4034, default_p18, default_k04, 8.240531).
navstivil(4035, default_p18, default_k04, 43.240574).
navstivil(4036, default_p18, default_k04, 43.240574).
navstivil(4037, default_p18, default_k04, 43.240574).
navstivil(4038, default_p18, default_k04, 90.240604).
navstivil(4039, default_p18, default_k04, 90.240604).
navstivil(4040, default_p18, default_k04, 90.240604).
navstivil(4041, default_p18, default_k04, 91.240639).
navstivil(4042, default_p18, default_k04, 91.240639).
navstivil(4043, default_p18, default_k04, 91.240639).
navstivil(4044, default_p18, default_k04, 40.240676).
navstivil(4045, default_p18, default_k04, 40.240676).
navstivil(4046, default_p18, default_k04, 40.240676).
navstivil(4047, default_p18, default_k04, 77.240707).
navstivil(4048, default_p18, default_k04, 77.240707).
navstivil(4049, default_p18, default_k04, 77.240707).
navstivil(4050, default_p18, default_k04, 87.24073).
navstivil(4051, default_p18, default_k04, 87.24073).
navstivil(4052, default_p18, default_k04, 87.24073).
navstivil(4053, default_p18, default_k05, 42.240761).
navstivil(4054, default_p18, default_k05, 42.240761).
navstivil(4055, default_p18, default_k05, 42.240761).
navstivil(4056, default_p18, default_k05, 74.240788).
navstivil(4057, default_p18, default_k05, 74.240788).
navstivil(4058, default_p18, default_k05, 74.240788).
navstivil(4059, default_p18, default_k05, 14.240823).
navstivil(4060, default_p18, default_k05, 14.240823).
navstivil(4061, default_p18, default_k05, 14.240823).
navstivil(4062, default_p18, default_k05, 90.240852).
navstivil(4063, default_p18, default_k05, 90.240852).
navstivil(4064, default_p18, default_k05, 90.240852).
navstivil(4065, default_p18, default_k05, 38.24087).
navstivil(4066, default_p18, default_k05, 38.24087).
navstivil(4067, default_p18, default_k05, 38.24087).
navstivil(4068, default_p18, default_k05, 61.240913).
navstivil(4069, default_p18, default_k05, 61.240913).
navstivil(4070, default_p18, default_k05, 61.240913).
navstivil(4071, default_p18, default_k05, 5.240938).
navstivil(4072, default_p18, default_k05, 5.240938).
navstivil(4073, default_p18, default_k05, 5.240938).
navstivil(4074, default_p18, default_k05, 3.240976).
navstivil(4075, default_p18, default_k05, 3.240976).
navstivil(4076, default_p18, default_k05, 3.240976).
navstivil(4077, default_p18, default_k05, 58.24101).
navstivil(4078, default_p18, default_k05, 58.24101).
navstivil(4079, default_p18, default_k05, 58.24101).
navstivil(4080, default_p18, default_k05, 56.24104).
navstivil(4081, default_p18, default_k05, 56.24104).
navstivil(4082, default_p18, default_k05, 56.24104).
navstivil(4083, default_p18, default_k05, 31.241084999999998).
navstivil(4084, default_p18, default_k05, 31.241084999999998).
navstivil(4085, default_p18, default_k05, 31.241084999999998).
navstivil(4086, default_p18, default_k05, 93.241119).
navstivil(4087, default_p18, default_k05, 93.241119).
navstivil(4088, default_p18, default_k05, 93.241119).
navstivil(4089, default_p18, default_k05, 27.241156).
navstivil(4090, default_p18, default_k05, 27.241156).
navstivil(4091, default_p18, default_k05, 27.241156).
navstivil(4092, default_p18, default_k05, 58.24119).
navstivil(4093, default_p18, default_k05, 58.24119).
navstivil(4094, default_p18, default_k05, 58.24119).
navstivil(4095, default_p18, default_k05, 37.241232).
navstivil(4096, default_p18, default_k05, 37.241232).
navstivil(4097, default_p18, default_k05, 37.241232).
navstivil(4098, default_p18, default_k05, 79.241279).
navstivil(4099, default_p18, default_k05, 79.241279).
navstivil(4100, default_p18, default_k05, 79.241279).
navstivil(4101, default_p18, default_k05, 31.241332).
navstivil(4102, default_p18, default_k05, 31.241332).
navstivil(4103, default_p18, default_k05, 31.241332).
navstivil(4104, default_p18, default_k06, 94.241365).
navstivil(4105, default_p18, default_k06, 94.241365).
navstivil(4106, default_p18, default_k06, 94.241365).
navstivil(4107, default_p18, default_k06, 46.241403).
navstivil(4108, default_p18, default_k06, 46.241403).
navstivil(4109, default_p18, default_k06, 46.241403).
navstivil(4110, default_p18, default_k06, 58.241494).
navstivil(4111, default_p18, default_k06, 58.241494).
navstivil(4112, default_p18, default_k06, 58.241494).
navstivil(4113, default_p18, default_k06, 35.241538).
navstivil(4114, default_p18, default_k06, 35.241538).
navstivil(4115, default_p18, default_k06, 35.241538).
navstivil(4116, default_p18, default_k06, 61.241576).
navstivil(4117, default_p18, default_k06, 61.241576).
navstivil(4118, default_p18, default_k06, 61.241576).
navstivil(4119, default_p18, default_k06, 70.241622).
navstivil(4120, default_p18, default_k06, 70.241622).
navstivil(4121, default_p18, default_k06, 70.241622).
navstivil(4122, default_p18, default_k06, 65.241663).
navstivil(4123, default_p18, default_k06, 65.241663).
navstivil(4124, default_p18, default_k06, 65.241663).
navstivil(4125, default_p18, default_k06, 29.241721).
navstivil(4126, default_p18, default_k06, 29.241721).
navstivil(4127, default_p18, default_k06, 29.241721).
navstivil(4128, default_p18, default_k06, 44.241771).
navstivil(4129, default_p18, default_k06, 44.241771).
navstivil(4130, default_p18, default_k06, 44.241771).
navstivil(4131, default_p18, default_k06, 15.24182).
navstivil(4132, default_p18, default_k06, 15.24182).
navstivil(4133, default_p18, default_k06, 15.24182).
navstivil(4134, default_p18, default_k06, 7.241854).
navstivil(4135, default_p18, default_k06, 7.241854).
navstivil(4136, default_p18, default_k06, 7.241854).
navstivil(4137, default_p18, default_k06, 30.241878).
navstivil(4138, default_p18, default_k06, 30.241878).
navstivil(4139, default_p18, default_k06, 30.241878).
navstivil(4140, default_p18, default_k06, 49.241911).
navstivil(4141, default_p18, default_k06, 49.241911).
navstivil(4142, default_p18, default_k06, 49.241911).
navstivil(4143, default_p18, default_k06, 74.241947).
navstivil(4144, default_p18, default_k06, 74.241947).
navstivil(4145, default_p18, default_k06, 74.241947).
navstivil(4146, default_p18, default_k06, 48.241989).
navstivil(4147, default_p18, default_k06, 48.241989).
navstivil(4148, default_p18, default_k06, 48.241989).
navstivil(4149, default_p18, default_k06, 49.242028).
navstivil(4150, default_p18, default_k06, 49.242028).
navstivil(4151, default_p18, default_k06, 49.242028).
navstivil(4152, default_p18, default_k06, 94.242096).
navstivil(4153, default_p18, default_k06, 94.242096).
navstivil(4154, default_p18, default_k06, 94.242096).
navstivil(4155, default_p18, default_k07, 32.242149).
navstivil(4156, default_p18, default_k07, 32.242149).
navstivil(4157, default_p18, default_k07, 32.242149).
navstivil(4158, default_p18, default_k07, 1.242186).
navstivil(4159, default_p18, default_k07, 1.242186).
navstivil(4160, default_p18, default_k07, 1.242186).
navstivil(4161, default_p18, default_k07, 66.242215).
navstivil(4162, default_p18, default_k07, 66.242215).
navstivil(4163, default_p18, default_k07, 66.242215).
navstivil(4164, default_p18, default_k07, 49.242245).
navstivil(4165, default_p18, default_k07, 49.242245).
navstivil(4166, default_p18, default_k07, 49.242245).
navstivil(4167, default_p18, default_k07, 53.242274).
navstivil(4168, default_p18, default_k07, 53.242274).
navstivil(4169, default_p18, default_k07, 53.242274).
navstivil(4170, default_p18, default_k07, 53.242312).
navstivil(4171, default_p18, default_k07, 53.242312).
navstivil(4172, default_p18, default_k07, 53.242312).
navstivil(4173, default_p18, default_k07, 10.242348).
navstivil(4174, default_p18, default_k07, 10.242348).
navstivil(4175, default_p18, default_k07, 10.242348).
navstivil(4176, default_p18, default_k07, 87.242374).
navstivil(4177, default_p18, default_k07, 87.242374).
navstivil(4178, default_p18, default_k07, 87.242374).
navstivil(4179, default_p18, default_k07, 98.2424).
navstivil(4180, default_p18, default_k07, 98.2424).
navstivil(4181, default_p18, default_k07, 98.2424).
navstivil(4182, default_p18, default_k07, 27.242431).
navstivil(4183, default_p18, default_k07, 27.242431).
navstivil(4184, default_p18, default_k07, 27.242431).
navstivil(4185, default_p18, default_k07, 1.242473).
navstivil(4186, default_p18, default_k07, 1.242473).
navstivil(4187, default_p18, default_k07, 1.242473).
navstivil(4188, default_p18, default_k07, 22.242514).
navstivil(4189, default_p18, default_k07, 22.242514).
navstivil(4190, default_p18, default_k07, 22.242514).
navstivil(4191, default_p18, default_k07, 96.242552).
navstivil(4192, default_p18, default_k07, 96.242552).
navstivil(4193, default_p18, default_k07, 96.242552).
navstivil(4194, default_p18, default_k07, 72.242626).
navstivil(4195, default_p18, default_k07, 72.242626).
navstivil(4196, default_p18, default_k07, 72.242626).
navstivil(4197, default_p18, default_k07, 50.24268).
navstivil(4198, default_p18, default_k07, 50.24268).
navstivil(4199, default_p18, default_k07, 50.24268).
navstivil(4200, default_p18, default_k07, 100.242716).
navstivil(4201, default_p18, default_k07, 100.242716).
navstivil(4202, default_p18, default_k07, 100.242716).
navstivil(4203, default_p18, default_k07, 64.242755).
navstivil(4204, default_p18, default_k07, 64.242755).
navstivil(4205, default_p18, default_k07, 64.242755).
navstivil(4206, default_p18, default_k08, 9.242794).
navstivil(4207, default_p18, default_k08, 9.242794).
navstivil(4208, default_p18, default_k08, 9.242794).
navstivil(4209, default_p18, default_k08, 93.242831).
navstivil(4210, default_p18, default_k08, 93.242831).
navstivil(4211, default_p18, default_k08, 93.242831).
navstivil(4212, default_p18, default_k08, 22.242854).
navstivil(4213, default_p18, default_k08, 22.242854).
navstivil(4214, default_p18, default_k08, 22.242854).
navstivil(4215, default_p18, default_k08, 37.242878).
navstivil(4216, default_p18, default_k08, 37.242878).
navstivil(4217, default_p18, default_k08, 37.242878).
navstivil(4218, default_p18, default_k08, 18.242909).
navstivil(4219, default_p18, default_k08, 18.242909).
navstivil(4220, default_p18, default_k08, 18.242909).
navstivil(4221, default_p18, default_k08, 54.242978).
navstivil(4222, default_p18, default_k08, 54.242978).
navstivil(4223, default_p18, default_k08, 54.242978).
navstivil(4224, default_p18, default_k08, 2.243021).
navstivil(4225, default_p18, default_k08, 2.243021).
navstivil(4226, default_p18, default_k08, 2.243021).
navstivil(4227, default_p18, default_k08, 39.243055).
navstivil(4228, default_p18, default_k08, 39.243055).
navstivil(4229, default_p18, default_k08, 39.243055).
navstivil(4230, default_p18, default_k08, 9.243091).
navstivil(4231, default_p18, default_k08, 9.243091).
navstivil(4232, default_p18, default_k08, 9.243091).
navstivil(4233, default_p18, default_k08, 74.243133).
navstivil(4234, default_p18, default_k08, 74.243133).
navstivil(4235, default_p18, default_k08, 74.243133).
navstivil(4236, default_p18, default_k08, 65.243244).
navstivil(4237, default_p18, default_k08, 65.243244).
navstivil(4238, default_p18, default_k08, 65.243244).
navstivil(4239, default_p18, default_k08, 20.243286).
navstivil(4240, default_p18, default_k08, 20.243286).
navstivil(4241, default_p18, default_k08, 20.243286).
navstivil(4242, default_p18, default_k08, 93.243326).
navstivil(4243, default_p18, default_k08, 93.243326).
navstivil(4244, default_p18, default_k08, 93.243326).
navstivil(4245, default_p18, default_k08, 23.243362).
navstivil(4246, default_p18, default_k08, 23.243362).
navstivil(4247, default_p18, default_k08, 23.243362).
navstivil(4248, default_p18, default_k08, 34.243385).
navstivil(4249, default_p18, default_k08, 34.243385).
navstivil(4250, default_p18, default_k08, 34.243385).
navstivil(4251, default_p18, default_k08, 16.24342).
navstivil(4252, default_p18, default_k08, 16.24342).
navstivil(4253, default_p18, default_k08, 16.24342).
navstivil(4254, default_p18, default_k08, 98.243456).
navstivil(4255, default_p18, default_k08, 98.243456).
navstivil(4256, default_p18, default_k08, 98.243456).
navstivil(4257, default_p18, default_k09, 66.243505).
navstivil(4258, default_p18, default_k09, 66.243505).
navstivil(4259, default_p18, default_k09, 66.243505).
navstivil(4260, default_p18, default_k09, 83.243558).
navstivil(4261, default_p18, default_k09, 83.243558).
navstivil(4262, default_p18, default_k09, 83.243558).
navstivil(4263, default_p18, default_k09, 52.243607).
navstivil(4264, default_p18, default_k09, 52.243607).
navstivil(4265, default_p18, default_k09, 52.243607).
navstivil(4266, default_p18, default_k09, 52.24366).
navstivil(4267, default_p18, default_k09, 52.24366).
navstivil(4268, default_p18, default_k09, 52.24366).
navstivil(4269, default_p18, default_k09, 89.243692).
navstivil(4270, default_p18, default_k09, 89.243692).
navstivil(4271, default_p18, default_k09, 89.243692).
navstivil(4272, default_p18, default_k09, 67.243719).
navstivil(4273, default_p18, default_k09, 67.243719).
navstivil(4274, default_p18, default_k09, 67.243719).
navstivil(4275, default_p18, default_k09, 20.24375).
navstivil(4276, default_p18, default_k09, 20.24375).
navstivil(4277, default_p18, default_k09, 20.24375).
navstivil(4278, default_p18, default_k09, 37.243819).
navstivil(4279, default_p18, default_k09, 37.243819).
navstivil(4280, default_p18, default_k09, 37.243819).
navstivil(4281, default_p18, default_k09, 22.243852).
navstivil(4282, default_p18, default_k09, 22.243852).
navstivil(4283, default_p18, default_k09, 22.243852).
navstivil(4284, default_p18, default_k09, 62.24388).
navstivil(4285, default_p18, default_k09, 62.24388).
navstivil(4286, default_p18, default_k09, 62.24388).
navstivil(4287, default_p18, default_k09, 34.243901).
navstivil(4288, default_p18, default_k09, 34.243901).
navstivil(4289, default_p18, default_k09, 34.243901).
navstivil(4290, default_p18, default_k09, 21.243932).
navstivil(4291, default_p18, default_k09, 21.243932).
navstivil(4292, default_p18, default_k09, 21.243932).
navstivil(4293, default_p18, default_k09, 11.243963).
navstivil(4294, default_p18, default_k09, 11.243963).
navstivil(4295, default_p18, default_k09, 11.243963).
navstivil(4296, default_p18, default_k09, 46.244002).
navstivil(4297, default_p18, default_k09, 46.244002).
navstivil(4298, default_p18, default_k09, 46.244002).
navstivil(4299, default_p18, default_k09, 99.244142).
navstivil(4300, default_p18, default_k09, 99.244142).
navstivil(4301, default_p18, default_k09, 99.244142).
navstivil(4302, default_p18, default_k09, 11.244184).
navstivil(4303, default_p18, default_k09, 11.244184).
navstivil(4304, default_p18, default_k09, 11.244184).
navstivil(4305, default_p18, default_k09, 55.244206).
navstivil(4306, default_p18, default_k09, 55.244206).
navstivil(4307, default_p18, default_k09, 55.244206).
navstivil(4308, default_p18, default_k10, 74.244227).
navstivil(4309, default_p18, default_k10, 74.244227).
navstivil(4310, default_p18, default_k10, 74.244227).
navstivil(4311, default_p18, default_k10, 35.244251).
navstivil(4312, default_p18, default_k10, 35.244251).
navstivil(4313, default_p18, default_k10, 35.244251).
navstivil(4314, default_p18, default_k10, 56.244273).
navstivil(4315, default_p18, default_k10, 56.244273).
navstivil(4316, default_p18, default_k10, 56.244273).
navstivil(4317, default_p18, default_k10, 40.244295).
navstivil(4318, default_p18, default_k10, 40.244295).
navstivil(4319, default_p18, default_k10, 40.244295).
navstivil(4320, default_p18, default_k10, 3.244353).
navstivil(4321, default_p18, default_k10, 3.244353).
navstivil(4322, default_p18, default_k10, 3.244353).
navstivil(4323, default_p18, default_k10, 53.244371).
navstivil(4324, default_p18, default_k10, 53.244371).
navstivil(4325, default_p18, default_k10, 53.244371).
navstivil(4326, default_p18, default_k10, 29.244394).
navstivil(4327, default_p18, default_k10, 29.244394).
navstivil(4328, default_p18, default_k10, 29.244394).
navstivil(4329, default_p18, default_k10, 100.244415).
navstivil(4330, default_p18, default_k10, 100.244415).
navstivil(4331, default_p18, default_k10, 100.244415).
navstivil(4332, default_p18, default_k10, 67.244444).
navstivil(4333, default_p18, default_k10, 67.244444).
navstivil(4334, default_p18, default_k10, 67.244444).
navstivil(4335, default_p18, default_k10, 38.244475).
navstivil(4336, default_p18, default_k10, 38.244475).
navstivil(4337, default_p18, default_k10, 38.244475).
navstivil(4338, default_p18, default_k10, 78.244498).
navstivil(4339, default_p18, default_k10, 78.244498).
navstivil(4340, default_p18, default_k10, 78.244498).
navstivil(4341, default_p18, default_k10, 18.244532).
navstivil(4342, default_p18, default_k10, 18.244532).
navstivil(4343, default_p18, default_k10, 18.244532).
navstivil(4344, default_p18, default_k10, 20.244562).
navstivil(4345, default_p18, default_k10, 20.244562).
navstivil(4346, default_p18, default_k10, 20.244562).
navstivil(4347, default_p18, default_k10, 19.2446).
navstivil(4348, default_p18, default_k10, 19.2446).
navstivil(4349, default_p18, default_k10, 19.2446).
navstivil(4350, default_p18, default_k10, 7.244626).
navstivil(4351, default_p18, default_k10, 7.244626).
navstivil(4352, default_p18, default_k10, 7.244626).
navstivil(4353, default_p18, default_k10, 70.244656).
navstivil(4354, default_p18, default_k10, 70.244656).
navstivil(4355, default_p18, default_k10, 70.244656).
navstivil(4356, default_p18, default_k10, 67.24468).
navstivil(4357, default_p18, default_k10, 67.24468).
navstivil(4358, default_p18, default_k10, 67.24468).
navstivil(4359, default_p19, default_k01, 63.244715).
navstivil(4360, default_p19, default_k01, 63.244715).
navstivil(4361, default_p19, default_k01, 63.244715).
navstivil(4362, default_p19, default_k01, 43.244774).
navstivil(4363, default_p19, default_k01, 43.244774).
navstivil(4364, default_p19, default_k01, 43.244774).
navstivil(4365, default_p19, default_k01, 58.2448).
navstivil(4366, default_p19, default_k01, 58.2448).
navstivil(4367, default_p19, default_k01, 58.2448).
navstivil(4368, default_p19, default_k01, 60.244819).
navstivil(4369, default_p19, default_k01, 60.244819).
navstivil(4370, default_p19, default_k01, 60.244819).
navstivil(4371, default_p19, default_k01, 13.244838).
navstivil(4372, default_p19, default_k01, 13.244838).
navstivil(4373, default_p19, default_k01, 13.244838).
navstivil(4374, default_p19, default_k01, 88.244857).
navstivil(4375, default_p19, default_k01, 88.244857).
navstivil(4376, default_p19, default_k01, 88.244857).
navstivil(4377, default_p19, default_k01, 94.244885).
navstivil(4378, default_p19, default_k01, 94.244885).
navstivil(4379, default_p19, default_k01, 94.244885).
navstivil(4380, default_p19, default_k01, 99.244916).
navstivil(4381, default_p19, default_k01, 99.244916).
navstivil(4382, default_p19, default_k01, 99.244916).
navstivil(4383, default_p19, default_k01, 64.244947).
navstivil(4384, default_p19, default_k01, 64.244947).
navstivil(4385, default_p19, default_k01, 64.244947).
navstivil(4386, default_p19, default_k01, 58.244975).
navstivil(4387, default_p19, default_k01, 58.244975).
navstivil(4388, default_p19, default_k01, 58.244975).
navstivil(4389, default_p19, default_k01, 23.245003).
navstivil(4390, default_p19, default_k01, 23.245003).
navstivil(4391, default_p19, default_k01, 23.245003).
navstivil(4392, default_p19, default_k01, 61.24503).
navstivil(4393, default_p19, default_k01, 61.24503).
navstivil(4394, default_p19, default_k01, 61.24503).
navstivil(4395, default_p19, default_k01, 85.245057).
navstivil(4396, default_p19, default_k01, 85.245057).
navstivil(4397, default_p19, default_k01, 85.245057).
navstivil(4398, default_p19, default_k01, 60.245082).
navstivil(4399, default_p19, default_k01, 60.245082).
navstivil(4400, default_p19, default_k01, 60.245082).
navstivil(4401, default_p19, default_k01, 18.245131).
navstivil(4402, default_p19, default_k01, 18.245131).
navstivil(4403, default_p19, default_k01, 18.245131).
navstivil(4404, default_p19, default_k01, 68.245199).
navstivil(4405, default_p19, default_k01, 68.245199).
navstivil(4406, default_p19, default_k01, 68.245199).
navstivil(4407, default_p19, default_k01, 29.245305).
navstivil(4408, default_p19, default_k01, 29.245305).
navstivil(4409, default_p19, default_k01, 29.245305).
navstivil(4410, default_p19, default_k01, 7.245343).
navstivil(4411, default_p19, default_k01, 7.245343).
navstivil(4412, default_p19, default_k01, 7.245343).
navstivil(4413, default_p19, default_k02, 99.245381).
navstivil(4414, default_p19, default_k02, 99.245381).
navstivil(4415, default_p19, default_k02, 99.245381).
navstivil(4416, default_p19, default_k02, 47.245406).
navstivil(4417, default_p19, default_k02, 47.245406).
navstivil(4418, default_p19, default_k02, 47.245406).
navstivil(4419, default_p19, default_k02, 31.245427).
navstivil(4420, default_p19, default_k02, 31.245427).
navstivil(4421, default_p19, default_k02, 31.245427).
navstivil(4422, default_p19, default_k02, 10.245452).
navstivil(4423, default_p19, default_k02, 10.245452).
navstivil(4424, default_p19, default_k02, 10.245452).
navstivil(4425, default_p19, default_k02, 2.245471).
navstivil(4426, default_p19, default_k02, 2.245471).
navstivil(4427, default_p19, default_k02, 2.245471).
navstivil(4428, default_p19, default_k02, 60.245491).
navstivil(4429, default_p19, default_k02, 60.245491).
navstivil(4430, default_p19, default_k02, 60.245491).
navstivil(4431, default_p19, default_k02, 10.245517).
navstivil(4432, default_p19, default_k02, 10.245517).
navstivil(4433, default_p19, default_k02, 10.245517).
navstivil(4434, default_p19, default_k02, 42.245542).
navstivil(4435, default_p19, default_k02, 42.245542).
navstivil(4436, default_p19, default_k02, 42.245542).
navstivil(4437, default_p19, default_k02, 39.245563).
navstivil(4438, default_p19, default_k02, 39.245563).
navstivil(4439, default_p19, default_k02, 39.245563).
navstivil(4440, default_p19, default_k02, 48.245581).
navstivil(4441, default_p19, default_k02, 48.245581).
navstivil(4442, default_p19, default_k02, 48.245581).
navstivil(4443, default_p19, default_k02, 4.245606).
navstivil(4444, default_p19, default_k02, 4.245606).
navstivil(4445, default_p19, default_k02, 4.245606).
navstivil(4446, default_p19, default_k02, 64.245664).
navstivil(4447, default_p19, default_k02, 64.245664).
navstivil(4448, default_p19, default_k02, 64.245664).
navstivil(4449, default_p19, default_k02, 4.245688).
navstivil(4450, default_p19, default_k02, 4.245688).
navstivil(4451, default_p19, default_k02, 4.245688).
navstivil(4452, default_p19, default_k02, 15.245716).
navstivil(4453, default_p19, default_k02, 15.245716).
navstivil(4454, default_p19, default_k02, 15.245716).
navstivil(4455, default_p19, default_k02, 62.245738).
navstivil(4456, default_p19, default_k02, 62.245738).
navstivil(4457, default_p19, default_k02, 62.245738).
navstivil(4458, default_p19, default_k02, 85.245763).
navstivil(4459, default_p19, default_k02, 85.245763).
navstivil(4460, default_p19, default_k02, 85.245763).
navstivil(4461, default_p19, default_k02, 73.245785).
navstivil(4462, default_p19, default_k02, 73.245785).
navstivil(4463, default_p19, default_k02, 73.245785).
navstivil(4464, default_p19, default_k02, 53.2458).
navstivil(4465, default_p19, default_k02, 53.2458).
navstivil(4466, default_p19, default_k02, 53.2458).
navstivil(4467, default_p19, default_k03, 43.245821).
navstivil(4468, default_p19, default_k03, 43.245821).
navstivil(4469, default_p19, default_k03, 43.245821).
navstivil(4470, default_p19, default_k03, 81.245856).
navstivil(4471, default_p19, default_k03, 81.245856).
navstivil(4472, default_p19, default_k03, 81.245856).
navstivil(4473, default_p19, default_k03, 78.245888).
navstivil(4474, default_p19, default_k03, 78.245888).
navstivil(4475, default_p19, default_k03, 78.245888).
navstivil(4476, default_p19, default_k03, 59.245919).
navstivil(4477, default_p19, default_k03, 59.245919).
navstivil(4478, default_p19, default_k03, 59.245919).
navstivil(4479, default_p19, default_k03, 64.245947).
navstivil(4480, default_p19, default_k03, 64.245947).
navstivil(4481, default_p19, default_k03, 64.245947).
navstivil(4482, default_p19, default_k03, 47.245977).
navstivil(4483, default_p19, default_k03, 47.245977).
navstivil(4484, default_p19, default_k03, 47.245977).
navstivil(4485, default_p19, default_k03, 71.246007).
navstivil(4486, default_p19, default_k03, 71.246007).
navstivil(4487, default_p19, default_k03, 71.246007).
navstivil(4488, default_p19, default_k03, 57.246064).
navstivil(4489, default_p19, default_k03, 57.246064).
navstivil(4490, default_p19, default_k03, 57.246064).
navstivil(4491, default_p19, default_k03, 80.246099).
navstivil(4492, default_p19, default_k03, 80.246099).
navstivil(4493, default_p19, default_k03, 80.246099).
navstivil(4494, default_p19, default_k03, 44.246127).
navstivil(4495, default_p19, default_k03, 44.246127).
navstivil(4496, default_p19, default_k03, 44.246127).
navstivil(4497, default_p19, default_k03, 3.246157).
navstivil(4498, default_p19, default_k03, 3.246157).
navstivil(4499, default_p19, default_k03, 3.246157).
navstivil(4500, default_p19, default_k03, 3.246184).
navstivil(4501, default_p19, default_k03, 3.246184).
navstivil(4502, default_p19, default_k03, 3.246184).
navstivil(4503, default_p19, default_k03, 81.246218).
navstivil(4504, default_p19, default_k03, 81.246218).
navstivil(4505, default_p19, default_k03, 81.246218).
navstivil(4506, default_p19, default_k03, 32.246235).
navstivil(4507, default_p19, default_k03, 32.246235).
navstivil(4508, default_p19, default_k03, 32.246235).
navstivil(4509, default_p19, default_k03, 63.246251).
navstivil(4510, default_p19, default_k03, 63.246251).
navstivil(4511, default_p19, default_k03, 63.246251).
navstivil(4512, default_p19, default_k03, 71.24627).
navstivil(4513, default_p19, default_k03, 71.24627).
navstivil(4514, default_p19, default_k03, 71.24627).
navstivil(4515, default_p19, default_k03, 71.246298).
navstivil(4516, default_p19, default_k03, 71.246298).
navstivil(4517, default_p19, default_k03, 71.246298).
navstivil(4518, default_p19, default_k03, 20.246329).
navstivil(4519, default_p19, default_k03, 20.246329).
navstivil(4520, default_p19, default_k03, 20.246329).
navstivil(4521, default_p19, default_k04, 50.246362).
navstivil(4522, default_p19, default_k04, 50.246362).
navstivil(4523, default_p19, default_k04, 50.246362).
navstivil(4524, default_p19, default_k04, 39.246394).
navstivil(4525, default_p19, default_k04, 39.246394).
navstivil(4526, default_p19, default_k04, 39.246394).
navstivil(4527, default_p19, default_k04, 8.24642).
navstivil(4528, default_p19, default_k04, 8.24642).
navstivil(4529, default_p19, default_k04, 8.24642).
navstivil(4530, default_p19, default_k04, 13.246472).
navstivil(4531, default_p19, default_k04, 13.246472).
navstivil(4532, default_p19, default_k04, 13.246472).
navstivil(4533, default_p19, default_k04, 74.246498).
navstivil(4534, default_p19, default_k04, 74.246498).
navstivil(4535, default_p19, default_k04, 74.246498).
navstivil(4536, default_p19, default_k04, 16.24653).
navstivil(4537, default_p19, default_k04, 16.24653).
navstivil(4538, default_p19, default_k04, 16.24653).
navstivil(4539, default_p19, default_k04, 25.246551).
navstivil(4540, default_p19, default_k04, 25.246551).
navstivil(4541, default_p19, default_k04, 25.246551).
navstivil(4542, default_p19, default_k04, 18.246573).
navstivil(4543, default_p19, default_k04, 18.246573).
navstivil(4544, default_p19, default_k04, 18.246573).
navstivil(4545, default_p19, default_k04, 21.246591).
navstivil(4546, default_p19, default_k04, 21.246591).
navstivil(4547, default_p19, default_k04, 21.246591).
navstivil(4548, default_p19, default_k04, 33.246611).
navstivil(4549, default_p19, default_k04, 33.246611).
navstivil(4550, default_p19, default_k04, 33.246611).
navstivil(4551, default_p19, default_k04, 91.246633).
navstivil(4552, default_p19, default_k04, 91.246633).
navstivil(4553, default_p19, default_k04, 91.246633).
navstivil(4554, default_p19, default_k04, 6.246653).
navstivil(4555, default_p19, default_k04, 6.246653).
navstivil(4556, default_p19, default_k04, 6.246653).
navstivil(4557, default_p19, default_k04, 6.24667).
navstivil(4558, default_p19, default_k04, 6.24667).
navstivil(4559, default_p19, default_k04, 6.24667).
navstivil(4560, default_p19, default_k04, 14.246693).
navstivil(4561, default_p19, default_k04, 14.246693).
navstivil(4562, default_p19, default_k04, 14.246693).
navstivil(4563, default_p19, default_k04, 95.246714).
navstivil(4564, default_p19, default_k04, 95.246714).
navstivil(4565, default_p19, default_k04, 95.246714).
navstivil(4566, default_p19, default_k04, 95.246729).
navstivil(4567, default_p19, default_k04, 95.246729).
navstivil(4568, default_p19, default_k04, 95.246729).
navstivil(4569, default_p19, default_k04, 89.246752).
navstivil(4570, default_p19, default_k04, 89.246752).
navstivil(4571, default_p19, default_k04, 89.246752).
navstivil(4572, default_p19, default_k04, 47.246804).
navstivil(4573, default_p19, default_k04, 47.246804).
navstivil(4574, default_p19, default_k04, 47.246804).
navstivil(4575, default_p19, default_k05, 65.246836).
navstivil(4576, default_p19, default_k05, 65.246836).
navstivil(4577, default_p19, default_k05, 65.246836).
navstivil(4578, default_p19, default_k05, 67.246863).
navstivil(4579, default_p19, default_k05, 67.246863).
navstivil(4580, default_p19, default_k05, 67.246863).
navstivil(4581, default_p19, default_k05, 10.24688).
navstivil(4582, default_p19, default_k05, 10.24688).
navstivil(4583, default_p19, default_k05, 10.24688).
navstivil(4584, default_p19, default_k05, 13.2469).
navstivil(4585, default_p19, default_k05, 13.2469).
navstivil(4586, default_p19, default_k05, 13.2469).
navstivil(4587, default_p19, default_k05, 26.246922).
navstivil(4588, default_p19, default_k05, 26.246922).
navstivil(4589, default_p19, default_k05, 26.246922).
navstivil(4590, default_p19, default_k05, 39.246985).
navstivil(4591, default_p19, default_k05, 39.246985).
navstivil(4592, default_p19, default_k05, 39.246985).
navstivil(4593, default_p19, default_k05, 26.24703).
navstivil(4594, default_p19, default_k05, 26.24703).
navstivil(4595, default_p19, default_k05, 26.24703).
navstivil(4596, default_p19, default_k05, 13.247057).
navstivil(4597, default_p19, default_k05, 13.247057).
navstivil(4598, default_p19, default_k05, 13.247057).
navstivil(4599, default_p19, default_k05, 94.247089).
navstivil(4600, default_p19, default_k05, 94.247089).
navstivil(4601, default_p19, default_k05, 94.247089).
navstivil(4602, default_p19, default_k05, 15.247107).
navstivil(4603, default_p19, default_k05, 15.247107).
navstivil(4604, default_p19, default_k05, 15.247107).
navstivil(4605, default_p19, default_k05, 19.247124).
navstivil(4606, default_p19, default_k05, 19.247124).
navstivil(4607, default_p19, default_k05, 19.247124).
navstivil(4608, default_p19, default_k05, 26.247143).
navstivil(4609, default_p19, default_k05, 26.247143).
navstivil(4610, default_p19, default_k05, 26.247143).
navstivil(4611, default_p19, default_k05, 76.247159).
navstivil(4612, default_p19, default_k05, 76.247159).
navstivil(4613, default_p19, default_k05, 76.247159).
navstivil(4614, default_p19, default_k05, 44.247195).
navstivil(4615, default_p19, default_k05, 44.247195).
navstivil(4616, default_p19, default_k05, 44.247195).
navstivil(4617, default_p19, default_k05, 32.247229).
navstivil(4618, default_p19, default_k05, 32.247229).
navstivil(4619, default_p19, default_k05, 32.247229).
navstivil(4620, default_p19, default_k05, 96.247261).
navstivil(4621, default_p19, default_k05, 96.247261).
navstivil(4622, default_p19, default_k05, 96.247261).
navstivil(4623, default_p19, default_k05, 53.247288).
navstivil(4624, default_p19, default_k05, 53.247288).
navstivil(4625, default_p19, default_k05, 53.247288).
navstivil(4626, default_p19, default_k05, 23.247317).
navstivil(4627, default_p19, default_k05, 23.247317).
navstivil(4628, default_p19, default_k05, 23.247317).
navstivil(4629, default_p19, default_k06, 40.247347).
navstivil(4630, default_p19, default_k06, 40.247347).
navstivil(4631, default_p19, default_k06, 40.247347).
navstivil(4632, default_p19, default_k06, 59.247371).
navstivil(4633, default_p19, default_k06, 59.247371).
navstivil(4634, default_p19, default_k06, 59.247371).
navstivil(4635, default_p19, default_k06, 23.247392).
navstivil(4636, default_p19, default_k06, 23.247392).
navstivil(4637, default_p19, default_k06, 23.247392).
navstivil(4638, default_p19, default_k06, 54.247414).
navstivil(4639, default_p19, default_k06, 54.247414).
navstivil(4640, default_p19, default_k06, 54.247414).
navstivil(4641, default_p19, default_k06, 53.247436).
navstivil(4642, default_p19, default_k06, 53.247436).
navstivil(4643, default_p19, default_k06, 53.247436).
navstivil(4644, default_p19, default_k06, 59.247453).
navstivil(4645, default_p19, default_k06, 59.247453).
navstivil(4646, default_p19, default_k06, 59.247453).
navstivil(4647, default_p19, default_k06, 52.247476).
navstivil(4648, default_p19, default_k06, 52.247476).
navstivil(4649, default_p19, default_k06, 52.247476).
navstivil(4650, default_p19, default_k06, 17.247496).
navstivil(4651, default_p19, default_k06, 17.247496).
navstivil(4652, default_p19, default_k06, 17.247496).
navstivil(4653, default_p19, default_k06, 93.247519).
navstivil(4654, default_p19, default_k06, 93.247519).
navstivil(4655, default_p19, default_k06, 93.247519).
navstivil(4656, default_p19, default_k06, 84.247551).
navstivil(4657, default_p19, default_k06, 84.247551).
navstivil(4658, default_p19, default_k06, 84.247551).
navstivil(4659, default_p19, default_k06, 82.24757).
navstivil(4660, default_p19, default_k06, 82.24757).
navstivil(4661, default_p19, default_k06, 82.24757).
navstivil(4662, default_p19, default_k06, 97.247632).
navstivil(4663, default_p19, default_k06, 97.247632).
navstivil(4664, default_p19, default_k06, 97.247632).
navstivil(4665, default_p19, default_k06, 45.247647).
navstivil(4666, default_p19, default_k06, 45.247647).
navstivil(4667, default_p19, default_k06, 45.247647).
navstivil(4668, default_p19, default_k06, 68.24766).
navstivil(4669, default_p19, default_k06, 68.24766).
navstivil(4670, default_p19, default_k06, 68.24766).
navstivil(4671, default_p19, default_k06, 89.247673).
navstivil(4672, default_p19, default_k06, 89.247673).
navstivil(4673, default_p19, default_k06, 89.247673).
navstivil(4674, default_p19, default_k06, 47.247689).
navstivil(4675, default_p19, default_k06, 47.247689).
navstivil(4676, default_p19, default_k06, 47.247689).
navstivil(4677, default_p19, default_k06, 18.247709).
navstivil(4678, default_p19, default_k06, 18.247709).
navstivil(4679, default_p19, default_k06, 18.247709).
navstivil(4680, default_p19, default_k06, 97.247727).
navstivil(4681, default_p19, default_k06, 97.247727).
navstivil(4682, default_p19, default_k06, 97.247727).
navstivil(4683, default_p19, default_k07, 15.247747).
navstivil(4684, default_p19, default_k07, 15.247747).
navstivil(4685, default_p19, default_k07, 15.247747).
navstivil(4686, default_p19, default_k07, 8.247762).
navstivil(4687, default_p19, default_k07, 8.247762).
navstivil(4688, default_p19, default_k07, 8.247762).
navstivil(4689, default_p19, default_k07, 43.247778).
navstivil(4690, default_p19, default_k07, 43.247778).
navstivil(4691, default_p19, default_k07, 43.247778).
navstivil(4692, default_p19, default_k07, 87.247795).
navstivil(4693, default_p19, default_k07, 87.247795).
navstivil(4694, default_p19, default_k07, 87.247795).
navstivil(4695, default_p19, default_k07, 52.247815).
navstivil(4696, default_p19, default_k07, 52.247815).
navstivil(4697, default_p19, default_k07, 52.247815).
navstivil(4698, default_p19, default_k07, 93.247845).
navstivil(4699, default_p19, default_k07, 93.247845).
navstivil(4700, default_p19, default_k07, 93.247845).
navstivil(4701, default_p19, default_k07, 46.247864).
navstivil(4702, default_p19, default_k07, 46.247864).
navstivil(4703, default_p19, default_k07, 46.247864).
navstivil(4704, default_p19, default_k07, 82.247878).
navstivil(4705, default_p19, default_k07, 82.247878).
navstivil(4706, default_p19, default_k07, 82.247878).
navstivil(4707, default_p19, default_k07, 15.247894).
navstivil(4708, default_p19, default_k07, 15.247894).
navstivil(4709, default_p19, default_k07, 15.247894).
navstivil(4710, default_p19, default_k07, 50.247909).
navstivil(4711, default_p19, default_k07, 50.247909).
navstivil(4712, default_p19, default_k07, 50.247909).
navstivil(4713, default_p19, default_k07, 48.247926).
navstivil(4714, default_p19, default_k07, 48.247926).
navstivil(4715, default_p19, default_k07, 48.247926).
navstivil(4716, default_p19, default_k07, 7.247939).
navstivil(4717, default_p19, default_k07, 7.247939).
navstivil(4718, default_p19, default_k07, 7.247939).
navstivil(4719, default_p19, default_k07, 74.247958).
navstivil(4720, default_p19, default_k07, 74.247958).
navstivil(4721, default_p19, default_k07, 74.247958).
navstivil(4722, default_p19, default_k07, 3.248002).
navstivil(4723, default_p19, default_k07, 3.248002).
navstivil(4724, default_p19, default_k07, 3.248002).
navstivil(4725, default_p19, default_k07, 37.248124).
navstivil(4726, default_p19, default_k07, 37.248124).
navstivil(4727, default_p19, default_k07, 37.248124).
navstivil(4728, default_p19, default_k07, 10.248187).
navstivil(4729, default_p19, default_k07, 10.248187).
navstivil(4730, default_p19, default_k07, 10.248187).
navstivil(4731, default_p19, default_k07, 35.248225).
navstivil(4732, default_p19, default_k07, 35.248225).
navstivil(4733, default_p19, default_k07, 35.248225).
navstivil(4734, default_p19, default_k07, 71.248267).
navstivil(4735, default_p19, default_k07, 71.248267).
navstivil(4736, default_p19, default_k07, 71.248267).
navstivil(4737, default_p19, default_k08, 29.248302).
navstivil(4738, default_p19, default_k08, 29.248302).
navstivil(4739, default_p19, default_k08, 29.248302).
navstivil(4740, default_p19, default_k08, 94.248352).
navstivil(4741, default_p19, default_k08, 94.248352).
navstivil(4742, default_p19, default_k08, 94.248352).
navstivil(4743, default_p19, default_k08, 63.248393).
navstivil(4744, default_p19, default_k08, 63.248393).
navstivil(4745, default_p19, default_k08, 63.248393).
navstivil(4746, default_p19, default_k08, 58.248432).
navstivil(4747, default_p19, default_k08, 58.248432).
navstivil(4748, default_p19, default_k08, 58.248432).
navstivil(4749, default_p19, default_k08, 47.24848).
navstivil(4750, default_p19, default_k08, 47.24848).
navstivil(4751, default_p19, default_k08, 47.24848).
navstivil(4752, default_p19, default_k08, 8.248518).
navstivil(4753, default_p19, default_k08, 8.248518).
navstivil(4754, default_p19, default_k08, 8.248518).
navstivil(4755, default_p19, default_k08, 93.248557).
navstivil(4756, default_p19, default_k08, 93.248557).
navstivil(4757, default_p19, default_k08, 93.248557).
navstivil(4758, default_p19, default_k08, 94.2486).
navstivil(4759, default_p19, default_k08, 94.2486).
navstivil(4760, default_p19, default_k08, 94.2486).
navstivil(4761, default_p19, default_k08, 80.248637).
navstivil(4762, default_p19, default_k08, 80.248637).
navstivil(4763, default_p19, default_k08, 80.248637).
navstivil(4764, default_p19, default_k08, 28.24868).
navstivil(4765, default_p19, default_k08, 28.24868).
navstivil(4766, default_p19, default_k08, 28.24868).
navstivil(4767, default_p19, default_k08, 93.248737).
navstivil(4768, default_p19, default_k08, 93.248737).
navstivil(4769, default_p19, default_k08, 93.248737).
navstivil(4770, default_p19, default_k08, 20.248779).
navstivil(4771, default_p19, default_k08, 20.248779).
navstivil(4772, default_p19, default_k08, 20.248779).
navstivil(4773, default_p19, default_k08, 81.248877).
navstivil(4774, default_p19, default_k08, 81.248877).
navstivil(4775, default_p19, default_k08, 81.248877).
navstivil(4776, default_p19, default_k08, 19.24891).
navstivil(4777, default_p19, default_k08, 19.24891).
navstivil(4778, default_p19, default_k08, 19.24891).
navstivil(4779, default_p19, default_k08, 17.248943).
navstivil(4780, default_p19, default_k08, 17.248943).
navstivil(4781, default_p19, default_k08, 17.248943).
navstivil(4782, default_p19, default_k08, 21.248995).
navstivil(4783, default_p19, default_k08, 21.248995).
navstivil(4784, default_p19, default_k08, 21.248995).
navstivil(4785, default_p19, default_k08, 33.249027).
navstivil(4786, default_p19, default_k08, 33.249027).
navstivil(4787, default_p19, default_k08, 33.249027).
navstivil(4788, default_p19, default_k08, 1.249063).
navstivil(4789, default_p19, default_k08, 1.249063).
navstivil(4790, default_p19, default_k08, 1.249063).
navstivil(4791, default_p19, default_k09, 45.249102).
navstivil(4792, default_p19, default_k09, 45.249102).
navstivil(4793, default_p19, default_k09, 45.249102).
navstivil(4794, default_p19, default_k09, 84.249145).
navstivil(4795, default_p19, default_k09, 84.249145).
navstivil(4796, default_p19, default_k09, 84.249145).
navstivil(4797, default_p19, default_k09, 66.249182).
navstivil(4798, default_p19, default_k09, 66.249182).
navstivil(4799, default_p19, default_k09, 66.249182).
navstivil(4800, default_p19, default_k09, 43.249219).
navstivil(4801, default_p19, default_k09, 43.249219).
navstivil(4802, default_p19, default_k09, 43.249219).
navstivil(4803, default_p19, default_k09, 2.249252).
navstivil(4804, default_p19, default_k09, 2.249252).
navstivil(4805, default_p19, default_k09, 2.249252).
navstivil(4806, default_p19, default_k09, 55.249287).
navstivil(4807, default_p19, default_k09, 55.249287).
navstivil(4808, default_p19, default_k09, 55.249287).
navstivil(4809, default_p19, default_k09, 14.24932).
navstivil(4810, default_p19, default_k09, 14.24932).
navstivil(4811, default_p19, default_k09, 14.24932).
navstivil(4812, default_p19, default_k09, 81.249358).
navstivil(4813, default_p19, default_k09, 81.249358).
navstivil(4814, default_p19, default_k09, 81.249358).
navstivil(4815, default_p19, default_k09, 38.249405).
navstivil(4816, default_p19, default_k09, 38.249405).
navstivil(4817, default_p19, default_k09, 38.249405).
navstivil(4818, default_p19, default_k09, 16.249467).
navstivil(4819, default_p19, default_k09, 16.249467).
navstivil(4820, default_p19, default_k09, 16.249467).
navstivil(4821, default_p19, default_k09, 46.249535).
navstivil(4822, default_p19, default_k09, 46.249535).
navstivil(4823, default_p19, default_k09, 46.249535).
navstivil(4824, default_p19, default_k09, 93.249644).
navstivil(4825, default_p19, default_k09, 93.249644).
navstivil(4826, default_p19, default_k09, 93.249644).
navstivil(4827, default_p19, default_k09, 74.249689).
navstivil(4828, default_p19, default_k09, 74.249689).
navstivil(4829, default_p19, default_k09, 74.249689).
navstivil(4830, default_p19, default_k09, 36.249731).
navstivil(4831, default_p19, default_k09, 36.249731).
navstivil(4832, default_p19, default_k09, 36.249731).
navstivil(4833, default_p19, default_k09, 84.249773).
navstivil(4834, default_p19, default_k09, 84.249773).
navstivil(4835, default_p19, default_k09, 84.249773).
navstivil(4836, default_p19, default_k09, 20.249834).
navstivil(4837, default_p19, default_k09, 20.249834).
navstivil(4838, default_p19, default_k09, 20.249834).
navstivil(4839, default_p19, default_k09, 59.249911).
navstivil(4840, default_p19, default_k09, 59.249911).
navstivil(4841, default_p19, default_k09, 59.249911).
navstivil(4842, default_p19, default_k09, 78.249957).
navstivil(4843, default_p19, default_k09, 78.249957).
navstivil(4844, default_p19, default_k09, 78.249957).
navstivil(4845, default_p19, default_k10, 59.250003).
navstivil(4846, default_p19, default_k10, 59.250003).
navstivil(4847, default_p19, default_k10, 59.250003).
navstivil(4848, default_p19, default_k10, 1.250052).
navstivil(4849, default_p19, default_k10, 1.250052).
navstivil(4850, default_p19, default_k10, 1.250052).
navstivil(4851, default_p19, default_k10, 15.250097).
navstivil(4852, default_p19, default_k10, 15.250097).
navstivil(4853, default_p19, default_k10, 15.250097).
navstivil(4854, default_p19, default_k10, 77.250139).
navstivil(4855, default_p19, default_k10, 77.250139).
navstivil(4856, default_p19, default_k10, 77.250139).
navstivil(4857, default_p19, default_k10, 11.250193).
navstivil(4858, default_p19, default_k10, 11.250193).
navstivil(4859, default_p19, default_k10, 11.250193).
navstivil(4860, default_p19, default_k10, 52.250228).
navstivil(4861, default_p19, default_k10, 52.250228).
navstivil(4862, default_p19, default_k10, 52.250228).
navstivil(4863, default_p19, default_k10, 59.250274).
navstivil(4864, default_p19, default_k10, 59.250274).
navstivil(4865, default_p19, default_k10, 59.250274).
navstivil(4866, default_p19, default_k10, 58.250395).
navstivil(4867, default_p19, default_k10, 58.250395).
navstivil(4868, default_p19, default_k10, 58.250395).
navstivil(4869, default_p19, default_k10, 13.250444).
navstivil(4870, default_p19, default_k10, 13.250444).
navstivil(4871, default_p19, default_k10, 13.250444).
navstivil(4872, default_p19, default_k10, 44.250479).
navstivil(4873, default_p19, default_k10, 44.250479).
navstivil(4874, default_p19, default_k10, 44.250479).
navstivil(4875, default_p19, default_k10, 62.250507).
navstivil(4876, default_p19, default_k10, 62.250507).
navstivil(4877, default_p19, default_k10, 62.250507).
navstivil(4878, default_p19, default_k10, 13.250547).
navstivil(4879, default_p19, default_k10, 13.250547).
navstivil(4880, default_p19, default_k10, 13.250547).
navstivil(4881, default_p19, default_k10, 80.250585).
navstivil(4882, default_p19, default_k10, 80.250585).
navstivil(4883, default_p19, default_k10, 80.250585).
navstivil(4884, default_p19, default_k10, 3.25061).
navstivil(4885, default_p19, default_k10, 3.25061).
navstivil(4886, default_p19, default_k10, 3.25061).
navstivil(4887, default_p19, default_k10, 8.250639).
navstivil(4888, default_p19, default_k10, 8.250639).
navstivil(4889, default_p19, default_k10, 8.250639).
navstivil(4890, default_p19, default_k10, 19.250674).
navstivil(4891, default_p19, default_k10, 19.250674).
navstivil(4892, default_p19, default_k10, 19.250674).
navstivil(4893, default_p19, default_k10, 73.250697).
navstivil(4894, default_p19, default_k10, 73.250697).
navstivil(4895, default_p19, default_k10, 73.250697).
navstivil(4896, default_p19, default_k10, 17.250722).
navstivil(4897, default_p19, default_k10, 17.250722).
navstivil(4898, default_p19, default_k10, 17.250722).
navstivil(4899, default_p20, default_k01, 37.250753).
navstivil(4900, default_p20, default_k01, 37.250753).
navstivil(4901, default_p20, default_k01, 37.250753).
navstivil(4902, default_p20, default_k01, 34.250773).
navstivil(4903, default_p20, default_k01, 34.250773).
navstivil(4904, default_p20, default_k01, 34.250773).
navstivil(4905, default_p20, default_k01, 63.250792).
navstivil(4906, default_p20, default_k01, 63.250792).
navstivil(4907, default_p20, default_k01, 63.250792).
navstivil(4908, default_p20, default_k01, 7.250813).
navstivil(4909, default_p20, default_k01, 7.250813).
navstivil(4910, default_p20, default_k01, 7.250813).
navstivil(4911, default_p20, default_k01, 61.250823).
navstivil(4912, default_p20, default_k01, 61.250823).
navstivil(4913, default_p20, default_k01, 61.250823).
navstivil(4914, default_p20, default_k01, 31.250833).
navstivil(4915, default_p20, default_k01, 31.250833).
navstivil(4916, default_p20, default_k01, 31.250833).
navstivil(4917, default_p20, default_k01, 53.250844).
navstivil(4918, default_p20, default_k01, 53.250844).
navstivil(4919, default_p20, default_k01, 53.250844).
navstivil(4920, default_p20, default_k01, 93.250855).
navstivil(4921, default_p20, default_k01, 93.250855).
navstivil(4922, default_p20, default_k01, 93.250855).
navstivil(4923, default_p20, default_k01, 70.250865).
navstivil(4924, default_p20, default_k01, 70.250865).
navstivil(4925, default_p20, default_k01, 70.250865).
navstivil(4926, default_p20, default_k01, 77.250875).
navstivil(4927, default_p20, default_k01, 77.250875).
navstivil(4928, default_p20, default_k01, 77.250875).
navstivil(4929, default_p20, default_k01, 2.250886).
navstivil(4930, default_p20, default_k01, 2.250886).
navstivil(4931, default_p20, default_k01, 2.250886).
navstivil(4932, default_p20, default_k01, 31.250897).
navstivil(4933, default_p20, default_k01, 31.250897).
navstivil(4934, default_p20, default_k01, 31.250897).
navstivil(4935, default_p20, default_k01, 24.250911).
navstivil(4936, default_p20, default_k01, 24.250911).
navstivil(4937, default_p20, default_k01, 24.250911).
navstivil(4938, default_p20, default_k01, 17.250921).
navstivil(4939, default_p20, default_k01, 17.250921).
navstivil(4940, default_p20, default_k01, 17.250921).
navstivil(4941, default_p20, default_k01, 6.250931).
navstivil(4942, default_p20, default_k01, 6.250931).
navstivil(4943, default_p20, default_k01, 6.250931).
navstivil(4944, default_p20, default_k01, 25.250942).
navstivil(4945, default_p20, default_k01, 25.250942).
navstivil(4946, default_p20, default_k01, 25.250942).
navstivil(4947, default_p20, default_k01, 34.250956).
navstivil(4948, default_p20, default_k01, 34.250956).
navstivil(4949, default_p20, default_k01, 34.250956).
navstivil(4950, default_p20, default_k01, 41.250973).
navstivil(4951, default_p20, default_k01, 41.250973).
navstivil(4952, default_p20, default_k01, 41.250973).
navstivil(4953, default_p20, default_k01, 44.250984).
navstivil(4954, default_p20, default_k01, 44.250984).
navstivil(4955, default_p20, default_k01, 44.250984).
navstivil(4956, default_p20, default_k02, 47.250996).
navstivil(4957, default_p20, default_k02, 47.250996).
navstivil(4958, default_p20, default_k02, 47.250996).
navstivil(4959, default_p20, default_k02, 30.251012).
navstivil(4960, default_p20, default_k02, 30.251012).
navstivil(4961, default_p20, default_k02, 30.251012).
navstivil(4962, default_p20, default_k02, 16.251029).
navstivil(4963, default_p20, default_k02, 16.251029).
navstivil(4964, default_p20, default_k02, 16.251029).
navstivil(4965, default_p20, default_k02, 60.251044).
navstivil(4966, default_p20, default_k02, 60.251044).
navstivil(4967, default_p20, default_k02, 60.251044).
navstivil(4968, default_p20, default_k02, 12.251056).
navstivil(4969, default_p20, default_k02, 12.251056).
navstivil(4970, default_p20, default_k02, 12.251056).
navstivil(4971, default_p20, default_k02, 67.251067).
navstivil(4972, default_p20, default_k02, 67.251067).
navstivil(4973, default_p20, default_k02, 67.251067).
navstivil(4974, default_p20, default_k02, 99.251089).
navstivil(4975, default_p20, default_k02, 99.251089).
navstivil(4976, default_p20, default_k02, 99.251089).
navstivil(4977, default_p20, default_k02, 22.251103).
navstivil(4978, default_p20, default_k02, 22.251103).
navstivil(4979, default_p20, default_k02, 22.251103).
navstivil(4980, default_p20, default_k02, 20.251122).
navstivil(4981, default_p20, default_k02, 20.251122).
navstivil(4982, default_p20, default_k02, 20.251122).
navstivil(4983, default_p20, default_k02, 93.251137).
navstivil(4984, default_p20, default_k02, 93.251137).
navstivil(4985, default_p20, default_k02, 93.251137).
navstivil(4986, default_p20, default_k02, 91.251149).
navstivil(4987, default_p20, default_k02, 91.251149).
navstivil(4988, default_p20, default_k02, 91.251149).
navstivil(4989, default_p20, default_k02, 47.251163).
navstivil(4990, default_p20, default_k02, 47.251163).
navstivil(4991, default_p20, default_k02, 47.251163).
navstivil(4992, default_p20, default_k02, 11.251179).
navstivil(4993, default_p20, default_k02, 11.251179).
navstivil(4994, default_p20, default_k02, 11.251179).
navstivil(4995, default_p20, default_k02, 87.251192).
navstivil(4996, default_p20, default_k02, 87.251192).
navstivil(4997, default_p20, default_k02, 87.251192).
navstivil(4998, default_p20, default_k02, 54.251203).
navstivil(4999, default_p20, default_k02, 54.251203).
navstivil(5000, default_p20, default_k02, 54.251203).
navstivil(5001, default_p20, default_k02, 93.251217).
navstivil(5002, default_p20, default_k02, 93.251217).
navstivil(5003, default_p20, default_k02, 93.251217).
navstivil(5004, default_p20, default_k02, 95.251233).
navstivil(5005, default_p20, default_k02, 95.251233).
navstivil(5006, default_p20, default_k02, 95.251233).
navstivil(5007, default_p20, default_k02, 63.251245).
navstivil(5008, default_p20, default_k02, 63.251245).
navstivil(5009, default_p20, default_k02, 63.251245).
navstivil(5010, default_p20, default_k02, 92.251256).
navstivil(5011, default_p20, default_k02, 92.251256).
navstivil(5012, default_p20, default_k02, 92.251256).
navstivil(5013, default_p20, default_k03, 15.251266).
navstivil(5014, default_p20, default_k03, 15.251266).
navstivil(5015, default_p20, default_k03, 15.251266).
navstivil(5016, default_p20, default_k03, 78.251276).
navstivil(5017, default_p20, default_k03, 78.251276).
navstivil(5018, default_p20, default_k03, 78.251276).
navstivil(5019, default_p20, default_k03, 13.251291).
navstivil(5020, default_p20, default_k03, 13.251291).
navstivil(5021, default_p20, default_k03, 13.251291).
navstivil(5022, default_p20, default_k03, 1.251312).
navstivil(5023, default_p20, default_k03, 1.251312).
navstivil(5024, default_p20, default_k03, 1.251312).
navstivil(5025, default_p20, default_k03, 70.251332).
navstivil(5026, default_p20, default_k03, 70.251332).
navstivil(5027, default_p20, default_k03, 70.251332).
navstivil(5028, default_p20, default_k03, 23.251349).
navstivil(5029, default_p20, default_k03, 23.251349).
navstivil(5030, default_p20, default_k03, 23.251349).
navstivil(5031, default_p20, default_k03, 25.251368).
navstivil(5032, default_p20, default_k03, 25.251368).
navstivil(5033, default_p20, default_k03, 25.251368).
navstivil(5034, default_p20, default_k03, 53.25139).
navstivil(5035, default_p20, default_k03, 53.25139).
navstivil(5036, default_p20, default_k03, 53.25139).
navstivil(5037, default_p20, default_k03, 9.2514).
navstivil(5038, default_p20, default_k03, 9.2514).
navstivil(5039, default_p20, default_k03, 9.2514).
navstivil(5040, default_p20, default_k03, 33.251411).
navstivil(5041, default_p20, default_k03, 33.251411).
navstivil(5042, default_p20, default_k03, 33.251411).
navstivil(5043, default_p20, default_k03, 8.251421).
navstivil(5044, default_p20, default_k03, 8.251421).
navstivil(5045, default_p20, default_k03, 8.251421).
navstivil(5046, default_p20, default_k03, 34.25143).
navstivil(5047, default_p20, default_k03, 34.25143).
navstivil(5048, default_p20, default_k03, 34.25143).
navstivil(5049, default_p20, default_k03, 60.25144).
navstivil(5050, default_p20, default_k03, 60.25144).
navstivil(5051, default_p20, default_k03, 60.25144).
navstivil(5052, default_p20, default_k03, 35.251449).
navstivil(5053, default_p20, default_k03, 35.251449).
navstivil(5054, default_p20, default_k03, 35.251449).
navstivil(5055, default_p20, default_k03, 28.251459).
navstivil(5056, default_p20, default_k03, 28.251459).
navstivil(5057, default_p20, default_k03, 28.251459).
navstivil(5058, default_p20, default_k03, 16.251469).
navstivil(5059, default_p20, default_k03, 16.251469).
navstivil(5060, default_p20, default_k03, 16.251469).
navstivil(5061, default_p20, default_k03, 38.251478).
navstivil(5062, default_p20, default_k03, 38.251478).
navstivil(5063, default_p20, default_k03, 38.251478).
navstivil(5064, default_p20, default_k03, 15.251488).
navstivil(5065, default_p20, default_k03, 15.251488).
navstivil(5066, default_p20, default_k03, 15.251488).
navstivil(5067, default_p20, default_k03, 40.251497).
navstivil(5068, default_p20, default_k03, 40.251497).
navstivil(5069, default_p20, default_k03, 40.251497).
navstivil(5070, default_p20, default_k04, 50.251507).
navstivil(5071, default_p20, default_k04, 50.251507).
navstivil(5072, default_p20, default_k04, 50.251507).
navstivil(5073, default_p20, default_k04, 97.251517).
navstivil(5074, default_p20, default_k04, 97.251517).
navstivil(5075, default_p20, default_k04, 97.251517).
navstivil(5076, default_p20, default_k04, 39.25153).
navstivil(5077, default_p20, default_k04, 39.25153).
navstivil(5078, default_p20, default_k04, 39.25153).
navstivil(5079, default_p20, default_k04, 4.251539).
navstivil(5080, default_p20, default_k04, 4.251539).
navstivil(5081, default_p20, default_k04, 4.251539).
navstivil(5082, default_p20, default_k04, 65.251549).
navstivil(5083, default_p20, default_k04, 65.251549).
navstivil(5084, default_p20, default_k04, 65.251549).
navstivil(5085, default_p20, default_k04, 81.251559).
navstivil(5086, default_p20, default_k04, 81.251559).
navstivil(5087, default_p20, default_k04, 81.251559).
navstivil(5088, default_p20, default_k04, 31.251568).
navstivil(5089, default_p20, default_k04, 31.251568).
navstivil(5090, default_p20, default_k04, 31.251568).
navstivil(5091, default_p20, default_k04, 16.251577).
navstivil(5092, default_p20, default_k04, 16.251577).
navstivil(5093, default_p20, default_k04, 16.251577).
navstivil(5094, default_p20, default_k04, 48.251587).
navstivil(5095, default_p20, default_k04, 48.251587).
navstivil(5096, default_p20, default_k04, 48.251587).
navstivil(5097, default_p20, default_k04, 59.251597).
navstivil(5098, default_p20, default_k04, 59.251597).
navstivil(5099, default_p20, default_k04, 59.251597).
navstivil(5100, default_p20, default_k04, 33.251606).
navstivil(5101, default_p20, default_k04, 33.251606).
navstivil(5102, default_p20, default_k04, 33.251606).
navstivil(5103, default_p20, default_k04, 89.251615).
navstivil(5104, default_p20, default_k04, 89.251615).
navstivil(5105, default_p20, default_k04, 89.251615).
navstivil(5106, default_p20, default_k04, 69.251625).
navstivil(5107, default_p20, default_k04, 69.251625).
navstivil(5108, default_p20, default_k04, 69.251625).
navstivil(5109, default_p20, default_k04, 55.251634).
navstivil(5110, default_p20, default_k04, 55.251634).
navstivil(5111, default_p20, default_k04, 55.251634).
navstivil(5112, default_p20, default_k04, 87.251643).
navstivil(5113, default_p20, default_k04, 87.251643).
navstivil(5114, default_p20, default_k04, 87.251643).
navstivil(5115, default_p20, default_k04, 76.251653).
navstivil(5116, default_p20, default_k04, 76.251653).
navstivil(5117, default_p20, default_k04, 76.251653).
navstivil(5118, default_p20, default_k04, 49.251665).
navstivil(5119, default_p20, default_k04, 49.251665).
navstivil(5120, default_p20, default_k04, 49.251665).
navstivil(5121, default_p20, default_k04, 55.251675).
navstivil(5122, default_p20, default_k04, 55.251675).
navstivil(5123, default_p20, default_k04, 55.251675).
navstivil(5124, default_p20, default_k04, 59.251687).
navstivil(5125, default_p20, default_k04, 59.251687).
navstivil(5126, default_p20, default_k04, 59.251687).
navstivil(5127, default_p20, default_k05, 95.251696).
navstivil(5128, default_p20, default_k05, 95.251696).
navstivil(5129, default_p20, default_k05, 95.251696).
navstivil(5130, default_p20, default_k05, 28.251706).
navstivil(5131, default_p20, default_k05, 28.251706).
navstivil(5132, default_p20, default_k05, 28.251706).
navstivil(5133, default_p20, default_k05, 5.251715).
navstivil(5134, default_p20, default_k05, 5.251715).
navstivil(5135, default_p20, default_k05, 5.251715).
navstivil(5136, default_p20, default_k05, 31.251725).
navstivil(5137, default_p20, default_k05, 31.251725).
navstivil(5138, default_p20, default_k05, 31.251725).
navstivil(5139, default_p20, default_k05, 97.251734).
navstivil(5140, default_p20, default_k05, 97.251734).
navstivil(5141, default_p20, default_k05, 97.251734).
navstivil(5142, default_p20, default_k05, 79.251744).
navstivil(5143, default_p20, default_k05, 79.251744).
navstivil(5144, default_p20, default_k05, 79.251744).
navstivil(5145, default_p20, default_k05, 64.251753).
navstivil(5146, default_p20, default_k05, 64.251753).
navstivil(5147, default_p20, default_k05, 64.251753).
navstivil(5148, default_p20, default_k05, 19.251763).
navstivil(5149, default_p20, default_k05, 19.251763).
navstivil(5150, default_p20, default_k05, 19.251763).
navstivil(5151, default_p20, default_k05, 6.251772).
navstivil(5152, default_p20, default_k05, 6.251772).
navstivil(5153, default_p20, default_k05, 6.251772).
navstivil(5154, default_p20, default_k05, 84.251782).
navstivil(5155, default_p20, default_k05, 84.251782).
navstivil(5156, default_p20, default_k05, 84.251782).
navstivil(5157, default_p20, default_k05, 68.251792).
navstivil(5158, default_p20, default_k05, 68.251792).
navstivil(5159, default_p20, default_k05, 68.251792).
navstivil(5160, default_p20, default_k05, 78.251804).
navstivil(5161, default_p20, default_k05, 78.251804).
navstivil(5162, default_p20, default_k05, 78.251804).
navstivil(5163, default_p20, default_k05, 95.251813).
navstivil(5164, default_p20, default_k05, 95.251813).
navstivil(5165, default_p20, default_k05, 95.251813).
navstivil(5166, default_p20, default_k05, 23.251822).
navstivil(5167, default_p20, default_k05, 23.251822).
navstivil(5168, default_p20, default_k05, 23.251822).
navstivil(5169, default_p20, default_k05, 96.251832).
navstivil(5170, default_p20, default_k05, 96.251832).
navstivil(5171, default_p20, default_k05, 96.251832).
navstivil(5172, default_p20, default_k05, 79.251842).
navstivil(5173, default_p20, default_k05, 79.251842).
navstivil(5174, default_p20, default_k05, 79.251842).
navstivil(5175, default_p20, default_k05, 93.251851).
navstivil(5176, default_p20, default_k05, 93.251851).
navstivil(5177, default_p20, default_k05, 93.251851).
navstivil(5178, default_p20, default_k05, 74.251861).
navstivil(5179, default_p20, default_k05, 74.251861).
navstivil(5180, default_p20, default_k05, 74.251861).
navstivil(5181, default_p20, default_k05, 1.25187).
navstivil(5182, default_p20, default_k05, 1.25187).
navstivil(5183, default_p20, default_k05, 1.25187).
navstivil(5184, default_p20, default_k06, 82.25188).
navstivil(5185, default_p20, default_k06, 82.25188).
navstivil(5186, default_p20, default_k06, 82.25188).
navstivil(5187, default_p20, default_k06, 50.25189).
navstivil(5188, default_p20, default_k06, 50.25189).
navstivil(5189, default_p20, default_k06, 50.25189).
navstivil(5190, default_p20, default_k06, 96.2519).
navstivil(5191, default_p20, default_k06, 96.2519).
navstivil(5192, default_p20, default_k06, 96.2519).
navstivil(5193, default_p20, default_k06, 29.251909).
navstivil(5194, default_p20, default_k06, 29.251909).
navstivil(5195, default_p20, default_k06, 29.251909).
navstivil(5196, default_p20, default_k06, 16.251918).
navstivil(5197, default_p20, default_k06, 16.251918).
navstivil(5198, default_p20, default_k06, 16.251918).
navstivil(5199, default_p20, default_k06, 60.251928).
navstivil(5200, default_p20, default_k06, 60.251928).
navstivil(5201, default_p20, default_k06, 60.251928).
navstivil(5202, default_p20, default_k06, 46.251941).
navstivil(5203, default_p20, default_k06, 46.251941).
navstivil(5204, default_p20, default_k06, 46.251941).
navstivil(5205, default_p20, default_k06, 66.25195).
navstivil(5206, default_p20, default_k06, 66.25195).
navstivil(5207, default_p20, default_k06, 66.25195).
navstivil(5208, default_p20, default_k06, 53.25196).
navstivil(5209, default_p20, default_k06, 53.25196).
navstivil(5210, default_p20, default_k06, 53.25196).
navstivil(5211, default_p20, default_k06, 20.251969).
navstivil(5212, default_p20, default_k06, 20.251969).
navstivil(5213, default_p20, default_k06, 20.251969).
navstivil(5214, default_p20, default_k06, 18.251979).
navstivil(5215, default_p20, default_k06, 18.251979).
navstivil(5216, default_p20, default_k06, 18.251979).
navstivil(5217, default_p20, default_k06, 46.251988).
navstivil(5218, default_p20, default_k06, 46.251988).
navstivil(5219, default_p20, default_k06, 46.251988).
navstivil(5220, default_p20, default_k06, 48.251998).
navstivil(5221, default_p20, default_k06, 48.251998).
navstivil(5222, default_p20, default_k06, 48.251998).
navstivil(5223, default_p20, default_k06, 72.252008).
navstivil(5224, default_p20, default_k06, 72.252008).
navstivil(5225, default_p20, default_k06, 72.252008).
navstivil(5226, default_p20, default_k06, 47.252032).
navstivil(5227, default_p20, default_k06, 47.252032).
navstivil(5228, default_p20, default_k06, 47.252032).
navstivil(5229, default_p20, default_k06, 32.252051).
navstivil(5230, default_p20, default_k06, 32.252051).
navstivil(5231, default_p20, default_k06, 32.252051).
navstivil(5232, default_p20, default_k06, 3.252062).
navstivil(5233, default_p20, default_k06, 3.252062).
navstivil(5234, default_p20, default_k06, 3.252062).
navstivil(5235, default_p20, default_k06, 62.252071).
navstivil(5236, default_p20, default_k06, 62.252071).
navstivil(5237, default_p20, default_k06, 62.252071).
navstivil(5238, default_p20, default_k06, 67.252081).
navstivil(5239, default_p20, default_k06, 67.252081).
navstivil(5240, default_p20, default_k06, 67.252081).
navstivil(5241, default_p20, default_k07, 37.252091).
navstivil(5242, default_p20, default_k07, 37.252091).
navstivil(5243, default_p20, default_k07, 37.252091).
navstivil(5244, default_p20, default_k07, 8.252103).
navstivil(5245, default_p20, default_k07, 8.252103).
navstivil(5246, default_p20, default_k07, 8.252103).
navstivil(5247, default_p20, default_k07, 62.252114).
navstivil(5248, default_p20, default_k07, 62.252114).
navstivil(5249, default_p20, default_k07, 62.252114).
navstivil(5250, default_p20, default_k07, 39.252124).
navstivil(5251, default_p20, default_k07, 39.252124).
navstivil(5252, default_p20, default_k07, 39.252124).
navstivil(5253, default_p20, default_k07, 22.252133).
navstivil(5254, default_p20, default_k07, 22.252133).
navstivil(5255, default_p20, default_k07, 22.252133).
navstivil(5256, default_p20, default_k07, 58.252143).
navstivil(5257, default_p20, default_k07, 58.252143).
navstivil(5258, default_p20, default_k07, 58.252143).
navstivil(5259, default_p20, default_k07, 77.252152).
navstivil(5260, default_p20, default_k07, 77.252152).
navstivil(5261, default_p20, default_k07, 77.252152).
navstivil(5262, default_p20, default_k07, 18.252162).
navstivil(5263, default_p20, default_k07, 18.252162).
navstivil(5264, default_p20, default_k07, 18.252162).
navstivil(5265, default_p20, default_k07, 10.252171).
navstivil(5266, default_p20, default_k07, 10.252171).
navstivil(5267, default_p20, default_k07, 10.252171).
navstivil(5268, default_p20, default_k07, 89.252181).
navstivil(5269, default_p20, default_k07, 89.252181).
navstivil(5270, default_p20, default_k07, 89.252181).
navstivil(5271, default_p20, default_k07, 49.252191).
navstivil(5272, default_p20, default_k07, 49.252191).
navstivil(5273, default_p20, default_k07, 49.252191).
navstivil(5274, default_p20, default_k07, 24.2522).
navstivil(5275, default_p20, default_k07, 24.2522).
navstivil(5276, default_p20, default_k07, 24.2522).
navstivil(5277, default_p20, default_k07, 21.252209).
navstivil(5278, default_p20, default_k07, 21.252209).
navstivil(5279, default_p20, default_k07, 21.252209).
navstivil(5280, default_p20, default_k07, 27.252219).
navstivil(5281, default_p20, default_k07, 27.252219).
navstivil(5282, default_p20, default_k07, 27.252219).
navstivil(5283, default_p20, default_k07, 66.252229).
navstivil(5284, default_p20, default_k07, 66.252229).
navstivil(5285, default_p20, default_k07, 66.252229).
navstivil(5286, default_p20, default_k07, 97.252244).
navstivil(5287, default_p20, default_k07, 97.252244).
navstivil(5288, default_p20, default_k07, 97.252244).
navstivil(5289, default_p20, default_k07, 99.252254).
navstivil(5290, default_p20, default_k07, 99.252254).
navstivil(5291, default_p20, default_k07, 99.252254).
navstivil(5292, default_p20, default_k07, 66.252263).
navstivil(5293, default_p20, default_k07, 66.252263).
navstivil(5294, default_p20, default_k07, 66.252263).
navstivil(5295, default_p20, default_k07, 40.252273).
navstivil(5296, default_p20, default_k07, 40.252273).
navstivil(5297, default_p20, default_k07, 40.252273).
navstivil(5298, default_p20, default_k08, 16.252283).
navstivil(5299, default_p20, default_k08, 16.252283).
navstivil(5300, default_p20, default_k08, 16.252283).
navstivil(5301, default_p20, default_k08, 38.252293).
navstivil(5302, default_p20, default_k08, 38.252293).
navstivil(5303, default_p20, default_k08, 38.252293).
navstivil(5304, default_p20, default_k08, 85.252303).
navstivil(5305, default_p20, default_k08, 85.252303).
navstivil(5306, default_p20, default_k08, 85.252303).
navstivil(5307, default_p20, default_k08, 71.252313).
navstivil(5308, default_p20, default_k08, 71.252313).
navstivil(5309, default_p20, default_k08, 71.252313).
navstivil(5310, default_p20, default_k08, 93.252322).
navstivil(5311, default_p20, default_k08, 93.252322).
navstivil(5312, default_p20, default_k08, 93.252322).
navstivil(5313, default_p20, default_k08, 73.252331).
navstivil(5314, default_p20, default_k08, 73.252331).
navstivil(5315, default_p20, default_k08, 73.252331).
navstivil(5316, default_p20, default_k08, 79.252341).
navstivil(5317, default_p20, default_k08, 79.252341).
navstivil(5318, default_p20, default_k08, 79.252341).
navstivil(5319, default_p20, default_k08, 96.25235).
navstivil(5320, default_p20, default_k08, 96.25235).
navstivil(5321, default_p20, default_k08, 96.25235).
navstivil(5322, default_p20, default_k08, 48.25236).
navstivil(5323, default_p20, default_k08, 48.25236).
navstivil(5324, default_p20, default_k08, 48.25236).
navstivil(5325, default_p20, default_k08, 66.25237).
navstivil(5326, default_p20, default_k08, 66.25237).
navstivil(5327, default_p20, default_k08, 66.25237).
navstivil(5328, default_p20, default_k08, 100.252382).
navstivil(5329, default_p20, default_k08, 100.252382).
navstivil(5330, default_p20, default_k08, 100.252382).
navstivil(5331, default_p20, default_k08, 44.252392).
navstivil(5332, default_p20, default_k08, 44.252392).
navstivil(5333, default_p20, default_k08, 44.252392).
navstivil(5334, default_p20, default_k08, 78.252402).
navstivil(5335, default_p20, default_k08, 78.252402).
navstivil(5336, default_p20, default_k08, 78.252402).
navstivil(5337, default_p20, default_k08, 1.252411).
navstivil(5338, default_p20, default_k08, 1.252411).
navstivil(5339, default_p20, default_k08, 1.252411).
navstivil(5340, default_p20, default_k08, 19.252421).
navstivil(5341, default_p20, default_k08, 19.252421).
navstivil(5342, default_p20, default_k08, 19.252421).
navstivil(5343, default_p20, default_k08, 85.25243).
navstivil(5344, default_p20, default_k08, 85.25243).
navstivil(5345, default_p20, default_k08, 85.25243).
navstivil(5346, default_p20, default_k08, 60.25244).
navstivil(5347, default_p20, default_k08, 60.25244).
navstivil(5348, default_p20, default_k08, 60.25244).
navstivil(5349, default_p20, default_k08, 95.252449).
navstivil(5350, default_p20, default_k08, 95.252449).
navstivil(5351, default_p20, default_k08, 95.252449).
navstivil(5352, default_p20, default_k08, 97.252458).
navstivil(5353, default_p20, default_k08, 97.252458).
navstivil(5354, default_p20, default_k08, 97.252458).
navstivil(5355, default_p20, default_k09, 6.252468).
navstivil(5356, default_p20, default_k09, 6.252468).
navstivil(5357, default_p20, default_k09, 6.252468).
navstivil(5358, default_p20, default_k09, 45.252479).
navstivil(5359, default_p20, default_k09, 45.252479).
navstivil(5360, default_p20, default_k09, 45.252479).
navstivil(5361, default_p20, default_k09, 53.252488).
navstivil(5362, default_p20, default_k09, 53.252488).
navstivil(5363, default_p20, default_k09, 53.252488).
navstivil(5364, default_p20, default_k09, 9.252971).
navstivil(5365, default_p20, default_k09, 9.252971).
navstivil(5366, default_p20, default_k09, 9.252971).
navstivil(5367, default_p20, default_k09, 49.252986).
navstivil(5368, default_p20, default_k09, 49.252986).
navstivil(5369, default_p20, default_k09, 49.252986).
navstivil(5370, default_p20, default_k09, 5.252998).
navstivil(5371, default_p20, default_k09, 5.252998).
navstivil(5372, default_p20, default_k09, 5.252998).
navstivil(5373, default_p20, default_k09, 39.253009).
navstivil(5374, default_p20, default_k09, 39.253009).
navstivil(5375, default_p20, default_k09, 39.253009).
navstivil(5376, default_p20, default_k09, 5.253024).
navstivil(5377, default_p20, default_k09, 5.253024).
navstivil(5378, default_p20, default_k09, 5.253024).
navstivil(5379, default_p20, default_k09, 50.253035).
navstivil(5380, default_p20, default_k09, 50.253035).
navstivil(5381, default_p20, default_k09, 50.253035).
navstivil(5382, default_p20, default_k09, 49.253045).
navstivil(5383, default_p20, default_k09, 49.253045).
navstivil(5384, default_p20, default_k09, 49.253045).
navstivil(5385, default_p20, default_k09, 3.253056).
navstivil(5386, default_p20, default_k09, 3.253056).
navstivil(5387, default_p20, default_k09, 3.253056).
navstivil(5388, default_p20, default_k09, 91.253066).
navstivil(5389, default_p20, default_k09, 91.253066).
navstivil(5390, default_p20, default_k09, 91.253066).
navstivil(5391, default_p20, default_k09, 26.253075).
navstivil(5392, default_p20, default_k09, 26.253075).
navstivil(5393, default_p20, default_k09, 26.253075).
navstivil(5394, default_p20, default_k09, 31.253085).
navstivil(5395, default_p20, default_k09, 31.253085).
navstivil(5396, default_p20, default_k09, 31.253085).
navstivil(5397, default_p20, default_k09, 100.253095).
navstivil(5398, default_p20, default_k09, 100.253095).
navstivil(5399, default_p20, default_k09, 100.253095).
navstivil(5400, default_p20, default_k09, 69.253105).
navstivil(5401, default_p20, default_k09, 69.253105).
navstivil(5402, default_p20, default_k09, 69.253105).
navstivil(5403, default_p20, default_k09, 43.253114).
navstivil(5404, default_p20, default_k09, 43.253114).
navstivil(5405, default_p20, default_k09, 43.253114).
navstivil(5406, default_p20, default_k09, 88.253124).
navstivil(5407, default_p20, default_k09, 88.253124).
navstivil(5408, default_p20, default_k09, 88.253124).
navstivil(5409, default_p20, default_k09, 68.253134).
navstivil(5410, default_p20, default_k09, 68.253134).
navstivil(5411, default_p20, default_k09, 68.253134).
navstivil(5412, default_p20, default_k10, 36.253144).
navstivil(5413, default_p20, default_k10, 36.253144).
navstivil(5414, default_p20, default_k10, 36.253144).
navstivil(5415, default_p20, default_k10, 19.253154).
navstivil(5416, default_p20, default_k10, 19.253154).
navstivil(5417, default_p20, default_k10, 19.253154).
navstivil(5418, default_p20, default_k10, 92.253163).
navstivil(5419, default_p20, default_k10, 92.253163).
navstivil(5420, default_p20, default_k10, 92.253163).
navstivil(5421, default_p20, default_k10, 4.253173).
navstivil(5422, default_p20, default_k10, 4.253173).
navstivil(5423, default_p20, default_k10, 4.253173).
navstivil(5424, default_p20, default_k10, 15.253182).
navstivil(5425, default_p20, default_k10, 15.253182).
navstivil(5426, default_p20, default_k10, 15.253182).
navstivil(5427, default_p20, default_k10, 43.253192).
navstivil(5428, default_p20, default_k10, 43.253192).
navstivil(5429, default_p20, default_k10, 43.253192).
navstivil(5430, default_p20, default_k10, 79.253202).
navstivil(5431, default_p20, default_k10, 79.253202).
navstivil(5432, default_p20, default_k10, 79.253202).
navstivil(5433, default_p20, default_k10, 72.253212).
navstivil(5434, default_p20, default_k10, 72.253212).
navstivil(5435, default_p20, default_k10, 72.253212).
navstivil(5436, default_p20, default_k10, 79.253221).
navstivil(5437, default_p20, default_k10, 79.253221).
navstivil(5438, default_p20, default_k10, 79.253221).
navstivil(5439, default_p20, default_k10, 14.253231).
navstivil(5440, default_p20, default_k10, 14.253231).
navstivil(5441, default_p20, default_k10, 14.253231).
navstivil(5442, default_p20, default_k10, 58.25324).
navstivil(5443, default_p20, default_k10, 58.25324).
navstivil(5444, default_p20, default_k10, 58.25324).
navstivil(5445, default_p20, default_k10, 79.25325).
navstivil(5446, default_p20, default_k10, 79.25325).
navstivil(5447, default_p20, default_k10, 79.25325).
navstivil(5448, default_p20, default_k10, 8.25326).
navstivil(5449, default_p20, default_k10, 8.25326).
navstivil(5450, default_p20, default_k10, 8.25326).
navstivil(5451, default_p20, default_k10, 98.253269).
navstivil(5452, default_p20, default_k10, 98.253269).
navstivil(5453, default_p20, default_k10, 98.253269).
navstivil(5454, default_p20, default_k10, 86.253279).
navstivil(5455, default_p20, default_k10, 86.253279).
navstivil(5456, default_p20, default_k10, 86.253279).
navstivil(5457, default_p20, default_k10, 22.253288).
navstivil(5458, default_p20, default_k10, 22.253288).
navstivil(5459, default_p20, default_k10, 22.253288).
navstivil(5460, default_p20, default_k10, 37.253298).
navstivil(5461, default_p20, default_k10, 37.253298).
navstivil(5462, default_p20, default_k10, 37.253298).
navstivil(5463, default_p20, default_k10, 98.253308).
navstivil(5464, default_p20, default_k10, 98.253308).
navstivil(5465, default_p20, default_k10, 98.253308).
navstivil(5466, default_p20, default_k10, 90.253317).
navstivil(5467, default_p20, default_k10, 90.253317).
navstivil(5468, default_p20, default_k10, 90.253317).
navstivil(5469, a_p1, default_k01, 36.253331).
navstivil(5470, a_p1, default_k01, 36.253331).
navstivil(5471, a_p1, default_k01, 36.253331).
navstivil(5472, a_p1, default_k01, 15.253341).
navstivil(5473, a_p1, default_k01, 15.253341).
navstivil(5474, a_p1, default_k01, 15.253341).
navstivil(5475, a_p1, default_k01, 70.253351).
navstivil(5476, a_p1, default_k01, 70.253351).
navstivil(5477, a_p1, default_k01, 70.253351).
navstivil(5478, a_p1, default_k01, 56.253361).
navstivil(5479, a_p1, default_k01, 56.253361).
navstivil(5480, a_p1, default_k01, 56.253361).
navstivil(5481, a_p1, default_k01, 76.253371).
navstivil(5482, a_p1, default_k01, 76.253371).
navstivil(5483, a_p1, default_k01, 76.253371).
navstivil(5484, a_p1, default_k01, 10.253381).
navstivil(5485, a_p1, default_k01, 10.253381).
navstivil(5486, a_p1, default_k01, 10.253381).
navstivil(5487, a_p1, default_k01, 75.253391).
navstivil(5488, a_p1, default_k01, 75.253391).
navstivil(5489, a_p1, default_k01, 75.253391).
navstivil(5490, a_p1, default_k01, 54.253401).
navstivil(5491, a_p1, default_k01, 54.253401).
navstivil(5492, a_p1, default_k01, 54.253401).
navstivil(5493, a_p1, default_k01, 86.253411).
navstivil(5494, a_p1, default_k01, 86.253411).
navstivil(5495, a_p1, default_k01, 86.253411).
navstivil(5496, a_p1, default_k01, 54.25342).
navstivil(5497, a_p1, default_k01, 54.25342).
navstivil(5498, a_p1, default_k01, 54.25342).
navstivil(5499, a_p1, default_k01, 3.25343).
navstivil(5500, a_p1, default_k01, 3.25343).
navstivil(5501, a_p1, default_k01, 3.25343).
navstivil(5502, a_p1, default_k01, 42.253439).
navstivil(5503, a_p1, default_k01, 42.253439).
navstivil(5504, a_p1, default_k01, 42.253439).
navstivil(5505, a_p1, default_k01, 11.253449).
navstivil(5506, a_p1, default_k01, 11.253449).
navstivil(5507, a_p1, default_k01, 11.253449).
navstivil(5508, a_p1, default_k01, 88.253459).
navstivil(5509, a_p1, default_k01, 88.253459).
navstivil(5510, a_p1, default_k01, 88.253459).
navstivil(5511, a_p1, default_k01, 62.253468).
navstivil(5512, a_p1, default_k01, 62.253468).
navstivil(5513, a_p1, default_k01, 62.253468).
navstivil(5514, a_p1, default_k01, 88.253478).
navstivil(5515, a_p1, default_k01, 88.253478).
navstivil(5516, a_p1, default_k01, 88.253478).
navstivil(5517, a_p1, default_k01, 96.253488).
navstivil(5518, a_p1, default_k01, 96.253488).
navstivil(5519, a_p1, default_k01, 96.253488).
navstivil(5520, a_p1, default_k01, 16.253497).
navstivil(5521, a_p1, default_k01, 16.253497).
navstivil(5522, a_p1, default_k01, 16.253497).
navstivil(5523, a_p1, default_k01, 84.253507).
navstivil(5524, a_p1, default_k01, 84.253507).
navstivil(5525, a_p1, default_k01, 84.253507).
navstivil(5526, a_p1, default_k01, 54.253516).
navstivil(5527, a_p1, default_k01, 54.253516).
navstivil(5528, a_p1, default_k01, 54.253516).
navstivil(5529, a_p1, default_k01, 47.253526).
navstivil(5530, a_p1, default_k01, 47.253526).
navstivil(5531, a_p1, default_k01, 47.253526).
navstivil(5532, a_p1, default_k01, 71.253535).
navstivil(5533, a_p1, default_k01, 71.253535).
navstivil(5534, a_p1, default_k01, 71.253535).
navstivil(5535, a_p1, default_k01, 59.253545).
navstivil(5536, a_p1, default_k01, 59.253545).
navstivil(5537, a_p1, default_k01, 59.253545).
navstivil(5538, a_p1, default_k01, 91.253554).
navstivil(5539, a_p1, default_k01, 91.253554).
navstivil(5540, a_p1, default_k01, 91.253554).
navstivil(5541, a_p1, default_k01, 22.253564).
navstivil(5542, a_p1, default_k01, 22.253564).
navstivil(5543, a_p1, default_k01, 22.253564).
navstivil(5544, a_p1, default_k01, 25.253573).
navstivil(5545, a_p1, default_k01, 25.253573).
navstivil(5546, a_p1, default_k01, 25.253573).
navstivil(5547, a_p1, default_k01, 63.253583).
navstivil(5548, a_p1, default_k01, 63.253583).
navstivil(5549, a_p1, default_k01, 63.253583).
navstivil(5550, a_p1, default_k01, 13.253593).
navstivil(5551, a_p1, default_k01, 13.253593).
navstivil(5552, a_p1, default_k01, 13.253593).
navstivil(5553, a_p1, default_k01, 61.253602).
navstivil(5554, a_p1, default_k01, 61.253602).
navstivil(5555, a_p1, default_k01, 61.253602).
navstivil(5556, a_p1, default_k01, 5.253612).
navstivil(5557, a_p1, default_k01, 5.253612).
navstivil(5558, a_p1, default_k01, 5.253612).
navstivil(5559, a_p1, default_k01, 46.253622).
navstivil(5560, a_p1, default_k01, 46.253622).
navstivil(5561, a_p1, default_k01, 46.253622).
navstivil(5562, a_p1, default_k01, 18.253631).
navstivil(5563, a_p1, default_k01, 18.253631).
navstivil(5564, a_p1, default_k01, 18.253631).
navstivil(5565, a_p1, default_k01, 54.253641).
navstivil(5566, a_p1, default_k01, 54.253641).
navstivil(5567, a_p1, default_k01, 54.253641).
navstivil(5568, a_p1, default_k01, 56.253651).
navstivil(5569, a_p1, default_k01, 56.253651).
navstivil(5570, a_p1, default_k01, 56.253651).
navstivil(5571, a_p1, default_k01, 31.25366).
navstivil(5572, a_p1, default_k01, 31.25366).
navstivil(5573, a_p1, default_k01, 31.25366).
navstivil(5574, a_p1, default_k01, 71.25367).
navstivil(5575, a_p1, default_k01, 71.25367).
navstivil(5576, a_p1, default_k01, 71.25367).
navstivil(5577, a_p1, default_k01, 60.25368).
navstivil(5578, a_p1, default_k01, 60.25368).
navstivil(5579, a_p1, default_k01, 60.25368).
navstivil(5580, a_p1, default_k01, 99.25369).
navstivil(5581, a_p1, default_k01, 99.25369).
navstivil(5582, a_p1, default_k01, 99.25369).
navstivil(5583, a_p1, default_k01, 90.253699).
navstivil(5584, a_p1, default_k01, 90.253699).
navstivil(5585, a_p1, default_k01, 90.253699).
navstivil(5586, a_p1, default_k01, 73.253709).
navstivil(5587, a_p1, default_k01, 73.253709).
navstivil(5588, a_p1, default_k01, 73.253709).
navstivil(5589, a_p1, default_k01, 32.253719).
navstivil(5590, a_p1, default_k01, 32.253719).
navstivil(5591, a_p1, default_k01, 32.253719).
navstivil(5592, a_p1, default_k01, 53.253728).
navstivil(5593, a_p1, default_k01, 53.253728).
navstivil(5594, a_p1, default_k01, 53.253728).
navstivil(5595, a_p1, default_k01, 39.253738).
navstivil(5596, a_p1, default_k01, 39.253738).
navstivil(5597, a_p1, default_k01, 39.253738).
navstivil(5598, a_p1, default_k01, 82.253748).
navstivil(5599, a_p1, default_k01, 82.253748).
navstivil(5600, a_p1, default_k01, 82.253748).
navstivil(5601, a_p1, default_k01, 73.253758).
navstivil(5602, a_p1, default_k01, 73.253758).
navstivil(5603, a_p1, default_k01, 73.253758).
navstivil(5604, a_p1, default_k01, 5.253767).
navstivil(5605, a_p1, default_k01, 5.253767).
navstivil(5606, a_p1, default_k01, 5.253767).
navstivil(5607, a_p1, default_k01, 46.253777).
navstivil(5608, a_p1, default_k01, 46.253777).
navstivil(5609, a_p1, default_k01, 46.253777).
navstivil(5610, a_p1, default_k01, 1.253786).
navstivil(5611, a_p1, default_k01, 1.253786).
navstivil(5612, a_p1, default_k01, 1.253786).
navstivil(5613, a_p1, default_k01, 29.253796).
navstivil(5614, a_p1, default_k01, 29.253796).
navstivil(5615, a_p1, default_k01, 29.253796).
navstivil(5616, a_p1, default_k01, 30.253806).
navstivil(5617, a_p1, default_k01, 30.253806).
navstivil(5618, a_p1, default_k01, 30.253806).
navstivil(5619, a_p2, default_k02, 71.253813).
navstivil(5620, a_p2, default_k01, 39.253817).
navstivil(5621, a_p2, default_k02, 91.25382).
navstivil(5622, a_p2, default_k06, 87.253824).
navstivil(5623, a_p2, default_k01, 19.253827).
navstivil(5624, a_p2, default_k02, 79.25383).
navstivil(5625, a_p2, default_k01, 92.253833).
navstivil(5626, a_p2, default_k01, 49.253836).
navstivil(5627, a_p2, default_k02, 4.25384).
navstivil(5628, a_p2, default_k03, 50.253843).
navstivil(5629, a_p2, default_k01, 6.253847).
navstivil(5630, a_p2, default_k01, 33.25385).
navstivil(5631, b_p1, default_k02, 1).
navstivil(5632, b_p1, default_k03, 2).
navstivil(5633, b_p1, default_k04, 3).
navstivil(5634, b_p1, default_k05, 4).
navstivil(5635, b_p1, default_k06, 5).
navstivil(5636, b_p1, default_k09, 6).
navstivil(5637, b_p1, default_k10, 7).
navstivil(5638, b_p1, default_k01, 8).
navstivil(5639, b_p1, default_k03, 9).
navstivil(5640, b_p1, default_k04, 10).
navstivil(5641, b_p1, default_k08, 11).
navstivil(5642, b_p1, default_k09, 12).
navstivil(5643, b_p1, default_k02, 13).
navstivil(5644, b_p1, default_k03, 14).
navstivil(5645, b_p1, default_k04, 15).
navstivil(5646, b_p1, default_k05, 16).
navstivil(5647, b_p1, default_k07, 17).
navstivil(5648, b_p1, default_k06, 18).
navstivil(5649, b_p1, default_k07, 19).
navstivil(5650, b_p1, default_k08, 20).
navstivil(5651, b_p1, default_k10, 21).
navstivil(5652, b_p1, default_k01, 22).
navstivil(5653, b_p1, default_k10, 23).
navstivil(5654, b_p1, default_k02, 24).
navstivil(5655, b_p1, default_k03, 25).
navstivil(5656, b_p1, default_k04, 26).
navstivil(5657, b_p1, default_k06, 27).
navstivil(5658, b_p1, default_k07, 28).
navstivil(5659, b_p1, default_k10, 29).
navstivil(5660, b_p1, default_k01, 30).
navstivil(5661, b_p1, default_k02, 31).
navstivil(5662, b_p1, default_k03, 32).
navstivil(5663, b_p1, default_k06, 33).
navstivil(5664, b_p1, default_k07, 34).
navstivil(5665, b_p1, default_k10, 35).
navstivil(5666, b_p1, default_k01, 36).
navstivil(5667, b_p1, default_k02, 37).
navstivil(5668, b_p1, default_k04, 38).
navstivil(5669, b_p1, default_k05, 39).
navstivil(5670, b_p1, default_k08, 40).
navstivil(5671, b_p1, default_k09, 41).
navstivil(5672, b_p1, default_k02, 42).
navstivil(5673, b_p1, default_k05, 43).
navstivil(5674, b_p1, default_k06, 44).
navstivil(5675, b_p1, default_k08, 45).
navstivil(5676, b_p1, default_k09, 46).
navstivil(5677, b_p1, default_k03, 47).
navstivil(5678, b_p1, default_k05, 48).
navstivil(5679, b_p1, default_k07, 49).
navstivil(5680, b_p1, default_k08, 50).
navstivil(5681, b_p1, default_k09, 51).
navstivil(5682, b_p1, default_k01, 52).
navstivil(5683, b_p1, default_k05, 53).
navstivil(5684, b_p1, default_k06, 54).
navstivil(5685, b_p1, default_k07, 55).
navstivil(5686, b_p1, default_k09, 56).
navstivil(5687, b_p1, default_k10, 57).
navstivil(5688, b_p1, default_k01, 58).
navstivil(5689, b_p1, default_k04, 59).
navstivil(5690, b_p1, default_k08, 60).
navstivil(5691, b_p000, default_k01, 47).
navstivil(5692, b_p001, default_k07, 47).
navstivil(5693, b_p002, default_k04, 47).
navstivil(5694, b_p003, default_k01, 47).
navstivil(5695, b_p004, default_k10, 47).
navstivil(5696, default_p20, default_k01, 23.253996).
navstivil(5697, default_p20, default_k03, 50.254002).
navstivil(5698, default_p20, default_k04, 12.254005).
navstivil(5699, default_p20, default_k08, 15.254008).
navstivil(5700, default_p20, default_k09, 64.254011).
navstivil(5701, default_p20, default_k06, 59.254016).
navstivil(5702, default_p20, default_k07, 10.254019).
navstivil(5703, default_p20, default_k08, 98.254021).
navstivil(5704, default_p20, default_k10, 34.254025).
navstivil(5705, default_p20, default_k01, 38.254029).
navstivil(5706, default_p20, default_k02, 61.254032).
navstivil(5707, default_p20, default_k03, 100.254035).
navstivil(5708, default_p20, default_k06, 38.254038).
navstivil(5709, default_p20, default_k07, 24.254041).
navstivil(5710, default_p20, default_k10, 9.254045).
navstivil(5711, default_p20, default_k03, 52.254048).
navstivil(5712, default_p20, default_k05, 83.254052).
navstivil(5713, default_p20, default_k07, 100.254055).
navstivil(5714, default_p20, default_k08, 89.254058).
navstivil(5715, default_p20, default_k09, 33.254061).
navstivil(5716, default_p20, default_k01, 63.254064).
navstivil(5717, default_p20, default_k05, 68.254067).
navstivil(5718, default_p20, default_k06, 96.25407).
navstivil(5719, default_p20, default_k07, 85.254073).
navstivil(5720, default_p20, default_k09, 15.254077).
navstivil(5721, default_p20, default_k10, 29.254093).
navstivil(5722, default_p20, default_k01, 83.254096).
navstivil(5723, default_p20, default_k04, 41.254099).
navstivil(5724, default_p20, default_k08, 4.254102).
navstivil(5725, default_p19, default_k02, 4.254102).
navstivil(5726, default_p19, default_k03, 89.254417).
navstivil(5727, default_p19, default_k04, 33.25442).
navstivil(5728, default_p19, default_k06, 27.254423).
navstivil(5729, default_p19, default_k07, 67.254425).
navstivil(5730, default_p19, default_k10, 64.254428).
navstivil(5731, default_p19, default_k01, 69.254431).
navstivil(5732, default_p19, default_k02, 47.254434).
navstivil(5733, default_p19, default_k03, 63.254437).
navstivil(5734, default_p19, default_k06, 17.25444).
navstivil(5735, default_p19, default_k07, 89.254443).
navstivil(5736, default_p19, default_k10, 22.254446).
navstivil(5737, default_p19, default_k01, 33.254448).
navstivil(5738, default_p19, default_k02, 28.254451).
navstivil(5739, default_p19, default_k04, 42.254454).
navstivil(5740, default_p19, default_k05, 100.254456).
navstivil(5741, default_p19, default_k08, 36.254459).
navstivil(5742, default_p19, default_k09, 87.254462).
navstivil(5743, default_p19, default_k02, 54.254465).
navstivil(5744, default_p19, default_k05, 36.254468).
navstivil(5745, default_p19, default_k06, 42.254471).
navstivil(5746, default_p19, default_k08, 62.254473).
navstivil(5747, default_p19, default_k09, 54.254476).
navstivil(5748, default_p19, default_k01, 90.254479).
navstivil(5749, default_p19, default_k05, 2.254483).
navstivil(5750, default_p19, default_k06, 49.254485).
navstivil(5751, default_p19, default_k07, 91.254488).
navstivil(5752, default_p19, default_k09, 11.254491).
navstivil(5753, default_p19, default_k10, 56.254494).
navstivil(5754, default_p19, default_k01, 36.254497).
navstivil(5755, default_p19, default_k04, 90.2545).
navstivil(5756, default_p19, default_k08, 23.254503).
navstivil(5757, d_p1, d_k1, 5).


vypil(1, default_a02, 49).
vypil(2, default_a08, 85).
vypil(3, default_a11, 29).
vypil(4, default_a01, 71).
vypil(5, default_a07, 15).
vypil(6, default_a09, 18).
vypil(7, default_a01, 88).
vypil(8, default_a03, 62).
vypil(9, default_a07, 30).
vypil(10, default_a01, 100).
vypil(11, default_a02, 27).
vypil(12, default_a03, 34).
vypil(13, default_a01, 7).
vypil(14, default_a09, 56).
vypil(15, default_a10, 99).
vypil(16, default_a01, 100).
vypil(17, default_a07, 25).
vypil(18, default_a09, 74).
vypil(19, default_a04, 6).
vypil(20, default_a06, 54).
vypil(21, default_a07, 14).
vypil(22, default_a02, 40).
vypil(23, default_a04, 22).
vypil(24, default_a08, 25).
vypil(25, default_a01, 86).
vypil(26, default_a02, 29).
vypil(27, default_a08, 74).
vypil(28, default_a06, 54).
vypil(29, default_a07, 41).
vypil(30, default_a11, 84).
vypil(31, default_a05, 60).
vypil(32, default_a08, 91).
vypil(33, default_a11, 28).
vypil(34, default_a08, 79).
vypil(35, default_a11, 31).
vypil(36, default_a12, 41).
vypil(37, default_a03, 46).
vypil(38, default_a08, 17).
vypil(39, default_a09, 96).
vypil(40, default_a01, 100).
vypil(41, default_a03, 11).
vypil(42, default_a09, 44).
vypil(43, default_a01, 84).
vypil(44, default_a02, 1).
vypil(45, default_a06, 51).
vypil(46, default_a03, 4).
vypil(47, default_a07, 83).
vypil(48, default_a10, 58).
vypil(49, default_a01, 26).
vypil(50, default_a02, 18).
vypil(51, default_a03, 100).
vypil(52, default_a01, 72).
vypil(53, default_a06, 2).
vypil(54, default_a08, 79).
vypil(55, default_a01, 9).
vypil(56, default_a03, 51).
vypil(57, default_a11, 73).
vypil(58, default_a01, 57).
vypil(59, default_a09, 93).
vypil(60, default_a11, 48).
vypil(61, default_a06, 65).
vypil(62, default_a09, 55).
vypil(63, default_a11, 63).
vypil(64, default_a01, 3).
vypil(65, default_a06, 82).
vypil(66, default_a07, 20).
vypil(67, default_a06, 8).
vypil(68, default_a07, 23).
vypil(69, default_a10, 15).
vypil(70, default_a06, 2).
vypil(71, default_a07, 67).
vypil(72, default_a10, 1).
vypil(73, default_a02, 55).
vypil(74, default_a04, 26).
vypil(75, default_a08, 48).
vypil(76, default_a04, 52).
vypil(77, default_a09, 70).
vypil(78, default_a10, 55).
vypil(79, default_a08, 80).
vypil(80, default_a10, 10).
vypil(81, default_a11, 4).
vypil(82, default_a02, 44).
vypil(83, default_a09, 94).
vypil(84, default_a11, 39).
vypil(85, default_a05, 78).
vypil(86, default_a06, 24).
vypil(87, default_a11, 71).
vypil(88, default_a01, 89).
vypil(89, default_a04, 99).
vypil(90, default_a11, 62).
vypil(91, default_a02, 8).
vypil(92, default_a05, 11).
vypil(93, default_a07, 83).
vypil(94, default_a05, 72).
vypil(95, default_a07, 67).
vypil(96, default_a08, 14).
vypil(97, default_a05, 67).
vypil(98, default_a11, 33).
vypil(99, default_a12, 45).
vypil(100, default_a07, 88).
vypil(101, default_a08, 82).
vypil(102, default_a09, 16).
vypil(103, default_a01, 100).
vypil(104, default_a07, 52).
vypil(105, default_a09, 37).
vypil(106, default_a01, 91).
vypil(107, default_a06, 18).
vypil(108, default_a08, 2).
vypil(109, default_a06, 34).
vypil(110, default_a07, 88).
vypil(111, default_a10, 35).
vypil(112, default_a02, 14).
vypil(113, default_a06, 81).
vypil(114, default_a10, 82).
vypil(115, default_a01, 46).
vypil(116, default_a02, 70).
vypil(117, default_a07, 92).
vypil(118, default_a01, 86).
vypil(119, default_a02, 53).
vypil(120, default_a06, 45).
vypil(121, default_a03, 83).
vypil(122, default_a06, 68).
vypil(123, default_a12, 23).
vypil(124, default_a03, 74).
vypil(125, default_a06, 26).
vypil(126, default_a12, 78).
vypil(127, default_a03, 98).
vypil(128, default_a09, 20).
vypil(129, default_a11, 3).
vypil(130, default_a01, 34).
vypil(131, default_a09, 14).
vypil(132, default_a11, 60).
vypil(133, default_a09, 19).
vypil(134, default_a10, 51).
vypil(135, default_a11, 65).
vypil(136, default_a01, 80).
vypil(137, default_a04, 6).
vypil(138, default_a06, 31).
vypil(139, default_a01, 81).
vypil(140, default_a04, 14).
vypil(141, default_a09, 62).
vypil(142, default_a01, 91).
vypil(143, default_a04, 48).
vypil(144, default_a07, 47).
vypil(145, default_a03, 80).
vypil(146, default_a06, 3).
vypil(147, default_a07, 16).
vypil(148, default_a03, 93).
vypil(149, default_a04, 55).
vypil(150, default_a06, 35).
vypil(151, default_a03, 18).
vypil(152, default_a04, 58).
vypil(153, default_a10, 40).
vypil(154, default_a02, 10).
vypil(155, default_a04, 24).
vypil(156, default_a10, 6).
vypil(157, default_a02, 62).
vypil(158, default_a10, 59).
vypil(159, default_a12, 89).
vypil(160, default_a04, 84).
vypil(161, default_a08, 50).
vypil(162, default_a10, 71).
vypil(163, default_a01, 56).
vypil(164, default_a02, 40).
vypil(165, default_a10, 51).
vypil(166, default_a02, 42).
vypil(167, default_a09, 64).
vypil(168, default_a10, 94).
vypil(169, default_a02, 55).
vypil(170, default_a09, 3).
vypil(171, default_a11, 62).
vypil(172, default_a04, 50).
vypil(173, default_a06, 38).
vypil(174, default_a07, 83).
vypil(175, default_a01, 94).
vypil(176, default_a05, 25).
vypil(177, default_a07, 63).
vypil(178, default_a01, 82).
vypil(179, default_a05, 36).
vypil(180, default_a07, 12).
vypil(181, default_a02, 14).
vypil(182, default_a05, 49).
vypil(183, default_a08, 15).
vypil(184, default_a05, 67).
vypil(185, default_a08, 98).
vypil(186, default_a12, 99).
vypil(187, default_a02, 73).
vypil(188, default_a05, 9).
vypil(189, default_a12, 61).
vypil(190, default_a02, 51).
vypil(191, default_a08, 27).
vypil(192, default_a12, 48).
vypil(193, default_a03, 35).
vypil(194, default_a06, 31).
vypil(195, default_a07, 30).
vypil(196, default_a03, 53).
vypil(197, default_a07, 65).
vypil(198, default_a08, 52).
vypil(199, default_a01, 87).
vypil(200, default_a06, 74).
vypil(201, default_a08, 56).
vypil(202, default_a06, 58).
vypil(203, default_a07, 59).
vypil(204, default_a09, 77).
vypil(205, default_a01, 14).
vypil(206, default_a03, 69).
vypil(207, default_a07, 27).
vypil(208, default_a03, 34).
vypil(209, default_a07, 55).
vypil(210, default_a10, 75).
vypil(211, default_a02, 90).
vypil(212, default_a06, 38).
vypil(213, default_a10, 70).
vypil(214, default_a01, 87).
vypil(215, default_a02, 24).
vypil(216, default_a06, 14).
vypil(217, default_a02, 86).
vypil(218, default_a08, 32).
vypil(219, default_a12, 53).
vypil(220, default_a01, 90).
vypil(221, default_a06, 10).
vypil(222, default_a12, 9).
vypil(223, default_a01, 52).
vypil(224, default_a02, 50).
vypil(225, default_a12, 18).
vypil(226, default_a01, 68).
vypil(227, default_a02, 6).
vypil(228, default_a06, 87).
vypil(229, default_a01, 50).
vypil(230, default_a03, 86).
vypil(231, default_a08, 51).
vypil(232, default_a03, 9).
vypil(233, default_a10, 19).
vypil(234, default_a11, 14).
vypil(235, default_a03, 81).
vypil(236, default_a08, 32).
vypil(237, default_a10, 29).
vypil(238, default_a03, 70).
vypil(239, default_a09, 2).
vypil(240, default_a11, 77).
vypil(241, default_a01, 76).
vypil(242, default_a09, 63).
vypil(243, default_a11, 42).
vypil(244, default_a04, 13).
vypil(245, default_a06, 27).
vypil(246, default_a09, 35).
vypil(247, default_a04, 50).
vypil(248, default_a07, 22).
vypil(249, default_a09, 33).
vypil(250, default_a01, 14).
vypil(251, default_a07, 29).
vypil(252, default_a11, 30).
vypil(253, default_a06, 36).
vypil(254, default_a07, 68).
vypil(255, default_a10, 84).
vypil(256, default_a04, 98).
vypil(257, default_a10, 34).
vypil(258, default_a11, 63).
vypil(259, default_a03, 55).
vypil(260, default_a07, 50).
vypil(261, default_a11, 34).
vypil(262, default_a03, 94).
vypil(263, default_a06, 28).
vypil(264, default_a11, 79).
vypil(265, default_a04, 89).
vypil(266, default_a08, 55).
vypil(267, default_a10, 21).
vypil(268, default_a04, 56).
vypil(269, default_a08, 70).
vypil(270, default_a12, 43).
vypil(271, default_a09, 1).
vypil(272, default_a10, 75).
vypil(273, default_a12, 20).
vypil(274, default_a02, 92).
vypil(275, default_a04, 62).
vypil(276, default_a08, 3).
vypil(277, default_a02, 99).
vypil(278, default_a09, 68).
vypil(279, default_a11, 65).
vypil(280, default_a01, 35).
vypil(281, default_a08, 62).
vypil(282, default_a09, 40).
vypil(283, default_a08, 12).
vypil(284, default_a09, 45).
vypil(285, default_a10, 86).
vypil(286, default_a01, 67).
vypil(287, default_a09, 26).
vypil(288, default_a10, 16).
vypil(289, default_a01, 28).
vypil(290, default_a06, 67).
vypil(291, default_a07, 84).
vypil(292, default_a05, 38).
vypil(293, default_a06, 45).
vypil(294, default_a07, 38).
vypil(295, default_a01, 22).
vypil(296, default_a05, 69).
vypil(297, default_a06, 38).
vypil(298, default_a06, 95).
vypil(299, default_a07, 8).
vypil(300, default_a11, 81).
vypil(301, default_a02, 82).
vypil(302, default_a11, 37).
vypil(303, default_a12, 70).
vypil(304, default_a05, 45).
vypil(305, default_a08, 17).
vypil(306, default_a12, 3).
vypil(307, default_a07, 65).
vypil(308, default_a08, 62).
vypil(309, default_a12, 38).
vypil(310, default_a02, 98).
vypil(311, default_a05, 78).
vypil(312, default_a12, 80).
vypil(313, default_a05, 54).
vypil(314, default_a08, 56).
vypil(315, default_a11, 90).
vypil(316, default_a01, 25).
vypil(317, default_a07, 89).
vypil(318, default_a09, 69).
vypil(319, default_a07, 73).
vypil(320, default_a08, 67).
vypil(321, default_a09, 30).
vypil(322, default_a01, 39).
vypil(323, default_a07, 12).
vypil(324, default_a08, 18).
vypil(325, default_a03, 4).
vypil(326, default_a07, 56).
vypil(327, default_a08, 14).
vypil(328, default_a01, 62).
vypil(329, default_a07, 26).
vypil(330, default_a08, 6).
vypil(331, default_a02, 41).
vypil(332, default_a03, 5).
vypil(333, default_a10, 56).
vypil(334, default_a02, 77).
vypil(335, default_a07, 32).
vypil(336, default_a10, 50).
vypil(337, default_a02, 90).
vypil(338, default_a03, 24).
vypil(339, default_a06, 21).
vypil(340, default_a03, 46).
vypil(341, default_a07, 94).
vypil(342, default_a10, 29).
vypil(343, default_a01, 81).
vypil(344, default_a02, 56).
vypil(345, default_a06, 94).
vypil(346, default_a02, 99).
vypil(347, default_a03, 54).
vypil(348, default_a12, 75).
vypil(349, default_a01, 87).
vypil(350, default_a03, 77).
vypil(351, default_a06, 44).
vypil(352, default_a01, 72).
vypil(353, default_a06, 82).
vypil(354, default_a12, 18).
vypil(355, default_a01, 5).
vypil(356, default_a02, 100).
vypil(357, default_a08, 10).
vypil(358, default_a02, 99).
vypil(359, default_a06, 90).
vypil(360, default_a08, 82).
vypil(361, default_a01, 98).
vypil(362, default_a08, 52).
vypil(363, default_a09, 82).
vypil(364, default_a01, 33).
vypil(365, default_a03, 46).
vypil(366, default_a08, 79).
vypil(367, default_a01, 36).
vypil(368, default_a03, 57).
vypil(369, default_a10, 6).
vypil(370, default_a01, 7).
vypil(371, default_a09, 84).
vypil(372, default_a10, 91).
vypil(373, default_a01, 72).
vypil(374, default_a09, 1).
vypil(375, default_a11, 66).
vypil(376, default_a01, 64).
vypil(377, default_a04, 69).
vypil(378, default_a09, 46).
vypil(379, default_a01, 10).
vypil(380, default_a09, 96).
vypil(381, default_a11, 25).
vypil(382, default_a04, 79).
vypil(383, default_a07, 60).
vypil(384, default_a09, 9).
vypil(385, default_a01, 80).
vypil(386, default_a06, 32).
vypil(387, default_a09, 49).
vypil(388, default_a01, 41).
vypil(389, default_a07, 91).
vypil(390, default_a11, 64).
vypil(391, default_a03, 77).
vypil(392, default_a04, 21).
vypil(393, default_a06, 20).
vypil(394, default_a07, 66).
vypil(395, default_a10, 6).
vypil(396, default_a11, 17).
vypil(397, default_a04, 77).
vypil(398, default_a06, 50).
vypil(399, default_a11, 81).
vypil(400, default_a06, 56).
vypil(401, default_a10, 16).
vypil(402, default_a11, 100).
vypil(403, default_a06, 96).
vypil(404, default_a07, 6).
vypil(405, default_a11, 99).
vypil(406, default_a04, 98).
vypil(407, default_a08, 40).
vypil(408, default_a12, 6).
vypil(409, default_a02, 12).
vypil(410, default_a04, 55).
vypil(411, default_a09, 85).
vypil(412, default_a04, 8).
vypil(413, default_a09, 39).
vypil(414, default_a10, 46).
vypil(415, default_a09, 77).
vypil(416, default_a10, 54).
vypil(417, default_a12, 76).
vypil(418, default_a04, 8).
vypil(419, default_a09, 42).
vypil(420, default_a10, 85).
vypil(421, default_a01, 52).
vypil(422, default_a02, 70).
vypil(423, default_a11, 46).
vypil(424, default_a01, 88).
vypil(425, default_a08, 29).
vypil(426, default_a09, 21).
vypil(427, default_a01, 98).
vypil(428, default_a09, 88).
vypil(429, default_a10, 58).
vypil(430, default_a02, 6).
vypil(431, default_a09, 44).
vypil(432, default_a10, 3).
vypil(433, default_a01, 28).
vypil(434, default_a08, 90).
vypil(435, default_a10, 15).
vypil(436, default_a01, 47).
vypil(437, default_a07, 95).
vypil(438, default_a11, 93).
vypil(439, default_a04, 28).
vypil(440, default_a06, 56).
vypil(441, default_a07, 65).
vypil(442, default_a04, 29).
vypil(443, default_a05, 69).
vypil(444, default_a07, 57).
vypil(445, default_a01, 1).
vypil(446, default_a04, 91).
vypil(447, default_a06, 43).
vypil(448, default_a01, 53).
vypil(449, default_a06, 7).
vypil(450, default_a07, 15).
vypil(451, default_a05, 24).
vypil(452, default_a08, 16).
vypil(453, default_a11, 63).
vypil(454, default_a02, 78).
vypil(455, default_a05, 63).
vypil(456, default_a12, 57).
vypil(457, default_a07, 59).
vypil(458, default_a11, 67).
vypil(459, default_a12, 50).
vypil(460, default_a07, 68).
vypil(461, default_a08, 88).
vypil(462, default_a12, 62).
vypil(463, default_a05, 51).
vypil(464, default_a08, 85).
vypil(465, default_a12, 70).
vypil(466, default_a05, 25).
vypil(467, default_a11, 98).
vypil(468, default_a12, 83).
vypil(469, default_a01, 75).
vypil(470, default_a06, 20).
vypil(471, default_a09, 23).
vypil(472, default_a01, 99).
vypil(473, default_a03, 78).
vypil(474, default_a08, 50).
vypil(475, default_a01, 69).
vypil(476, default_a03, 76).
vypil(477, default_a07, 49).
vypil(478, default_a01, 49).
vypil(479, default_a07, 99).
vypil(480, default_a09, 32).
vypil(481, default_a01, 48).
vypil(482, default_a07, 81).
vypil(483, default_a08, 5).
vypil(484, default_a01, 53).
vypil(485, default_a03, 63).
vypil(486, default_a07, 20).
vypil(487, default_a01, 10).
vypil(488, default_a02, 20).
vypil(489, default_a07, 40).
vypil(490, default_a02, 25).
vypil(491, default_a06, 75).
vypil(492, default_a07, 22).
vypil(493, default_a01, 3).
vypil(494, default_a03, 92).
vypil(495, default_a07, 80).
vypil(496, default_a01, 86).
vypil(497, default_a02, 9).
vypil(498, default_a07, 42).
vypil(499, default_a01, 22).
vypil(500, default_a02, 14).
vypil(501, default_a10, 11).
vypil(502, default_a03, 64).
vypil(503, default_a06, 93).
vypil(504, default_a07, 35).
vypil(505, default_a02, 20).
vypil(506, default_a06, 94).
vypil(507, default_a12, 93).
vypil(508, default_a01, 68).
vypil(509, default_a06, 52).
vypil(510, default_a08, 8).
vypil(511, default_a02, 65).
vypil(512, default_a03, 5).
vypil(513, default_a06, 19).
vypil(514, default_a01, 62).
vypil(515, default_a06, 97).
vypil(516, default_a08, 7).
vypil(517, default_a01, 31).
vypil(518, default_a08, 86).
vypil(519, default_a12, 98).
vypil(520, default_a01, 4).
vypil(521, default_a08, 40).
vypil(522, default_a12, 78).
vypil(523, default_a09, 43).
vypil(524, default_a10, 66).
vypil(525, default_a11, 90).
vypil(526, default_a01, 63).
vypil(527, default_a03, 88).
vypil(528, default_a10, 59).
vypil(529, default_a03, 84).
vypil(530, default_a10, 18).
vypil(531, default_a11, 91).
vypil(532, default_a01, 9).
vypil(533, default_a09, 36).
vypil(534, default_a10, 54).
vypil(535, default_a08, 36).
vypil(536, default_a10, 61).
vypil(537, default_a11, 82).
vypil(538, default_a03, 56).
vypil(539, default_a08, 97).
vypil(540, default_a10, 7).
vypil(541, default_a04, 82).
vypil(542, default_a06, 82).
vypil(543, default_a07, 67).
vypil(544, default_a01, 63).
vypil(545, default_a06, 53).
vypil(546, default_a07, 96).
vypil(547, default_a04, 24).
vypil(548, default_a07, 43).
vypil(549, default_a09, 47).
vypil(550, default_a04, 42).
vypil(551, default_a06, 63).
vypil(552, default_a07, 55).
vypil(553, default_a04, 100).
vypil(554, default_a06, 75).
vypil(555, default_a09, 81).
vypil(556, default_a07, 30).
vypil(557, default_a09, 50).
vypil(558, default_a11, 55).
vypil(559, default_a03, 55).
vypil(560, default_a06, 11).
vypil(561, default_a10, 41).
vypil(562, default_a06, 30).
vypil(563, default_a10, 90).
vypil(564, default_a11, 5).
vypil(565, default_a07, 3).
vypil(566, default_a10, 87).
vypil(567, default_a11, 39).
vypil(568, default_a04, 4).
vypil(569, default_a06, 11).
vypil(570, default_a07, 35).
vypil(571, default_a06, 27).
vypil(572, default_a10, 81).
vypil(573, default_a11, 35).
vypil(574, default_a03, 22).
vypil(575, default_a07, 58).
vypil(576, default_a10, 16).
vypil(577, default_a08, 99).
vypil(578, default_a10, 46).
vypil(579, default_a12, 52).
vypil(580, default_a02, 30).
vypil(581, default_a04, 13).
vypil(582, default_a09, 57).
vypil(583, default_a04, 76).
vypil(584, default_a08, 59).
vypil(585, default_a10, 62).
vypil(586, default_a04, 22).
vypil(587, default_a10, 66).
vypil(588, default_a12, 92).
vypil(589, default_a02, 52).
vypil(590, default_a04, 1).
vypil(591, default_a09, 15).
vypil(592, default_a02, 49).
vypil(593, default_a04, 24).
vypil(594, default_a12, 78).
vypil(595, default_a01, 71).
vypil(596, default_a02, 84).
vypil(597, default_a09, 11).
vypil(598, default_a02, 69).
vypil(599, default_a10, 78).
vypil(600, default_a11, 42).
vypil(601, default_a02, 38).
vypil(602, default_a08, 89).
vypil(603, default_a10, 7).
vypil(604, default_a02, 100).
vypil(605, default_a08, 76).
vypil(606, default_a09, 11).
vypil(607, default_a02, 7).
vypil(608, default_a08, 90).
vypil(609, default_a11, 38).
vypil(610, default_a02, 95).
vypil(611, default_a09, 42).
vypil(612, default_a11, 77).
vypil(613, default_a04, 2).
vypil(614, default_a06, 52).
vypil(615, default_a11, 83).
vypil(616, default_a01, 26).
vypil(617, default_a06, 74).
vypil(618, default_a07, 91).
vypil(619, default_a01, 62).
vypil(620, default_a04, 3).
vypil(621, default_a07, 45).
vypil(622, default_a01, 47).
vypil(623, default_a06, 86).
vypil(624, default_a11, 81).
vypil(625, default_a01, 58).
vypil(626, default_a05, 9).
vypil(627, default_a11, 45).
vypil(628, default_a05, 60).
vypil(629, default_a07, 61).
vypil(630, default_a11, 12).
vypil(631, default_a05, 67).
vypil(632, default_a08, 43).
vypil(633, default_a11, 98).
vypil(634, default_a05, 72).
vypil(635, default_a07, 50).
vypil(636, default_a08, 45).
vypil(637, default_a05, 74).
vypil(638, default_a07, 2).
vypil(639, default_a08, 73).
vypil(640, default_a02, 50).
vypil(641, default_a05, 56).
vypil(642, default_a11, 37).
vypil(643, default_a02, 52).
vypil(644, default_a05, 26).
vypil(645, default_a07, 70).
vypil(646, default_a02, 4).
vypil(647, default_a08, 77).
vypil(648, default_a11, 75).
vypil(649, default_a02, 72).
vypil(650, default_a08, 54).
vypil(651, default_a11, 49).
vypil(652, default_a01, 55).
vypil(653, default_a03, 89).
vypil(654, default_a06, 83).
vypil(655, default_a01, 87).
vypil(656, default_a03, 70).
vypil(657, default_a09, 51).
vypil(658, default_a01, 37).
vypil(659, default_a03, 34).
vypil(660, default_a07, 30).
vypil(661, default_a01, 38).
vypil(662, default_a06, 89).
vypil(663, default_a07, 97).
vypil(664, default_a06, 23).
vypil(665, default_a07, 16).
vypil(666, default_a09, 5).
vypil(667, default_a06, 90).
vypil(668, default_a07, 41).
vypil(669, default_a08, 34).
vypil(670, default_a01, 89).
vypil(671, default_a06, 77).
vypil(672, default_a08, 64).
vypil(673, default_a01, 45).
vypil(674, default_a03, 59).
vypil(675, default_a06, 47).
vypil(676, default_a01, 83).
vypil(677, default_a03, 56).
vypil(678, default_a10, 29).
vypil(679, default_a02, 23).
vypil(680, default_a06, 31).
vypil(681, default_a07, 65).
vypil(682, default_a01, 65).
vypil(683, default_a03, 99).
vypil(684, default_a10, 16).
vypil(685, default_a03, 45).
vypil(686, default_a07, 77).
vypil(687, default_a10, 22).
vypil(688, default_a01, 32).
vypil(689, default_a07, 38).
vypil(690, default_a10, 19).
vypil(691, default_a03, 66).
vypil(692, default_a06, 52).
vypil(693, default_a10, 85).
vypil(694, default_a02, 92).
vypil(695, default_a06, 36).
vypil(696, default_a12, 44).
vypil(697, default_a01, 32).
vypil(698, default_a03, 75).
vypil(699, default_a08, 27).
vypil(700, default_a01, 78).
vypil(701, default_a02, 30).
vypil(702, default_a12, 2).
vypil(703, default_a01, 25).
vypil(704, default_a03, 34).
vypil(705, default_a08, 85).
vypil(706, default_a02, 4).
vypil(707, default_a03, 43).
vypil(708, default_a08, 17).
vypil(709, default_a06, 97).
vypil(710, default_a08, 54).
vypil(711, default_a12, 73).
vypil(712, default_a02, 45).
vypil(713, default_a03, 40).
vypil(714, default_a12, 52).
vypil(715, default_a03, 17).
vypil(716, default_a08, 83).
vypil(717, default_a10, 49).
vypil(718, default_a03, 2).
vypil(719, default_a08, 27).
vypil(720, default_a09, 29).
vypil(721, default_a01, 19).
vypil(722, default_a03, 56).
vypil(723, default_a10, 88).
vypil(724, default_a01, 9).
vypil(725, default_a08, 88).
vypil(726, default_a11, 36).
vypil(727, default_a01, 73).
vypil(728, default_a03, 15).
vypil(729, default_a08, 57).
vypil(730, default_a03, 46).
vypil(731, default_a10, 67).
vypil(732, default_a11, 72).
vypil(733, default_a03, 58).
vypil(734, default_a08, 9).
vypil(735, default_a10, 53).
vypil(736, default_a01, 24).
vypil(737, default_a09, 10).
vypil(738, default_a11, 57).
vypil(739, default_a01, 32).
vypil(740, default_a06, 67).
vypil(741, default_a07, 18).
vypil(742, default_a01, 7).
vypil(743, default_a07, 80).
vypil(744, default_a11, 40).
vypil(745, default_a04, 90).
vypil(746, default_a07, 10).
vypil(747, default_a09, 68).
vypil(748, default_a01, 82).
vypil(749, default_a07, 13).
vypil(750, default_a11, 10).
vypil(751, default_a01, 19).
vypil(752, default_a04, 86).
vypil(753, default_a11, 96).
vypil(754, default_a01, 36).
vypil(755, default_a04, 97).
vypil(756, default_a07, 65).
vypil(757, default_a04, 94).
vypil(758, default_a06, 72).
vypil(759, default_a07, 21).
vypil(760, default_a06, 14).
vypil(761, default_a07, 60).
vypil(762, default_a11, 47).
vypil(763, default_a03, 32).
vypil(764, default_a06, 69).
vypil(765, default_a10, 78).
vypil(766, default_a03, 52).
vypil(767, default_a06, 100).
vypil(768, default_a10, 54).
vypil(769, default_a03, 65).
vypil(770, default_a06, 57).
vypil(771, default_a07, 80).
vypil(772, default_a03, 14).
vypil(773, default_a04, 5).
vypil(774, default_a07, 16).
vypil(775, default_a04, 90).
vypil(776, default_a07, 11).
vypil(777, default_a10, 78).
vypil(778, default_a02, 65).
vypil(779, default_a09, 67).
vypil(780, default_a12, 44).
vypil(781, default_a02, 73).
vypil(782, default_a09, 4).
vypil(783, default_a12, 40).
vypil(784, default_a02, 3).
vypil(785, default_a10, 20).
vypil(786, default_a12, 15).
vypil(787, default_a02, 42).
vypil(788, default_a10, 64).
vypil(789, default_a12, 63).
vypil(790, default_a09, 13).
vypil(791, default_a10, 35).
vypil(792, default_a12, 57).
vypil(793, default_a02, 47).
vypil(794, default_a04, 34).
vypil(795, default_a08, 58).
vypil(796, default_a02, 86).
vypil(797, default_a09, 55).
vypil(798, default_a10, 22).
vypil(799, default_a02, 79).
vypil(800, default_a10, 35).
vypil(801, default_a11, 6).
vypil(802, default_a08, 53).
vypil(803, default_a09, 23).
vypil(804, default_a11, 46).
vypil(805, default_a01, 43).
vypil(806, default_a02, 60).
vypil(807, default_a10, 22).
vypil(808, default_a02, 16).
vypil(809, default_a08, 25).
vypil(810, default_a09, 87).
vypil(811, default_a02, 66).
vypil(812, default_a09, 89).
vypil(813, default_a10, 91).
vypil(814, default_a02, 87).
vypil(815, default_a09, 50).
vypil(816, default_a11, 98).
vypil(817, default_a02, 22).
vypil(818, default_a08, 93).
vypil(819, default_a10, 92).
vypil(820, default_a05, 65).
vypil(821, default_a07, 2).
vypil(822, default_a11, 6).
vypil(823, default_a04, 30).
vypil(824, default_a06, 83).
vypil(825, default_a07, 38).
vypil(826, default_a04, 18).
vypil(827, default_a06, 71).
vypil(828, default_a11, 74).
vypil(829, default_a01, 80).
vypil(830, default_a06, 55).
vypil(831, default_a11, 80).
vypil(832, default_a01, 57).
vypil(833, default_a04, 51).
vypil(834, default_a11, 95).
vypil(835, default_a05, 6).
vypil(836, default_a07, 76).
vypil(837, default_a11, 38).
vypil(838, default_a04, 8).
vypil(839, default_a06, 11).
vypil(840, default_a07, 61).
vypil(841, default_a05, 43).
vypil(842, default_a05, 94).
vypil(843, default_a05, 16).
vypil(844, default_a05, 57).
vypil(845, default_a05, 84).
vypil(846, default_a05, 13).
vypil(847, default_a05, 86).
vypil(848, default_a05, 14).
vypil(849, default_a05, 47).
vypil(850, default_a11, 74).
vypil(851, default_a12, 91).
vypil(852, default_a02, 93).
vypil(853, default_a07, 93).
vypil(854, default_a08, 66).
vypil(855, default_a05, 90).
vypil(856, default_a08, 85).
vypil(857, default_a12, 67).
vypil(858, default_a05, 81).
vypil(859, default_a08, 49).
vypil(860, default_a12, 58).
vypil(861, default_a02, 81).
vypil(862, default_a05, 12).
vypil(863, default_a07, 59).
vypil(864, default_a05, 99).
vypil(865, default_a07, 56).
vypil(866, default_a12, 81).
vypil(867, default_a07, 64).
vypil(868, default_a11, 11).
vypil(869, default_a12, 81).
vypil(870, default_a05, 68).
vypil(871, default_a11, 49).
vypil(872, default_a12, 43).
vypil(873, default_a05, 74).
vypil(874, default_a08, 4).
vypil(875, default_a12, 10).
vypil(876, default_a06, 1).
vypil(877, default_a07, 36).
vypil(878, default_a08, 16).
vypil(879, default_a03, 75).
vypil(880, default_a06, 47).
vypil(881, default_a08, 85).
vypil(882, default_a01, 95).
vypil(883, default_a07, 17).
vypil(884, default_a08, 96).
vypil(885, default_a03, 11).
vypil(886, default_a06, 14).
vypil(887, default_a07, 54).
vypil(888, default_a01, 98).
vypil(889, default_a06, 46).
vypil(890, default_a08, 17).
vypil(891, default_a01, 1).
vypil(892, default_a03, 38).
vypil(893, default_a09, 63).
vypil(894, default_a06, 73).
vypil(895, default_a07, 30).
vypil(896, default_a08, 7).
vypil(897, default_a01, 76).
vypil(898, default_a06, 46).
vypil(899, default_a08, 95).
vypil(900, default_a06, 45).
vypil(901, default_a08, 2).
vypil(902, default_a09, 58).
vypil(903, default_a06, 28).
vypil(904, default_a07, 23).
vypil(905, default_a10, 24).
vypil(906, default_a02, 36).
vypil(907, default_a03, 75).
vypil(908, default_a10, 25).
vypil(909, default_a01, 35).
vypil(910, default_a02, 86).
vypil(911, default_a03, 44).
vypil(912, default_a01, 95).
vypil(913, default_a07, 66).
vypil(914, default_a10, 44).
vypil(915, default_a01, 88).
vypil(916, default_a02, 73).
vypil(917, default_a03, 10).
vypil(918, default_a01, 4).
vypil(919, default_a02, 89).
vypil(920, default_a07, 38).
vypil(921, default_a01, 92).
vypil(922, default_a07, 6).
vypil(923, default_a10, 49).
vypil(924, default_a03, 32).
vypil(925, default_a06, 49).
vypil(926, default_a10, 29).
vypil(927, default_a01, 95).
vypil(928, default_a06, 67).
vypil(929, default_a10, 41).
vypil(930, default_a02, 96).
vypil(931, default_a06, 5).
vypil(932, default_a08, 60).
vypil(933, default_a02, 58).
vypil(934, default_a03, 48).
vypil(935, default_a08, 19).
vypil(936, default_a01, 27).
vypil(937, default_a08, 94).
vypil(938, default_a12, 71).
vypil(939, default_a01, 69).
vypil(940, default_a08, 44).
vypil(941, default_a12, 71).
vypil(942, default_a01, 24).
vypil(943, default_a02, 26).
vypil(944, default_a06, 98).
vypil(945, default_a01, 61).
vypil(946, default_a03, 96).
vypil(947, default_a12, 52).
vypil(948, default_a03, 5).
vypil(949, default_a08, 25).
vypil(950, default_a12, 89).
vypil(951, default_a02, 42).
vypil(952, default_a06, 9).
vypil(953, default_a12, 41).
vypil(954, default_a02, 12).
vypil(955, default_a06, 31).
vypil(956, default_a12, 17).
vypil(957, default_a01, 54).
vypil(958, default_a03, 12).
vypil(959, default_a11, 66).
vypil(960, default_a01, 92).
vypil(961, default_a08, 64).
vypil(962, default_a10, 79).
vypil(963, default_a01, 14).
vypil(964, default_a08, 3).
vypil(965, default_a11, 16).
vypil(966, default_a03, 30).
vypil(967, default_a08, 21).
vypil(968, default_a09, 5).
vypil(969, default_a01, 85).
vypil(970, default_a03, 24).
vypil(971, default_a08, 2).
vypil(972, default_a01, 98).
vypil(973, default_a08, 56).
vypil(974, default_a09, 31).
vypil(975, default_a01, 82).
vypil(976, default_a09, 86).
vypil(977, default_a11, 37).
vypil(978, default_a08, 95).
vypil(979, default_a09, 33).
vypil(980, default_a11, 94).
vypil(981, default_a01, 85).
vypil(982, default_a03, 6).
vypil(983, default_a08, 74).
vypil(984, default_a01, 93).
vypil(985, default_a04, 24).
vypil(986, default_a06, 2).
vypil(987, default_a04, 77).
vypil(988, default_a06, 30).
vypil(989, default_a09, 71).
vypil(990, default_a01, 75).
vypil(991, default_a09, 74).
vypil(992, default_a11, 45).
vypil(993, default_a01, 57).
vypil(994, default_a09, 17).
vypil(995, default_a11, 96).
vypil(996, default_a01, 56).
vypil(997, default_a04, 64).
vypil(998, default_a09, 31).
vypil(999, default_a07, 18).
vypil(1000, default_a09, 30).
vypil(1001, default_a11, 20).
vypil(1002, default_a04, 62).
vypil(1003, default_a06, 35).
vypil(1004, default_a07, 32).
vypil(1005, default_a04, 6).
vypil(1006, default_a07, 87).
vypil(1007, default_a11, 3).
vypil(1008, default_a01, 25).
vypil(1009, default_a09, 51).
vypil(1010, default_a11, 6).
vypil(1011, default_a04, 53).
vypil(1012, default_a06, 21).
vypil(1013, default_a11, 90).
vypil(1014, default_a06, 48).
vypil(1015, default_a07, 53).
vypil(1016, default_a10, 93).
vypil(1017, default_a07, 43).
vypil(1018, default_a10, 4).
vypil(1019, default_a11, 13).
vypil(1020, default_a03, 43).
vypil(1021, default_a04, 24).
vypil(1022, default_a10, 62).
vypil(1023, default_a03, 1).
vypil(1024, default_a06, 86).
vypil(1025, default_a07, 19).
vypil(1026, default_a03, 83).
vypil(1027, default_a04, 13).
vypil(1028, default_a06, 20).
vypil(1029, default_a06, 70).
vypil(1030, default_a07, 63).
vypil(1031, default_a10, 12).
vypil(1032, default_a04, 94).
vypil(1033, default_a06, 66).
vypil(1034, default_a07, 28).
vypil(1035, default_a04, 9).
vypil(1036, default_a06, 25).
vypil(1037, default_a07, 51).
vypil(1038, default_a08, 28).
vypil(1039, default_a09, 47).
vypil(1040, default_a10, 41).
vypil(1041, default_a02, 79).
vypil(1042, default_a08, 78).
vypil(1043, default_a12, 81).
vypil(1044, default_a02, 91).
vypil(1045, default_a04, 91).
vypil(1046, default_a09, 21).
vypil(1047, default_a02, 98).
vypil(1048, default_a08, 19).
vypil(1049, default_a09, 94).
vypil(1050, default_a04, 29).
vypil(1051, default_a08, 14).
vypil(1052, default_a09, 89).
vypil(1053, default_a02, 67).
vypil(1054, default_a10, 81).
vypil(1055, default_a12, 28).
vypil(1056, default_a02, 58).
vypil(1057, default_a04, 20).
vypil(1058, default_a09, 67).
vypil(1059, default_a04, 3).
vypil(1060, default_a08, 12).
vypil(1061, default_a12, 47).
vypil(1062, default_a02, 62).
vypil(1063, default_a04, 79).
vypil(1064, default_a08, 39).
vypil(1065, default_a01, 38).
vypil(1066, default_a08, 17).
vypil(1067, default_a09, 9).
vypil(1068, default_a01, 57).
vypil(1069, default_a02, 97).
vypil(1070, default_a11, 95).
vypil(1071, default_a02, 60).
vypil(1072, default_a08, 88).
vypil(1073, default_a09, 24).
vypil(1074, default_a01, 97).
vypil(1075, default_a02, 46).
vypil(1076, default_a09, 46).
vypil(1077, default_a01, 88).
vypil(1078, default_a09, 73).
vypil(1079, default_a11, 32).
vypil(1080, default_a01, 34).
vypil(1081, default_a09, 7).
vypil(1082, default_a11, 53).
vypil(1083, default_a08, 92).
vypil(1084, default_a10, 2).
vypil(1085, default_a11, 36).
vypil(1086, default_a08, 83).
vypil(1087, default_a09, 30).
vypil(1088, default_a11, 65).
vypil(1089, default_a01, 10).
vypil(1090, default_a02, 43).
vypil(1091, default_a08, 36).
vypil(1092, default_a01, 76).
vypil(1093, default_a06, 19).
vypil(1094, default_a11, 72).
vypil(1095, default_a04, 31).
vypil(1096, default_a05, 52).
vypil(1097, default_a11, 53).
vypil(1098, default_a01, 91).
vypil(1099, default_a05, 96).
vypil(1100, default_a11, 77).
vypil(1101, default_a04, 14).
vypil(1102, default_a05, 59).
vypil(1103, default_a07, 86).
vypil(1104, default_a04, 53).
vypil(1105, default_a06, 64).
vypil(1106, default_a07, 82).
vypil(1107, default_a01, 70).
vypil(1108, default_a06, 13).
vypil(1109, default_a07, 44).
vypil(1110, default_a01, 36).
vypil(1111, default_a06, 5).
vypil(1112, default_a07, 67).
vypil(1113, default_a05, 17).
vypil(1114, default_a06, 21).
vypil(1115, default_a11, 49).
vypil(1116, default_a01, 72).
vypil(1117, default_a04, 54).
vypil(1118, default_a07, 86).
vypil(1119, default_a02, 67).
vypil(1120, default_a05, 81).
vypil(1121, default_a12, 40).
vypil(1122, default_a02, 49).
vypil(1123, default_a05, 74).
vypil(1124, default_a07, 55).
vypil(1125, default_a05, 12).
vypil(1126, default_a11, 17).
vypil(1127, default_a12, 22).
vypil(1128, default_a02, 80).
vypil(1129, default_a08, 40).
vypil(1130, default_a11, 47).
vypil(1131, default_a02, 72).
vypil(1132, default_a05, 36).
vypil(1133, default_a11, 20).
vypil(1134, default_a07, 54).
vypil(1135, default_a08, 59).
vypil(1136, default_a11, 31).
vypil(1137, default_a05, 19).
vypil(1138, default_a07, 73).
vypil(1139, default_a11, 26).
vypil(1140, default_a02, 64).
vypil(1141, default_a07, 89).
vypil(1142, default_a11, 26).
vypil(1143, default_a02, 80).
vypil(1144, default_a07, 29).
vypil(1145, default_a11, 72).
vypil(1146, default_a07, 19).
vypil(1147, default_a08, 47).
vypil(1148, default_a11, 80).
vypil(1149, default_a03, 58).
vypil(1150, default_a06, 35).
vypil(1151, default_a09, 54).
vypil(1152, default_a03, 56).
vypil(1153, default_a07, 88).
vypil(1154, default_a08, 37).
vypil(1155, default_a01, 31).
vypil(1156, default_a03, 24).
vypil(1157, default_a06, 33).
vypil(1158, default_a03, 53).
vypil(1159, default_a06, 83).
vypil(1160, default_a08, 29).
vypil(1161, default_a06, 45).
vypil(1162, default_a07, 41).
vypil(1163, default_a09, 41).
vypil(1164, default_a01, 2).
vypil(1165, default_a06, 53).
vypil(1166, default_a07, 38).
vypil(1167, default_a01, 8).
vypil(1168, default_a08, 46).
vypil(1169, default_a09, 39).
vypil(1170, default_a07, 67).
vypil(1171, default_a08, 49).
vypil(1172, default_a09, 90).
vypil(1173, default_a01, 24).
vypil(1174, default_a07, 34).
vypil(1175, default_a09, 40).
vypil(1176, default_a03, 49).
vypil(1177, default_a06, 47).
vypil(1178, default_a09, 22).
vypil(1179, default_a01, 26).
vypil(1180, default_a03, 27).
vypil(1181, default_a10, 4).
vypil(1182, default_a01, 49).
vypil(1183, default_a06, 6).
vypil(1184, default_a10, 48).
vypil(1185, default_a02, 87).
vypil(1186, default_a06, 29).
vypil(1187, default_a10, 61).
vypil(1188, default_a01, 15).
vypil(1189, default_a03, 61).
vypil(1190, default_a06, 26).
vypil(1191, default_a01, 89).
vypil(1192, default_a03, 77).
vypil(1193, default_a10, 69).
vypil(1194, default_a03, 85).
vypil(1195, default_a06, 19).
vypil(1196, default_a07, 49).
vypil(1197, default_a02, 34).
vypil(1198, default_a06, 65).
vypil(1199, default_a10, 37).
vypil(1200, default_a01, 96).
vypil(1201, default_a06, 56).
vypil(1202, default_a10, 30).
vypil(1203, default_a01, 98).
vypil(1204, default_a03, 45).
vypil(1205, default_a10, 84).
vypil(1206, default_a02, 79).
vypil(1207, default_a06, 27).
vypil(1208, default_a07, 86).
vypil(1209, default_a01, 4).
vypil(1210, default_a02, 78).
vypil(1211, default_a08, 49).
vypil(1212, default_a01, 11).
vypil(1213, default_a06, 13).
vypil(1214, default_a12, 54).
vypil(1215, default_a02, 50).
vypil(1216, default_a06, 59).
vypil(1217, default_a12, 67).
vypil(1218, default_a02, 25).
vypil(1219, default_a03, 79).
vypil(1220, default_a08, 53).
vypil(1221, default_a01, 20).
vypil(1222, default_a08, 91).
vypil(1223, default_a12, 35).
vypil(1224, default_a03, 91).
vypil(1225, default_a08, 41).
vypil(1226, default_a12, 56).
vypil(1227, default_a02, 92).
vypil(1228, default_a06, 94).
vypil(1229, default_a08, 66).
vypil(1230, default_a01, 67).
vypil(1231, default_a02, 20).
vypil(1232, default_a03, 13).
vypil(1233, default_a02, 12).
vypil(1234, default_a03, 51).
vypil(1235, default_a06, 15).
vypil(1236, default_a01, 28).
vypil(1237, default_a03, 26).
vypil(1238, default_a08, 42).
vypil(1239, default_a03, 18).
vypil(1240, default_a08, 67).
vypil(1241, default_a10, 55).
vypil(1242, default_a03, 48).
vypil(1243, default_a08, 6).
vypil(1244, default_a11, 60).
vypil(1245, default_a03, 99).
vypil(1246, default_a08, 86).
vypil(1247, default_a11, 26).
vypil(1248, default_a01, 55).
vypil(1249, default_a09, 51).
vypil(1250, default_a10, 22).
vypil(1251, default_a08, 52).
vypil(1252, default_a09, 60).
vypil(1253, default_a10, 92).
vypil(1254, default_a03, 37).
vypil(1255, default_a08, 4).
vypil(1256, default_a09, 40).
vypil(1257, default_a01, 91).
vypil(1258, default_a09, 59).
vypil(1259, default_a10, 44).
vypil(1260, default_a01, 10).
vypil(1261, default_a08, 10).
vypil(1262, default_a11, 65).
vypil(1263, default_a03, 85).
vypil(1264, default_a10, 33).
vypil(1265, default_a11, 85).
vypil(1266, default_a09, 98).
vypil(1267, default_a10, 12).
vypil(1268, default_a11, 91).
vypil(1269, default_a06, 21).
vypil(1270, default_a07, 66).
vypil(1271, default_a09, 37).
vypil(1272, default_a04, 71).
vypil(1273, default_a07, 34).
vypil(1274, default_a09, 2).
vypil(1275, default_a01, 89).
vypil(1276, default_a06, 92).
vypil(1277, default_a09, 38).
vypil(1278, default_a01, 21).
vypil(1279, default_a06, 99).
vypil(1280, default_a07, 3).
vypil(1281, default_a01, 8).
vypil(1282, default_a07, 18).
vypil(1283, default_a11, 76).
vypil(1284, default_a04, 3).
vypil(1285, default_a07, 99).
vypil(1286, default_a11, 15).
vypil(1287, default_a01, 92).
vypil(1288, default_a06, 11).
vypil(1289, default_a11, 24).
vypil(1290, default_a01, 31).
vypil(1291, default_a07, 33).
vypil(1292, default_a11, 17).
vypil(1293, default_a04, 34).
vypil(1294, default_a07, 72).
vypil(1295, default_a11, 52).
vypil(1296, default_a01, 72).
vypil(1297, default_a06, 56).
vypil(1298, default_a11, 89).
vypil(1299, default_a06, 52).
vypil(1300, default_a07, 13).
vypil(1301, default_a11, 41).
vypil(1302, default_a04, 10).
vypil(1303, default_a06, 95).
vypil(1304, default_a07, 1).
vypil(1305, default_a03, 19).
vypil(1306, default_a04, 10).
vypil(1307, default_a10, 17).
vypil(1308, default_a03, 62).
vypil(1309, default_a04, 33).
vypil(1310, default_a06, 5).
vypil(1311, default_a04, 10).
vypil(1312, default_a07, 42).
vypil(1313, default_a10, 38).
vypil(1314, default_a04, 70).
vypil(1315, default_a07, 82).
vypil(1316, default_a10, 94).
vypil(1317, default_a06, 74).
vypil(1318, default_a10, 39).
vypil(1319, default_a11, 83).
vypil(1320, default_a03, 33).
vypil(1321, default_a04, 99).
vypil(1322, default_a07, 81).
vypil(1323, default_a03, 55).
vypil(1324, default_a04, 34).
vypil(1325, default_a06, 39).
vypil(1326, default_a03, 85).
vypil(1327, default_a06, 49).
vypil(1328, default_a10, 1).
vypil(1329, default_a08, 19).
vypil(1330, default_a10, 37).
vypil(1331, default_a12, 28).
vypil(1332, default_a04, 9).
vypil(1333, default_a10, 70).
vypil(1334, default_a12, 88).
vypil(1335, default_a04, 21).
vypil(1336, default_a08, 17).
vypil(1337, default_a12, 19).
vypil(1338, default_a02, 66).
vypil(1339, default_a04, 85).
vypil(1340, default_a12, 4).
vypil(1341, default_a02, 11).
vypil(1342, default_a08, 65).
vypil(1343, default_a09, 16).
vypil(1344, default_a04, 56).
vypil(1345, default_a09, 97).
vypil(1346, default_a12, 81).
vypil(1347, default_a04, 64).
vypil(1348, default_a10, 63).
vypil(1349, default_a12, 17).
vypil(1350, default_a02, 17).
vypil(1351, default_a04, 86).
vypil(1352, default_a10, 52).
vypil(1353, default_a02, 85).
vypil(1354, default_a04, 61).
vypil(1355, default_a12, 3).
vypil(1356, default_a08, 88).
vypil(1357, default_a10, 48).
vypil(1358, default_a12, 92).
vypil(1359, default_a02, 85).
vypil(1360, default_a08, 28).
vypil(1361, default_a11, 65).
vypil(1362, default_a02, 94).
vypil(1363, default_a09, 49).
vypil(1364, default_a11, 58).
vypil(1365, default_a02, 57).
vypil(1366, default_a10, 2).
vypil(1367, default_a11, 34).
vypil(1368, default_a02, 70).
vypil(1369, default_a08, 63).
vypil(1370, default_a11, 22).
vypil(1371, default_a01, 17).
vypil(1372, default_a10, 11).
vypil(1373, default_a11, 39).
vypil(1374, default_a02, 76).
vypil(1375, default_a08, 80).
vypil(1376, default_a11, 64).
vypil(1377, default_a01, 81).
vypil(1378, default_a02, 23).
vypil(1379, default_a09, 30).
vypil(1380, default_a09, 84).
vypil(1381, default_a10, 74).
vypil(1382, default_a11, 71).
vypil(1383, default_a01, 29).
vypil(1384, default_a10, 42).
vypil(1385, default_a11, 79).
vypil(1386, default_a09, 96).
vypil(1387, default_a10, 30).
vypil(1388, default_a11, 83).
vypil(1389, default_a05, 55).
vypil(1390, default_a07, 7).
vypil(1391, default_a11, 19).
vypil(1392, default_a04, 10).
vypil(1393, default_a07, 39).
vypil(1394, default_a11, 2).
vypil(1395, default_a01, 52).
vypil(1396, default_a05, 71).
vypil(1397, default_a07, 87).
vypil(1398, default_a01, 71).
vypil(1399, default_a05, 88).
vypil(1400, default_a06, 91).
vypil(1401, default_a05, 51).
vypil(1402, default_a07, 28).
vypil(1403, default_a11, 6).
vypil(1404, default_a05, 88).
vypil(1405, default_a06, 19).
vypil(1406, default_a11, 22).
vypil(1407, default_a04, 28).
vypil(1408, default_a06, 66).
vypil(1409, default_a07, 50).
vypil(1410, default_a04, 73).
vypil(1411, default_a05, 46).
vypil(1412, default_a11, 18).
vypil(1413, default_a01, 90).
vypil(1414, default_a04, 35).
vypil(1415, default_a07, 87).
vypil(1416, default_a04, 45).
vypil(1417, default_a06, 58).
vypil(1418, default_a11, 4).
vypil(1419, default_a02, 3).
vypil(1420, default_a05, 67).
vypil(1421, default_a08, 19).
vypil(1422, default_a02, 37).
vypil(1423, default_a08, 50).
vypil(1424, default_a12, 97).
vypil(1425, default_a05, 88).
vypil(1426, default_a11, 73).
vypil(1427, default_a12, 69).
vypil(1428, default_a05, 62).
vypil(1429, default_a07, 43).
vypil(1430, default_a11, 49).
vypil(1431, default_a02, 48).
vypil(1432, default_a11, 96).
vypil(1433, default_a12, 39).
vypil(1434, default_a05, 20).
vypil(1435, default_a07, 94).
vypil(1436, default_a08, 88).
vypil(1437, default_a07, 24).
vypil(1438, default_a08, 90).
vypil(1439, default_a12, 30).
vypil(1440, default_a08, 98).
vypil(1441, default_a11, 98).
vypil(1442, default_a12, 29).
vypil(1443, default_a02, 72).
vypil(1444, default_a07, 92).
vypil(1445, default_a11, 95).
vypil(1446, default_a02, 65).
vypil(1447, default_a08, 24).
vypil(1448, default_a12, 91).
vypil(1449, default_a08, 6).
vypil(1450, default_a11, 14).
vypil(1451, default_a12, 33).
vypil(1452, default_a03, 36).
vypil(1453, default_a08, 1).
vypil(1454, default_a09, 40).
vypil(1455, default_a06, 51).
vypil(1456, default_a08, 49).
vypil(1457, default_a09, 66).
vypil(1458, default_a03, 2).
vypil(1459, default_a07, 83).
vypil(1460, default_a09, 49).
vypil(1461, default_a01, 4).
vypil(1462, default_a03, 93).
vypil(1463, default_a06, 70).
vypil(1464, default_a01, 61).
vypil(1465, default_a07, 53).
vypil(1466, default_a08, 97).
vypil(1467, default_a03, 53).
vypil(1468, default_a08, 39).
vypil(1469, default_a09, 36).
vypil(1470, default_a03, 37).
vypil(1471, default_a08, 81).
vypil(1472, default_a09, 12).
vypil(1473, default_a01, 56).
vypil(1474, default_a03, 55).
vypil(1475, default_a08, 73).
vypil(1476, default_a06, 63).
vypil(1477, default_a07, 28).
vypil(1478, default_a09, 31).
vypil(1479, default_a06, 5).
vypil(1480, default_a07, 9).
vypil(1481, default_a08, 52).
vypil(1482, default_a01, 64).
vypil(1483, default_a06, 49).
vypil(1484, default_a09, 85).
vypil(1485, default_a02, 3).
vypil(1486, default_a06, 77).
vypil(1487, default_a07, 62).
vypil(1488, default_a02, 80).
vypil(1489, default_a03, 70).
vypil(1490, default_a10, 68).
vypil(1491, default_a01, 76).
vypil(1492, default_a03, 55).
vypil(1493, default_a06, 70).
vypil(1494, default_a02, 56).
vypil(1495, default_a06, 22).
vypil(1496, default_a07, 18).
vypil(1497, default_a06, 33).
vypil(1498, default_a07, 18).
vypil(1499, default_a10, 38).
vypil(1500, default_a02, 62).
vypil(1501, default_a06, 32).
vypil(1502, default_a10, 46).
vypil(1503, default_a01, 68).
vypil(1504, default_a03, 87).
vypil(1505, default_a10, 29).
vypil(1506, default_a01, 58).
vypil(1507, default_a02, 10).
vypil(1508, default_a03, 52).
vypil(1509, default_a01, 15).
vypil(1510, default_a02, 50).
vypil(1511, default_a03, 12).
vypil(1512, default_a02, 3).
vypil(1513, default_a03, 17).
vypil(1514, default_a10, 6).
vypil(1515, default_a03, 14).
vypil(1516, default_a07, 97).
vypil(1517, default_a10, 70).
vypil(1518, default_a01, 59).
vypil(1519, default_a08, 6).
vypil(1520, default_a12, 34).
vypil(1521, default_a06, 91).
vypil(1522, default_a08, 20).
vypil(1523, default_a12, 66).
vypil(1524, default_a02, 55).
vypil(1525, default_a03, 85).
vypil(1526, default_a12, 97).
vypil(1527, default_a01, 88).
vypil(1528, default_a06, 99).
vypil(1529, default_a08, 35).
vypil(1530, default_a01, 17).
vypil(1531, default_a03, 9).
vypil(1532, default_a06, 72).
vypil(1533, default_a03, 93).
vypil(1534, default_a06, 48).
vypil(1535, default_a12, 49).
vypil(1536, default_a02, 33).
vypil(1537, default_a06, 100).
vypil(1538, default_a12, 51).
vypil(1539, default_a01, 28).
vypil(1540, default_a03, 17).
vypil(1541, default_a08, 21).
vypil(1542, default_a01, 80).
vypil(1543, default_a03, 55).
vypil(1544, default_a06, 82).
vypil(1545, default_a03, 63).
vypil(1546, default_a06, 91).
vypil(1547, default_a12, 9).
vypil(1548, default_a01, 3).
vypil(1549, default_a02, 17).
vypil(1550, default_a03, 17).
vypil(1551, default_a01, 92).
vypil(1552, default_a03, 82).
vypil(1553, default_a09, 66).
vypil(1554, default_a01, 16).
vypil(1555, default_a08, 15).
vypil(1556, default_a09, 88).
vypil(1557, default_a01, 78).
vypil(1558, default_a03, 63).
vypil(1559, default_a08, 15).
vypil(1560, default_a01, 62).
vypil(1561, default_a10, 89).
vypil(1562, default_a11, 97).
vypil(1563, default_a03, 98).
vypil(1564, default_a08, 80).
vypil(1565, default_a09, 4).
vypil(1566, default_a01, 26).
vypil(1567, default_a09, 67).
vypil(1568, default_a10, 91).
vypil(1569, default_a03, 62).
vypil(1570, default_a08, 68).
vypil(1571, default_a10, 10).
vypil(1572, default_a03, 75).
vypil(1573, default_a08, 7).
vypil(1574, default_a10, 84).
vypil(1575, default_a08, 31).
vypil(1576, default_a09, 59).
vypil(1577, default_a11, 90).
vypil(1578, default_a03, 2).
vypil(1579, default_a09, 36).
vypil(1580, default_a11, 17).
vypil(1581, default_a01, 27).
vypil(1582, default_a09, 99).
vypil(1583, default_a10, 90).
vypil(1584, default_a06, 8).
vypil(1585, default_a07, 77).
vypil(1586, default_a09, 17).
vypil(1587, default_a01, 16).
vypil(1588, default_a07, 2).
vypil(1589, default_a11, 27).
vypil(1590, default_a04, 88).
vypil(1591, default_a07, 63).
vypil(1592, default_a09, 42).
vypil(1593, default_a01, 64).
vypil(1594, default_a04, 86).
vypil(1595, default_a07, 11).
vypil(1596, default_a01, 79).
vypil(1597, default_a04, 13).
vypil(1598, default_a06, 93).
vypil(1599, default_a04, 39).
vypil(1600, default_a07, 44).
vypil(1601, default_a11, 93).
vypil(1602, default_a01, 8).
vypil(1603, default_a07, 96).
vypil(1604, default_a09, 29).
vypil(1605, default_a01, 94).
vypil(1606, default_a06, 4).
vypil(1607, default_a11, 55).
vypil(1608, default_a04, 100).
vypil(1609, default_a07, 44).
vypil(1610, default_a09, 18).
vypil(1611, default_a04, 20).
vypil(1612, default_a07, 99).
vypil(1613, default_a09, 34).
vypil(1614, default_a01, 71).
vypil(1615, default_a06, 11).
vypil(1616, default_a11, 59).
vypil(1617, default_a04, 91).
vypil(1618, default_a10, 11).
vypil(1619, default_a11, 19).
vypil(1620, default_a03, 68).
vypil(1621, default_a06, 21).
vypil(1622, default_a07, 96).
vypil(1623, default_a03, 15).
vypil(1624, default_a06, 83).
vypil(1625, default_a07, 44).
vypil(1626, default_a03, 87).
vypil(1627, default_a06, 68).
vypil(1628, default_a11, 59).
vypil(1629, default_a03, 3).
vypil(1630, default_a04, 54).
vypil(1631, default_a11, 33).
vypil(1632, default_a06, 87).
vypil(1633, default_a07, 61).
vypil(1634, default_a11, 10).
vypil(1635, default_a04, 94).
vypil(1636, default_a07, 88).
vypil(1637, default_a11, 29).
vypil(1638, default_a04, 62).
vypil(1639, default_a06, 30).
vypil(1640, default_a07, 11).
vypil(1641, default_a04, 1).
vypil(1642, default_a07, 81).
vypil(1643, default_a11, 45).
vypil(1644, default_a03, 37).
vypil(1645, default_a07, 71).
vypil(1646, default_a11, 95).
vypil(1647, default_a04, 49).
vypil(1648, default_a07, 51).
vypil(1649, default_a10, 47).
vypil(1650, default_a02, 88).
vypil(1651, default_a08, 81).
vypil(1652, default_a09, 53).
vypil(1653, default_a09, 53).
vypil(1654, default_a10, 73).
vypil(1655, default_a12, 93).
vypil(1656, default_a02, 7).
vypil(1657, default_a08, 22).
vypil(1658, default_a12, 86).
vypil(1659, default_a09, 38).
vypil(1660, default_a10, 3).
vypil(1661, default_a12, 72).
vypil(1662, default_a02, 12).
vypil(1663, default_a09, 81).
vypil(1664, default_a10, 18).
vypil(1665, default_a04, 100).
vypil(1666, default_a09, 61).
vypil(1667, default_a12, 13).
vypil(1668, default_a09, 48).
vypil(1669, default_a10, 95).
vypil(1670, default_a12, 98).
vypil(1671, default_a02, 31).
vypil(1672, default_a04, 93).
vypil(1673, default_a12, 33).
vypil(1674, default_a08, 70).
vypil(1675, default_a09, 55).
vypil(1676, default_a10, 38).
vypil(1677, default_a02, 69).
vypil(1678, default_a09, 89).
vypil(1679, default_a10, 81).
vypil(1680, default_a08, 13).
vypil(1681, default_a09, 71).
vypil(1682, default_a10, 76).
vypil(1683, default_a01, 68).
vypil(1684, default_a08, 5).
vypil(1685, default_a10, 15).
vypil(1686, default_a01, 36).
vypil(1687, default_a08, 51).
vypil(1688, default_a09, 76).
vypil(1689, default_a01, 30).
vypil(1690, default_a08, 6).
vypil(1691, default_a11, 81).
vypil(1692, default_a01, 46).
vypil(1693, default_a08, 71).
vypil(1694, default_a11, 25).
vypil(1695, default_a02, 91).
vypil(1696, default_a08, 55).
vypil(1697, default_a11, 93).
vypil(1698, default_a01, 15).
vypil(1699, default_a08, 12).
vypil(1700, default_a10, 17).
vypil(1701, default_a02, 80).
vypil(1702, default_a09, 66).
vypil(1703, default_a11, 59).
vypil(1704, default_a08, 43).
vypil(1705, default_a09, 56).
vypil(1706, default_a11, 92).
vypil(1707, default_a02, 3).
vypil(1708, default_a10, 48).
vypil(1709, default_a11, 45).
vypil(1710, default_a02, 81).
vypil(1711, default_a09, 33).
vypil(1712, default_a11, 74).
vypil(1713, default_a02, 42).
vypil(1714, default_a09, 69).
vypil(1715, default_a10, 55).
vypil(1716, default_a01, 97).
vypil(1717, default_a05, 22).
vypil(1718, default_a06, 78).
vypil(1719, default_a01, 40).
vypil(1720, default_a05, 97).
vypil(1721, default_a06, 30).
vypil(1722, default_a04, 40).
vypil(1723, default_a05, 85).
vypil(1724, default_a11, 65).
vypil(1725, default_a06, 70).
vypil(1726, default_a07, 6).
vypil(1727, default_a11, 95).
vypil(1728, default_a05, 82).
vypil(1729, default_a06, 24).
vypil(1730, default_a11, 52).
vypil(1731, default_a01, 57).
vypil(1732, default_a05, 34).
vypil(1733, default_a06, 71).
vypil(1734, default_a04, 96).
vypil(1735, default_a05, 32).
vypil(1736, default_a11, 86).
vypil(1737, default_a05, 22).
vypil(1738, default_a06, 87).
vypil(1739, default_a11, 86).
vypil(1740, default_a01, 31).
vypil(1741, default_a04, 83).
vypil(1742, default_a11, 36).
vypil(1743, default_a06, 54).
vypil(1744, default_a07, 28).
vypil(1745, default_a11, 95).
vypil(1746, default_a05, 77).
vypil(1747, default_a06, 86).
vypil(1748, default_a07, 56).
vypil(1749, default_a02, 85).
vypil(1750, default_a07, 79).
vypil(1751, default_a11, 14).
vypil(1752, default_a07, 75).
vypil(1753, default_a11, 47).
vypil(1754, default_a12, 37).
vypil(1755, default_a02, 53).
vypil(1756, default_a08, 31).
vypil(1757, default_a12, 15).
vypil(1758, default_a02, 12).
vypil(1759, default_a11, 51).
vypil(1760, default_a12, 32).
vypil(1761, default_a02, 19).
vypil(1762, default_a05, 62).
vypil(1763, default_a12, 17).
vypil(1764, default_a05, 59).
vypil(1765, default_a07, 83).
vypil(1766, default_a12, 64).
vypil(1767, default_a02, 36).
vypil(1768, default_a08, 60).
vypil(1769, default_a12, 14).
vypil(1770, default_a05, 88).
vypil(1771, default_a07, 4).
vypil(1772, default_a12, 30).
vypil(1773, default_a02, 65).
vypil(1774, default_a08, 61).
vypil(1775, default_a12, 79).
vypil(1776, default_a05, 28).
vypil(1777, default_a07, 79).
vypil(1778, default_a11, 43).
vypil(1779, default_a08, 52).
vypil(1780, default_a11, 97).
vypil(1781, default_a12, 57).
vypil(1782, default_a05, 3).
vypil(1783, default_a11, 59).
vypil(1784, default_a12, 49).
vypil(1785, default_a01, 54).
vypil(1786, default_a08, 43).
vypil(1787, default_a09, 3).
vypil(1788, default_a03, 76).
vypil(1789, default_a07, 8).
vypil(1790, default_a08, 97).
vypil(1791, default_a03, 13).
vypil(1792, default_a06, 23).
vypil(1793, default_a08, 83).
vypil(1794, default_a03, 62).
vypil(1795, default_a07, 57).
vypil(1796, default_a09, 90).
vypil(1797, default_a03, 58).
vypil(1798, default_a06, 88).
vypil(1799, default_a09, 22).
vypil(1800, default_a01, 8).
vypil(1801, default_a03, 16).
vypil(1802, default_a07, 36).
vypil(1803, default_a01, 47).
vypil(1804, default_a03, 48).
vypil(1805, default_a06, 74).
vypil(1806, default_a01, 96).
vypil(1807, default_a06, 11).
vypil(1808, default_a07, 95).
vypil(1809, default_a01, 86).
vypil(1810, default_a07, 54).
vypil(1811, default_a08, 25).
vypil(1812, default_a07, 39).
vypil(1813, default_a08, 72).
vypil(1814, default_a09, 21).
vypil(1815, default_a06, 89).
vypil(1816, default_a07, 53).
vypil(1817, default_a08, 50).
vypil(1818, default_a01, 1).
vypil(1819, default_a07, 17).
vypil(1820, default_a08, 6).
vypil(1821, default_a02, 39).
vypil(1822, default_a03, 10).
vypil(1823, default_a10, 99).
vypil(1824, default_a02, 95).
vypil(1825, default_a03, 20).
vypil(1826, default_a07, 78).
vypil(1827, default_a02, 67).
vypil(1828, default_a03, 41).
vypil(1829, default_a06, 48).
vypil(1830, default_a03, 93).
vypil(1831, default_a07, 17).
vypil(1832, default_a10, 80).
vypil(1833, default_a01, 9).
vypil(1834, default_a02, 41).
vypil(1835, default_a06, 85).
vypil(1836, default_a01, 47).
vypil(1837, default_a02, 86).
vypil(1838, default_a06, 84).
vypil(1839, default_a02, 37).
vypil(1840, default_a07, 59).
vypil(1841, default_a10, 84).
vypil(1842, default_a02, 40).
vypil(1843, default_a06, 12).
vypil(1844, default_a07, 7).
vypil(1845, default_a01, 90).
vypil(1846, default_a06, 55).
vypil(1847, default_a10, 84).
vypil(1848, default_a02, 36).
vypil(1849, default_a06, 31).
vypil(1850, default_a07, 96).
vypil(1851, default_a01, 18).
vypil(1852, default_a02, 30).
vypil(1853, default_a07, 5).
vypil(1854, default_a02, 2).
vypil(1855, default_a03, 17).
vypil(1856, default_a06, 93).
vypil(1857, default_a06, 17).
vypil(1858, default_a08, 47).
vypil(1859, default_a12, 45).
vypil(1860, default_a02, 78).
vypil(1861, default_a03, 23).
vypil(1862, default_a08, 81).
vypil(1863, default_a02, 99).
vypil(1864, default_a03, 32).
vypil(1865, default_a12, 9).
vypil(1866, default_a02, 55).
vypil(1867, default_a03, 78).
vypil(1868, default_a08, 21).
vypil(1869, default_a03, 11).
vypil(1870, default_a06, 97).
vypil(1871, default_a12, 49).
vypil(1872, default_a06, 100).
vypil(1873, default_a08, 98).
vypil(1874, default_a12, 29).
vypil(1875, default_a02, 9).
vypil(1876, default_a03, 74).
vypil(1877, default_a12, 43).
vypil(1878, default_a01, 68).
vypil(1879, default_a06, 7).
vypil(1880, default_a12, 7).
vypil(1881, default_a01, 53).
vypil(1882, default_a06, 95).
vypil(1883, default_a08, 77).
vypil(1884, default_a01, 60).
vypil(1885, default_a02, 63).
vypil(1886, default_a06, 78).
vypil(1887, default_a06, 11).
vypil(1888, default_a08, 91).
vypil(1889, default_a12, 61).
vypil(1890, default_a02, 23).
vypil(1891, default_a03, 18).
vypil(1892, default_a06, 81).
vypil(1893, default_a08, 70).
vypil(1894, default_a09, 89).
vypil(1895, default_a11, 34).
vypil(1896, default_a01, 13).
vypil(1897, default_a10, 81).
vypil(1898, default_a11, 47).
vypil(1899, default_a01, 99).
vypil(1900, default_a08, 65).
vypil(1901, default_a10, 32).
vypil(1902, default_a03, 64).
vypil(1903, default_a09, 54).
vypil(1904, default_a10, 64).
vypil(1905, default_a01, 49).
vypil(1906, default_a08, 10).
vypil(1907, default_a09, 50).
vypil(1908, default_a08, 12).
vypil(1909, default_a09, 100).
vypil(1910, default_a11, 67).
vypil(1911, default_a03, 45).
vypil(1912, default_a10, 12).
vypil(1913, default_a11, 34).
vypil(1914, default_a01, 86).
vypil(1915, default_a09, 11).
vypil(1916, default_a10, 75).
vypil(1917, default_a03, 88).
vypil(1918, default_a09, 83).
vypil(1919, default_a11, 83).
vypil(1920, default_a03, 83).
vypil(1921, default_a10, 28).
vypil(1922, default_a11, 18).
vypil(1923, default_a03, 89).
vypil(1924, default_a08, 100).
vypil(1925, default_a11, 13).
vypil(1926, default_a01, 39).
vypil(1927, default_a09, 96).
vypil(1928, default_a11, 27).
vypil(1929, default_a01, 70).
vypil(1930, default_a04, 28).
vypil(1931, default_a06, 100).
vypil(1932, default_a04, 60).
vypil(1933, default_a06, 21).
vypil(1934, default_a11, 94).
vypil(1935, default_a01, 99).
vypil(1936, default_a07, 53).
vypil(1937, default_a09, 88).
vypil(1938, default_a01, 52).
vypil(1939, default_a04, 33).
vypil(1940, default_a11, 46).
vypil(1941, default_a01, 66).
vypil(1942, default_a06, 57).
vypil(1943, default_a11, 66).
vypil(1944, default_a07, 62).
vypil(1945, default_a09, 94).
vypil(1946, default_a11, 57).
vypil(1947, default_a04, 9).
vypil(1948, default_a07, 38).
vypil(1949, default_a11, 39).
vypil(1950, default_a01, 73).
vypil(1951, default_a06, 69).
vypil(1952, default_a11, 93).
vypil(1953, default_a01, 59).
vypil(1954, default_a09, 4).
vypil(1955, default_a11, 84).
vypil(1956, default_a01, 59).
vypil(1957, default_a07, 41).
vypil(1958, default_a09, 34).
vypil(1959, default_a06, 98).
vypil(1960, default_a07, 98).
vypil(1961, default_a09, 81).
vypil(1962, default_a04, 20).
vypil(1963, default_a06, 33).
vypil(1964, default_a07, 78).
vypil(1965, default_a03, 22).
vypil(1966, default_a06, 9).
vypil(1967, default_a07, 42).
vypil(1968, default_a06, 84).
vypil(1969, default_a07, 32).
vypil(1970, default_a10, 18).
vypil(1971, default_a03, 100).
vypil(1972, default_a04, 70).
vypil(1973, default_a10, 71).
vypil(1974, default_a03, 40).
vypil(1975, default_a06, 27).
vypil(1976, default_a11, 12).
vypil(1977, default_a03, 33).
vypil(1978, default_a07, 5).
vypil(1979, default_a11, 6).
vypil(1980, default_a03, 57).
vypil(1981, default_a04, 52).
vypil(1982, default_a11, 17).
vypil(1983, default_a03, 55).
vypil(1984, default_a06, 36).
vypil(1985, default_a11, 6).
vypil(1986, default_a04, 23).
vypil(1987, default_a10, 7).
vypil(1988, default_a11, 46).
vypil(1989, default_a04, 48).
vypil(1990, default_a06, 81).
vypil(1991, default_a10, 12).
vypil(1992, default_a04, 70).
vypil(1993, default_a07, 91).
vypil(1994, default_a10, 71).
vypil(1995, default_a03, 29).
vypil(1996, default_a04, 67).
vypil(1997, default_a06, 78).
vypil(1998, default_a04, 49).
vypil(1999, default_a07, 90).
vypil(2000, default_a11, 55).
vypil(2001, default_a02, 22).
vypil(2002, default_a04, 91).
vypil(2003, default_a08, 75).
vypil(2004, default_a02, 31).
vypil(2005, default_a08, 23).
vypil(2006, default_a10, 91).
vypil(2007, default_a02, 88).
vypil(2008, default_a09, 9).
vypil(2009, default_a10, 15).
vypil(2010, default_a04, 66).
vypil(2011, default_a09, 60).
vypil(2012, default_a10, 18).
vypil(2013, default_a02, 48).
vypil(2014, default_a04, 46).
vypil(2015, default_a12, 80).
vypil(2016, default_a02, 65).
vypil(2017, default_a08, 5).
vypil(2018, default_a12, 77).
vypil(2019, default_a04, 97).
vypil(2020, default_a09, 5).
vypil(2021, default_a12, 40).
vypil(2022, default_a04, 56).
vypil(2023, default_a09, 36).
vypil(2024, default_a12, 67).
vypil(2025, default_a02, 6).
vypil(2026, default_a08, 19).
vypil(2027, default_a12, 44).
vypil(2028, default_a02, 6).
vypil(2029, default_a09, 10).
vypil(2030, default_a10, 93).
vypil(2031, default_a09, 84).
vypil(2032, default_a10, 2).
vypil(2033, default_a12, 22).
vypil(2034, default_a09, 12).
vypil(2035, default_a10, 88).
vypil(2036, default_a12, 99).
vypil(2037, default_a02, 12).
vypil(2038, default_a09, 44).
vypil(2039, default_a10, 87).
vypil(2040, default_a01, 13).
vypil(2041, default_a08, 85).
vypil(2042, default_a10, 71).
vypil(2043, default_a01, 48).
vypil(2044, default_a10, 83).
vypil(2045, default_a11, 90).
vypil(2046, default_a09, 61).
vypil(2047, default_a10, 8).
vypil(2048, default_a11, 9).
vypil(2049, default_a01, 39).
vypil(2050, default_a02, 98).
vypil(2051, default_a08, 31).
vypil(2052, default_a08, 49).
vypil(2053, default_a10, 100).
vypil(2054, default_a11, 74).
vypil(2055, default_a01, 47).
vypil(2056, default_a08, 71).
vypil(2057, default_a10, 93).
vypil(2058, default_a01, 14).
vypil(2059, default_a08, 62).
vypil(2060, default_a09, 74).
vypil(2061, default_a02, 81).
vypil(2062, default_a08, 53).
vypil(2063, default_a10, 18).
vypil(2064, default_a02, 10).
vypil(2065, default_a10, 83).
vypil(2066, default_a11, 68).
vypil(2067, default_a01, 95).
vypil(2068, default_a09, 21).
vypil(2069, default_a10, 100).
vypil(2070, default_a09, 62).
vypil(2071, default_a10, 45).
vypil(2072, default_a11, 60).
vypil(2073, default_a01, 70).
vypil(2074, default_a05, 9).
vypil(2075, default_a11, 78).
vypil(2076, default_a01, 48).
vypil(2077, default_a06, 69).
vypil(2078, default_a07, 8).
vypil(2079, default_a04, 28).
vypil(2080, default_a05, 57).
vypil(2081, default_a07, 38).
vypil(2082, default_a01, 98).
vypil(2083, default_a06, 54).
vypil(2084, default_a07, 11).
vypil(2085, default_a01, 82).
vypil(2086, default_a07, 32).
vypil(2087, default_a11, 38).
vypil(2088, default_a04, 92).
vypil(2089, default_a06, 19).
vypil(2090, default_a11, 37).
vypil(2091, default_a01, 17).
vypil(2092, default_a06, 3).
vypil(2093, default_a07, 38).
vypil(2094, default_a01, 10).
vypil(2095, default_a06, 68).
vypil(2096, default_a11, 55).
vypil(2097, default_a01, 93).
vypil(2098, default_a04, 34).
vypil(2099, default_a11, 31).
vypil(2100, default_a01, 16).
vypil(2101, default_a04, 91).
vypil(2102, default_a11, 32).
vypil(2103, default_a04, 68).
vypil(2104, default_a05, 67).
vypil(2105, default_a06, 16).
vypil(2106, default_a04, 39).
vypil(2107, default_a06, 92).
vypil(2108, default_a11, 78).
vypil(2109, default_a07, 38).
vypil(2110, default_a11, 82).
vypil(2111, default_a12, 18).
vypil(2112, default_a02, 87).
vypil(2113, default_a05, 7).
vypil(2114, default_a12, 50).
vypil(2115, default_a02, 63).
vypil(2116, default_a05, 66).
vypil(2117, default_a11, 17).
vypil(2118, default_a02, 93).
vypil(2119, default_a11, 19).
vypil(2120, default_a12, 69).
vypil(2121, default_a02, 3).
vypil(2122, default_a07, 93).
vypil(2123, default_a11, 85).
vypil(2124, default_a05, 22).
vypil(2125, default_a08, 100).
vypil(2126, default_a11, 95).
vypil(2127, default_a05, 41).
vypil(2128, default_a08, 17).
vypil(2129, default_a12, 54).
vypil(2130, default_a05, 80).
vypil(2131, default_a08, 21).
vypil(2132, default_a11, 18).
vypil(2133, default_a05, 83).
vypil(2134, default_a08, 83).
vypil(2135, default_a12, 9).
vypil(2136, default_a05, 60).
vypil(2137, default_a08, 36).
vypil(2138, default_a12, 20).
vypil(2139, default_a02, 83).
vypil(2140, default_a07, 76).
vypil(2141, default_a11, 20).
vypil(2142, default_a07, 72).
vypil(2143, default_a11, 25).
vypil(2144, default_a12, 89).
vypil(2145, default_a07, 78).
vypil(2146, default_a08, 24).
vypil(2147, default_a12, 62).
vypil(2148, default_a01, 52).
vypil(2149, default_a03, 65).
vypil(2150, default_a09, 43).
vypil(2151, default_a01, 82).
vypil(2152, default_a03, 75).
vypil(2153, default_a07, 69).
vypil(2154, default_a01, 93).
vypil(2155, default_a03, 50).
vypil(2156, default_a09, 76).
vypil(2157, default_a01, 7).
vypil(2158, default_a03, 58).
vypil(2159, default_a07, 11).
vypil(2160, default_a03, 56).
vypil(2161, default_a06, 99).
vypil(2162, default_a08, 47).
vypil(2163, default_a03, 74).
vypil(2164, default_a06, 36).
vypil(2165, default_a08, 41).
vypil(2166, default_a01, 74).
vypil(2167, default_a03, 20).
vypil(2168, default_a07, 83).
vypil(2169, default_a01, 36).
vypil(2170, default_a03, 36).
vypil(2171, default_a08, 55).
vypil(2172, default_a03, 42).
vypil(2173, default_a07, 48).
vypil(2174, default_a08, 64).
vypil(2175, default_a01, 100).
vypil(2176, default_a03, 69).
vypil(2177, default_a06, 74).
vypil(2178, default_a01, 100).
vypil(2179, default_a03, 87).
vypil(2180, default_a08, 47).
vypil(2181, default_a03, 7).
vypil(2182, default_a06, 10).
vypil(2183, default_a08, 97).
vypil(2184, default_a01, 84).
vypil(2185, default_a06, 10).
vypil(2186, default_a09, 94).
vypil(2187, default_a02, 84).
vypil(2188, default_a06, 43).
vypil(2189, default_a10, 36).
vypil(2190, default_a02, 75).
vypil(2191, default_a03, 56).
vypil(2192, default_a10, 91).
vypil(2193, default_a06, 65).
vypil(2194, default_a07, 99).
vypil(2195, default_a10, 52).
vypil(2196, default_a02, 12).
vypil(2197, default_a03, 26).
vypil(2198, default_a07, 68).
vypil(2199, default_a02, 29).
vypil(2200, default_a07, 30).
vypil(2201, default_a10, 70).
vypil(2202, default_a02, 24).
vypil(2203, default_a03, 81).
vypil(2204, default_a07, 97).
vypil(2205, default_a01, 89).
vypil(2206, default_a02, 56).
vypil(2207, default_a03, 94).
vypil(2208, default_a06, 14).
vypil(2209, default_a07, 48).
vypil(2210, default_a10, 46).
vypil(2211, default_a06, 76).
vypil(2212, default_a07, 64).
vypil(2213, default_a10, 31).
vypil(2214, default_a02, 51).
vypil(2215, default_a06, 45).
vypil(2216, default_a10, 92).
vypil(2217, default_a02, 1).
vypil(2218, default_a03, 34).
vypil(2219, default_a10, 97).
vypil(2220, default_a01, 26).
vypil(2221, default_a03, 94).
vypil(2222, default_a06, 30).
vypil(2223, default_a01, 90).
vypil(2224, default_a02, 59).
vypil(2225, default_a10, 74).
vypil(2226, default_a06, 23).
vypil(2227, default_a08, 74).
vypil(2228, default_a12, 41).
vypil(2229, default_a01, 90).
vypil(2230, default_a06, 53).
vypil(2231, default_a08, 41).
vypil(2232, default_a01, 71).
vypil(2233, default_a06, 74).
vypil(2234, default_a08, 56).
vypil(2235, default_a01, 35).
vypil(2236, default_a02, 2).
vypil(2237, default_a12, 15).
vypil(2238, default_a02, 67).
vypil(2239, default_a06, 79).
vypil(2240, default_a12, 83).
vypil(2241, default_a06, 21).
vypil(2242, default_a08, 43).
vypil(2243, default_a12, 39).
vypil(2244, default_a03, 25).
vypil(2245, default_a06, 26).
vypil(2246, default_a12, 73).
vypil(2247, default_a02, 77).
vypil(2248, default_a06, 100).
vypil(2249, default_a12, 48).
vypil(2250, default_a01, 51).
vypil(2251, default_a06, 49).
vypil(2252, default_a08, 98).
vypil(2253, default_a02, 70).
vypil(2254, default_a03, 79).
vypil(2255, default_a06, 37).
vypil(2256, default_a02, 78).
vypil(2257, default_a03, 57).
vypil(2258, default_a06, 30).
vypil(2259, default_a03, 66).
vypil(2260, default_a08, 57).
vypil(2261, default_a12, 15).
vypil(2262, default_a01, 26).
vypil(2263, default_a03, 44).
vypil(2264, default_a12, 53).
vypil(2265, default_a03, 70).
vypil(2266, default_a09, 65).
vypil(2267, default_a11, 99).
vypil(2268, default_a01, 92).
vypil(2269, default_a08, 81).
vypil(2270, default_a09, 44).
vypil(2271, default_a08, 2).
vypil(2272, default_a09, 91).
vypil(2273, default_a11, 94).
vypil(2274, default_a08, 72).
vypil(2275, default_a10, 80).
vypil(2276, default_a11, 26).
vypil(2277, default_a01, 19).
vypil(2278, default_a03, 100).
vypil(2279, default_a08, 37).
vypil(2280, default_a01, 59).
vypil(2281, default_a03, 88).
vypil(2282, default_a09, 39).
vypil(2283, default_a08, 32).
vypil(2284, default_a09, 40).
vypil(2285, default_a10, 43).
vypil(2286, default_a01, 5).
vypil(2287, default_a03, 66).
vypil(2288, default_a11, 67).
vypil(2289, default_a03, 50).
vypil(2290, default_a08, 49).
vypil(2291, default_a09, 23).
vypil(2292, default_a01, 9).
vypil(2293, default_a03, 73).
vypil(2294, default_a11, 26).
vypil(2295, default_a01, 94).
vypil(2296, default_a03, 47).
vypil(2297, default_a11, 52).
vypil(2298, default_a03, 55).
vypil(2299, default_a08, 61).
vypil(2300, default_a09, 12).
vypil(2301, default_a01, 76).
vypil(2302, default_a03, 59).
vypil(2303, default_a08, 71).
vypil(2304, default_a04, 26).
vypil(2305, default_a06, 6).
vypil(2306, default_a11, 8).
vypil(2307, default_a04, 68).
vypil(2308, default_a06, 75).
vypil(2309, default_a09, 13).
vypil(2310, default_a04, 91).
vypil(2311, default_a06, 83).
vypil(2312, default_a11, 12).
vypil(2313, default_a04, 65).
vypil(2314, default_a07, 58).
vypil(2315, default_a09, 90).
vypil(2316, default_a01, 80).
vypil(2317, default_a07, 92).
vypil(2318, default_a11, 24).
vypil(2319, default_a04, 68).
vypil(2320, default_a06, 4).
vypil(2321, default_a11, 100).
vypil(2322, default_a01, 31).
vypil(2323, default_a04, 99).
vypil(2324, default_a06, 50).
vypil(2325, default_a04, 28).
vypil(2326, default_a06, 78).
vypil(2327, default_a11, 3).
vypil(2328, default_a01, 38).
vypil(2329, default_a04, 70).
vypil(2330, default_a09, 50).
vypil(2331, default_a06, 30).
vypil(2332, default_a07, 56).
vypil(2333, default_a09, 29).
vypil(2334, default_a07, 90).
vypil(2335, default_a09, 45).
vypil(2336, default_a11, 95).
vypil(2337, default_a07, 56).
vypil(2338, default_a09, 77).
vypil(2339, default_a11, 50).
vypil(2340, default_a04, 9).
vypil(2341, default_a06, 78).
vypil(2342, default_a09, 61).
vypil(2343, default_a04, 26).
vypil(2344, default_a06, 32).
vypil(2345, default_a07, 68).
vypil(2346, default_a03, 12).
vypil(2347, default_a07, 40).
vypil(2348, default_a10, 11).
vypil(2349, default_a03, 79).
vypil(2350, default_a04, 87).
vypil(2351, default_a11, 66).
vypil(2352, default_a03, 70).
vypil(2353, default_a06, 11).
vypil(2354, default_a07, 26).
vypil(2355, default_a03, 98).
vypil(2356, default_a04, 98).
vypil(2357, default_a07, 6).
vypil(2358, default_a03, 51).
vypil(2359, default_a04, 47).
vypil(2360, default_a07, 14).
vypil(2361, default_a04, 6).
vypil(2362, default_a06, 85).
vypil(2363, default_a07, 64).
vypil(2364, default_a04, 37).
vypil(2365, default_a07, 63).
vypil(2366, default_a10, 70).
vypil(2367, default_a03, 87).
vypil(2368, default_a06, 67).
vypil(2369, default_a10, 99).
vypil(2370, default_a04, 11).
vypil(2371, default_a07, 56).
vypil(2372, default_a11, 59).
vypil(2373, default_a06, 90).
vypil(2374, default_a07, 31).
vypil(2375, default_a10, 36).
vypil(2376, default_a03, 5).
vypil(2377, default_a07, 38).
vypil(2378, default_a10, 16).
vypil(2379, default_a06, 15).
vypil(2380, default_a07, 29).
vypil(2381, default_a11, 7).
vypil(2382, default_a08, 24).
vypil(2383, default_a09, 90).
vypil(2384, default_a10, 11).
vypil(2385, default_a04, 17).
vypil(2386, default_a08, 33).
vypil(2387, default_a10, 88).
vypil(2388, default_a08, 41).
vypil(2389, default_a10, 77).
vypil(2390, default_a12, 75).
vypil(2391, default_a02, 8).
vypil(2392, default_a04, 31).
vypil(2393, default_a12, 28).
vypil(2394, default_a02, 83).
vypil(2395, default_a04, 80).
vypil(2396, default_a12, 51).
vypil(2397, default_a02, 71).
vypil(2398, default_a09, 9).
vypil(2399, default_a12, 42).
vypil(2400, default_a09, 16).
vypil(2401, default_a10, 28).
vypil(2402, default_a12, 27).
vypil(2403, default_a02, 72).
vypil(2404, default_a04, 71).
vypil(2405, default_a08, 51).
vypil(2406, default_a08, 35).
vypil(2407, default_a09, 24).
vypil(2408, default_a12, 12).
vypil(2409, default_a02, 65).
vypil(2410, default_a10, 28).
vypil(2411, default_a12, 81).
vypil(2412, default_a09, 12).
vypil(2413, default_a10, 52).
vypil(2414, default_a12, 33).
vypil(2415, default_a08, 69).
vypil(2416, default_a09, 37).
vypil(2417, default_a12, 80).
vypil(2418, default_a02, 37).
vypil(2419, default_a08, 86).
vypil(2420, default_a09, 59).
vypil(2421, default_a01, 27).
vypil(2422, default_a08, 93).
vypil(2423, default_a10, 43).
vypil(2424, default_a02, 85).
vypil(2425, default_a10, 87).
vypil(2426, default_a11, 42).
vypil(2427, default_a02, 91).
vypil(2428, default_a10, 100).
vypil(2429, default_a11, 35).
vypil(2430, default_a01, 86).
vypil(2431, default_a09, 7).
vypil(2432, default_a10, 60).
vypil(2433, default_a02, 66).
vypil(2434, default_a10, 66).
vypil(2435, default_a11, 79).
vypil(2436, default_a01, 45).
vypil(2437, default_a08, 74).
vypil(2438, default_a09, 76).
vypil(2439, default_a08, 98).
vypil(2440, default_a09, 71).
vypil(2441, default_a11, 45).
vypil(2442, default_a01, 81).
vypil(2443, default_a08, 88).
vypil(2444, default_a09, 34).
vypil(2445, default_a02, 48).
vypil(2446, default_a09, 63).
vypil(2447, default_a10, 8).
vypil(2448, default_a01, 80).
vypil(2449, default_a09, 54).
vypil(2450, default_a11, 23).
vypil(2451, default_a09, 71).
vypil(2452, default_a10, 9).
vypil(2453, default_a11, 11).
vypil(2454, default_a08, 48).
vypil(2455, default_a10, 84).
vypil(2456, default_a11, 87).
vypil(2457, default_a01, 63).
vypil(2458, default_a02, 90).
vypil(2459, default_a09, 22).
vypil(2460, default_a04, 47).
vypil(2461, default_a05, 100).
vypil(2462, default_a07, 9).
vypil(2463, default_a05, 93).
vypil(2464, default_a06, 38).
vypil(2465, default_a11, 23).
vypil(2466, default_a01, 80).
vypil(2467, default_a04, 58).
vypil(2468, default_a05, 60).
vypil(2469, default_a01, 54).
vypil(2470, default_a05, 97).
vypil(2471, default_a07, 53).
vypil(2472, default_a04, 66).
vypil(2473, default_a05, 18).
vypil(2474, default_a11, 74).
vypil(2475, default_a01, 88).
vypil(2476, default_a06, 94).
vypil(2477, default_a11, 79).
vypil(2478, default_a04, 21).
vypil(2479, default_a06, 99).
vypil(2480, default_a11, 15).
vypil(2481, default_a01, 8).
vypil(2482, default_a07, 72).
vypil(2483, default_a11, 93).
vypil(2484, default_a05, 27).
vypil(2485, default_a06, 100).
vypil(2486, default_a11, 30).
vypil(2487, default_a04, 42).
vypil(2488, default_a05, 53).
vypil(2489, default_a11, 44).
vypil(2490, default_a01, 40).
vypil(2491, default_a04, 2).
vypil(2492, default_a05, 47).
vypil(2493, default_a05, 94).
vypil(2494, default_a06, 97).
vypil(2495, default_a07, 11).
vypil(2496, default_a01, 29).
vypil(2497, default_a04, 56).
vypil(2498, default_a06, 5).
vypil(2499, default_a02, 72).
vypil(2500, default_a08, 69).
vypil(2501, default_a11, 59).
vypil(2502, default_a08, 45).
vypil(2503, default_a11, 73).
vypil(2504, default_a12, 56).
vypil(2505, default_a05, 47).
vypil(2506, default_a11, 66).
vypil(2507, default_a12, 1).
vypil(2508, default_a07, 79).
vypil(2509, default_a08, 29).
vypil(2510, default_a12, 58).
vypil(2511, default_a08, 12).
vypil(2512, default_a11, 79).
vypil(2513, default_a12, 92).
vypil(2514, default_a07, 66).
vypil(2515, default_a08, 50).
vypil(2516, default_a11, 81).
vypil(2517, default_a02, 71).
vypil(2518, default_a07, 39).
vypil(2519, default_a12, 11).
vypil(2520, default_a07, 27).
vypil(2521, default_a11, 41).
vypil(2522, default_a12, 97).
vypil(2523, default_a02, 7).
vypil(2524, default_a07, 58).
vypil(2525, default_a12, 29).
vypil(2526, default_a02, 69).
vypil(2527, default_a08, 25).
vypil(2528, default_a12, 87).
vypil(2529, default_a05, 4).
vypil(2530, default_a07, 43).
vypil(2531, default_a11, 62).
vypil(2532, default_a07, 94).
vypil(2533, default_a08, 40).
vypil(2534, default_a11, 68).
vypil(2535, default_a02, 85).
vypil(2536, default_a05, 21).
vypil(2537, default_a12, 68).
vypil(2538, default_a02, 35).
vypil(2539, default_a07, 4).
vypil(2540, default_a12, 42).
vypil(2541, default_a01, 80).
vypil(2542, default_a06, 77).
vypil(2543, default_a08, 73).
vypil(2544, default_a01, 19).
vypil(2545, default_a03, 33).
vypil(2546, default_a09, 83).
vypil(2547, default_a03, 7).
vypil(2548, default_a07, 44).
vypil(2549, default_a08, 13).
vypil(2550, default_a01, 49).
vypil(2551, default_a06, 10).
vypil(2552, default_a08, 77).
vypil(2553, default_a03, 96).
vypil(2554, default_a06, 74).
vypil(2555, default_a09, 45).
vypil(2556, default_a03, 19).
vypil(2557, default_a06, 81).
vypil(2558, default_a09, 71).
vypil(2559, default_a03, 20).
vypil(2560, default_a08, 75).
vypil(2561, default_a09, 56).
vypil(2562, default_a01, 22).
vypil(2563, default_a07, 19).
vypil(2564, default_a08, 76).
vypil(2565, default_a01, 33).
vypil(2566, default_a06, 30).
vypil(2567, default_a09, 50).
vypil(2568, default_a03, 4).
vypil(2569, default_a06, 57).
vypil(2570, default_a08, 41).
vypil(2571, default_a01, 65).
vypil(2572, default_a07, 71).
vypil(2573, default_a09, 49).
vypil(2574, default_a01, 85).
vypil(2575, default_a07, 49).
vypil(2576, default_a09, 71).
vypil(2577, default_a01, 70).
vypil(2578, default_a06, 74).
vypil(2579, default_a09, 61).
vypil(2580, default_a01, 25).
vypil(2581, default_a03, 33).
vypil(2582, default_a06, 47).
vypil(2583, default_a01, 22).
vypil(2584, default_a03, 43).
vypil(2585, default_a10, 36).
vypil(2586, default_a03, 71).
vypil(2587, default_a07, 14).
vypil(2588, default_a10, 46).
vypil(2589, default_a06, 83).
vypil(2590, default_a07, 57).
vypil(2591, default_a10, 26).
vypil(2592, default_a03, 53).
vypil(2593, default_a06, 61).
vypil(2594, default_a07, 57).
vypil(2595, default_a03, 26).
vypil(2596, default_a07, 78).
vypil(2597, default_a10, 81).
vypil(2598, default_a02, 5).
vypil(2599, default_a07, 87).
vypil(2600, default_a10, 62).
vypil(2601, default_a03, 4).
vypil(2602, default_a06, 42).
vypil(2603, default_a10, 70).
vypil(2604, default_a01, 68).
vypil(2605, default_a02, 73).
vypil(2606, default_a03, 84).
vypil(2607, default_a01, 6).
vypil(2608, default_a06, 26).
vypil(2609, default_a10, 95).
vypil(2610, default_a02, 44).
vypil(2611, default_a03, 64).
vypil(2612, default_a06, 50).
vypil(2613, default_a01, 73).
vypil(2614, default_a03, 52).
vypil(2615, default_a10, 99).
vypil(2616, default_a03, 35).
vypil(2617, default_a06, 14).
vypil(2618, default_a10, 81).
vypil(2619, default_a01, 15).
vypil(2620, default_a02, 8).
vypil(2621, default_a03, 42).
vypil(2622, default_a01, 54).
vypil(2623, default_a03, 46).
vypil(2624, default_a06, 95).
vypil(2625, default_a01, 84).
vypil(2626, default_a06, 43).
vypil(2627, default_a12, 1).
vypil(2628, default_a02, 20).
vypil(2629, default_a03, 55).
vypil(2630, default_a12, 14).
vypil(2631, default_a02, 45).
vypil(2632, default_a03, 22).
vypil(2633, default_a08, 18).
vypil(2634, default_a02, 25).
vypil(2635, default_a03, 81).
vypil(2636, default_a08, 52).
vypil(2637, default_a01, 42).
vypil(2638, default_a03, 81).
vypil(2639, default_a08, 21).
vypil(2640, default_a02, 90).
vypil(2641, default_a03, 100).
vypil(2642, default_a06, 75).
vypil(2643, default_a02, 30).
vypil(2644, default_a06, 98).
vypil(2645, default_a12, 91).
vypil(2646, default_a02, 85).
vypil(2647, default_a06, 57).
vypil(2648, default_a08, 99).
vypil(2649, default_a02, 48).
vypil(2650, default_a08, 81).
vypil(2651, default_a12, 49).
vypil(2652, default_a02, 5).
vypil(2653, default_a08, 51).
vypil(2654, default_a12, 51).
vypil(2655, default_a01, 36).
vypil(2656, default_a03, 61).
vypil(2657, default_a12, 45).
vypil(2658, default_a01, 46).
vypil(2659, default_a02, 51).
vypil(2660, default_a06, 50).
vypil(2661, default_a02, 11).
vypil(2662, default_a08, 50).
vypil(2663, default_a12, 10).
vypil(2664, default_a01, 36).
vypil(2665, default_a08, 35).
vypil(2666, default_a12, 44).
vypil(2667, default_a09, 3).
vypil(2668, default_a10, 94).
vypil(2669, default_a11, 79).
vypil(2670, default_a01, 83).
vypil(2671, default_a08, 5).
vypil(2672, default_a10, 5).
vypil(2673, default_a01, 30).
vypil(2674, default_a08, 71).
vypil(2675, default_a11, 50).
vypil(2676, default_a08, 37).
vypil(2677, default_a09, 67).
vypil(2678, default_a10, 78).
vypil(2679, default_a01, 30).
vypil(2680, default_a03, 20).
vypil(2681, default_a08, 96).
vypil(2682, default_a01, 91).
vypil(2683, default_a08, 3).
vypil(2684, default_a11, 56).
vypil(2685, default_a08, 22).
vypil(2686, default_a09, 54).
vypil(2687, default_a11, 46).
vypil(2688, default_a08, 60).
vypil(2689, default_a10, 35).
vypil(2690, default_a11, 7).
vypil(2691, default_a01, 3).
vypil(2692, default_a08, 58).
vypil(2693, default_a10, 92).
vypil(2694, default_a01, 98).
vypil(2695, default_a08, 77).
vypil(2696, default_a09, 10).
vypil(2697, default_a03, 90).
vypil(2698, default_a08, 72).
vypil(2699, default_a10, 43).
vypil(2700, default_a08, 17).
vypil(2701, default_a09, 100).
vypil(2702, default_a10, 72).
vypil(2703, default_a01, 96).
vypil(2704, default_a03, 44).
vypil(2705, default_a10, 30).
vypil(2706, default_a03, 35).
vypil(2707, default_a10, 72).
vypil(2708, default_a11, 25).
vypil(2709, default_a01, 53).
vypil(2710, default_a06, 14).
vypil(2711, default_a09, 63).
vypil(2712, default_a06, 35).
vypil(2713, default_a07, 20).
vypil(2714, default_a11, 54).
vypil(2715, default_a06, 7).
vypil(2716, default_a09, 51).
vypil(2717, default_a11, 21).
vypil(2718, default_a01, 38).
vypil(2719, default_a06, 77).
vypil(2720, default_a11, 44).
vypil(2721, default_a01, 71).
vypil(2722, default_a09, 8).
vypil(2723, default_a11, 58).
vypil(2724, default_a04, 46).
vypil(2725, default_a09, 75).
vypil(2726, default_a11, 13).
vypil(2727, default_a01, 43).
vypil(2728, default_a09, 35).
vypil(2729, default_a11, 83).
vypil(2730, default_a04, 46).
vypil(2731, default_a06, 63).
vypil(2732, default_a07, 82).
vypil(2733, default_a01, 89).
vypil(2734, default_a04, 40).
vypil(2735, default_a06, 55).
vypil(2736, default_a01, 45).
vypil(2737, default_a06, 100).
vypil(2738, default_a07, 73).
vypil(2739, default_a01, 82).
vypil(2740, default_a04, 26).
vypil(2741, default_a09, 21).
vypil(2742, default_a01, 69).
vypil(2743, default_a04, 31).
vypil(2744, default_a06, 89).
vypil(2745, default_a01, 59).
vypil(2746, default_a04, 17).
vypil(2747, default_a07, 22).
vypil(2748, default_a01, 47).
vypil(2749, default_a04, 3).
vypil(2750, default_a11, 11).
vypil(2751, default_a03, 13).
vypil(2752, default_a04, 40).
vypil(2753, default_a11, 61).
vypil(2754, default_a06, 48).
vypil(2755, default_a10, 82).
vypil(2756, default_a11, 17).
vypil(2757, default_a03, 69).
vypil(2758, default_a07, 38).
vypil(2759, default_a11, 84).
vypil(2760, default_a04, 69).
vypil(2761, default_a10, 81).
vypil(2762, default_a11, 40).
vypil(2763, default_a04, 52).
vypil(2764, default_a07, 43).
vypil(2765, default_a11, 53).
vypil(2766, default_a06, 8).
vypil(2767, default_a07, 61).
vypil(2768, default_a11, 73).
vypil(2769, default_a06, 60).
vypil(2770, default_a07, 10).
vypil(2771, default_a11, 15).
vypil(2772, default_a03, 98).
vypil(2773, default_a04, 59).
vypil(2774, default_a11, 33).
vypil(2775, default_a06, 15).
vypil(2776, default_a07, 83).
vypil(2777, default_a10, 74).
vypil(2778, default_a04, 70).
vypil(2779, default_a07, 71).
vypil(2780, default_a11, 50).
vypil(2781, default_a03, 58).
vypil(2782, default_a06, 7).
vypil(2783, default_a10, 60).
vypil(2784, default_a03, 43).
vypil(2785, default_a04, 72).
vypil(2786, default_a11, 44).
vypil(2787, default_a03, 42).
vypil(2788, default_a10, 80).
vypil(2789, default_a11, 53).
vypil(2790, default_a03, 61).
vypil(2791, default_a07, 2).
vypil(2792, default_a10, 66).
vypil(2793, default_a02, 95).
vypil(2794, default_a10, 63).
vypil(2795, default_a12, 7).
vypil(2796, default_a09, 58).
vypil(2797, default_a10, 74).
vypil(2798, default_a12, 14).
vypil(2799, default_a04, 38).
vypil(2800, default_a09, 21).
vypil(2801, default_a10, 10).
vypil(2802, default_a02, 61).
vypil(2803, default_a10, 43).
vypil(2804, default_a12, 93).
vypil(2805, default_a04, 59).
vypil(2806, default_a09, 80).
vypil(2807, default_a10, 80).
vypil(2808, default_a02, 17).
vypil(2809, default_a09, 63).
vypil(2810, default_a10, 83).
vypil(2811, default_a04, 14).
vypil(2812, default_a09, 90).
vypil(2813, default_a10, 78).
vypil(2814, default_a02, 25).
vypil(2815, default_a09, 7).
vypil(2816, default_a12, 56).
vypil(2817, default_a02, 72).
vypil(2818, default_a04, 3).
vypil(2819, default_a09, 55).
vypil(2820, default_a08, 17).
vypil(2821, default_a09, 21).
vypil(2822, default_a12, 95).
vypil(2823, default_a04, 28).
vypil(2824, default_a09, 12).
vypil(2825, default_a12, 46).
vypil(2826, default_a02, 39).
vypil(2827, default_a04, 44).
vypil(2828, default_a08, 90).
vypil(2829, default_a08, 83).
vypil(2830, default_a09, 8).
vypil(2831, default_a12, 72).
vypil(2832, default_a08, 33).
vypil(2833, default_a10, 5).
vypil(2834, default_a12, 19).
vypil(2835, default_a01, 61).
vypil(2836, default_a09, 70).
vypil(2837, default_a10, 72).
vypil(2838, default_a01, 55).
vypil(2839, default_a02, 17).
vypil(2840, default_a08, 28).
vypil(2841, default_a02, 48).
vypil(2842, default_a10, 75).
vypil(2843, default_a11, 4).
vypil(2844, default_a01, 43).
vypil(2845, default_a02, 86).
vypil(2846, default_a11, 12).
vypil(2847, default_a02, 70).
vypil(2848, default_a10, 46).
vypil(2849, default_a11, 51).
vypil(2850, default_a08, 48).
vypil(2851, default_a09, 59).
vypil(2852, default_a10, 66).
vypil(2853, default_a08, 57).
vypil(2854, default_a09, 9).
vypil(2855, default_a11, 22).
vypil(2856, default_a01, 16).
vypil(2857, default_a02, 23).
vypil(2858, default_a09, 29).
vypil(2859, default_a01, 57).
vypil(2860, default_a09, 79).
vypil(2861, default_a11, 5).
vypil(2862, default_a08, 15).
vypil(2863, default_a10, 98).
vypil(2864, default_a11, 61).
vypil(2865, default_a02, 45).
vypil(2866, default_a10, 26).
vypil(2867, default_a11, 48).
vypil(2868, default_a01, 82).
vypil(2869, default_a08, 21).
vypil(2870, default_a11, 80).
vypil(2871, default_a02, 64).
vypil(2872, default_a10, 31).
vypil(2873, default_a11, 40).
vypil(2874, default_a02, 37).
vypil(2875, default_a09, 25).
vypil(2876, default_a11, 13).
vypil(2877, default_a01, 96).
vypil(2878, default_a04, 7).
vypil(2879, default_a06, 89).
vypil(2880, default_a01, 41).
vypil(2881, default_a06, 10).
vypil(2882, default_a07, 40).
vypil(2883, default_a01, 86).
vypil(2884, default_a05, 51).
vypil(2885, default_a06, 15).
vypil(2886, default_a01, 12).
vypil(2887, default_a06, 43).
vypil(2888, default_a07, 100).
vypil(2889, default_a01, 28).
vypil(2890, default_a04, 49).
vypil(2891, default_a06, 94).
vypil(2892, default_a04, 18).
vypil(2893, default_a07, 19).
vypil(2894, default_a11, 68).
vypil(2895, default_a01, 11).
vypil(2896, default_a04, 93).
vypil(2897, default_a06, 33).
vypil(2898, default_a01, 12).
vypil(2899, default_a04, 8).
vypil(2900, default_a07, 64).
vypil(2901, default_a01, 45).
vypil(2902, default_a06, 11).
vypil(2903, default_a07, 25).
vypil(2904, default_a01, 70).
vypil(2905, default_a04, 86).
vypil(2906, default_a07, 30).
vypil(2907, default_a04, 24).
vypil(2908, default_a07, 98).
vypil(2909, default_a11, 72).
vypil(2910, default_a01, 8).
vypil(2911, default_a06, 41).
vypil(2912, default_a11, 20).
vypil(2913, default_a01, 16).
vypil(2914, default_a04, 12).
vypil(2915, default_a07, 75).
vypil(2916, default_a01, 83).
vypil(2917, default_a04, 58).
vypil(2918, default_a06, 46).
vypil(2919, default_a07, 49).
vypil(2920, default_a11, 57).
vypil(2921, default_a12, 66).
vypil(2922, default_a05, 4).
vypil(2923, default_a11, 48).
vypil(2924, default_a12, 98).
vypil(2925, default_a02, 15).
vypil(2926, default_a11, 13).
vypil(2927, default_a12, 2).
vypil(2928, default_a07, 78).
vypil(2929, default_a08, 28).
vypil(2930, default_a11, 49).
vypil(2931, default_a08, 80).
vypil(2932, default_a11, 94).
vypil(2933, default_a12, 100).
vypil(2934, default_a05, 41).
vypil(2935, default_a07, 52).
vypil(2936, default_a12, 18).
vypil(2937, default_a02, 47).
vypil(2938, default_a05, 2).
vypil(2939, default_a11, 55).
vypil(2940, default_a02, 12).
vypil(2941, default_a05, 25).
vypil(2942, default_a07, 56).
vypil(2943, default_a02, 89).
vypil(2944, default_a05, 46).
vypil(2945, default_a08, 74).
vypil(2946, default_a02, 84).
vypil(2947, default_a05, 92).
vypil(2948, default_a08, 98).
vypil(2949, default_a02, 69).
vypil(2950, default_a05, 50).
vypil(2951, default_a11, 99).
vypil(2952, default_a05, 30).
vypil(2953, default_a08, 84).
vypil(2954, default_a11, 52).
vypil(2955, default_a08, 3).
vypil(2956, default_a11, 30).
vypil(2957, default_a12, 56).
vypil(2958, default_a07, 41).
vypil(2959, default_a11, 62).
vypil(2960, default_a12, 8).
vypil(2961, default_a05, 14).
vypil(2962, default_a07, 12).
vypil(2963, default_a11, 95).
vypil(2964, default_a06, 70).
vypil(2965, default_a07, 34).
vypil(2966, default_a09, 71).
vypil(2967, default_a01, 35).
vypil(2968, default_a07, 78).
vypil(2969, default_a08, 77).
vypil(2970, default_a03, 5).
vypil(2971, default_a08, 26).
vypil(2972, default_a09, 14).
vypil(2973, default_a06, 57).
vypil(2974, default_a08, 17).
vypil(2975, default_a09, 75).
vypil(2976, default_a01, 44).
vypil(2977, default_a07, 52).
vypil(2978, default_a08, 97).
vypil(2979, default_a03, 48).
vypil(2980, default_a06, 69).
vypil(2981, default_a07, 83).
vypil(2982, default_a01, 38).
vypil(2983, default_a03, 77).
vypil(2984, default_a07, 89).
vypil(2985, default_a01, 11).
vypil(2986, default_a03, 100).
vypil(2987, default_a07, 11).
vypil(2988, default_a01, 67).
vypil(2989, default_a06, 88).
vypil(2990, default_a08, 92).
vypil(2991, default_a01, 27).
vypil(2992, default_a03, 85).
vypil(2993, default_a07, 7).
vypil(2994, default_a03, 3).
vypil(2995, default_a06, 24).
vypil(2996, default_a09, 4).
vypil(2997, default_a01, 86).
vypil(2998, default_a07, 66).
vypil(2999, default_a09, 96).
vypil(3000, default_a03, 26).
vypil(3001, default_a08, 47).
vypil(3002, default_a09, 29).
vypil(3003, default_a01, 82).
vypil(3004, default_a03, 94).
vypil(3005, default_a08, 38).
vypil(3006, default_a01, 79).
vypil(3007, default_a07, 71).
vypil(3008, default_a09, 98).
vypil(3009, default_a01, 79).
vypil(3010, default_a03, 74).
vypil(3011, default_a06, 33).
vypil(3012, default_a01, 80).
vypil(3013, default_a03, 69).
vypil(3014, default_a10, 86).
vypil(3015, default_a01, 99).
vypil(3016, default_a03, 59).
vypil(3017, default_a06, 65).
vypil(3018, default_a01, 46).
vypil(3019, default_a02, 6).
vypil(3020, default_a03, 5).
vypil(3021, default_a02, 47).
vypil(3022, default_a03, 72).
vypil(3023, default_a10, 18).
vypil(3024, default_a01, 65).
vypil(3025, default_a02, 47).
vypil(3026, default_a10, 89).
vypil(3027, default_a03, 75).
vypil(3028, default_a07, 76).
vypil(3029, default_a10, 41).
vypil(3030, default_a03, 87).
vypil(3031, default_a07, 13).
vypil(3032, default_a10, 46).
vypil(3033, default_a01, 18).
vypil(3034, default_a03, 75).
vypil(3035, default_a10, 3).
vypil(3036, default_a06, 2).
vypil(3037, default_a07, 19).
vypil(3038, default_a10, 60).
vypil(3039, default_a02, 96).
vypil(3040, default_a06, 45).
vypil(3041, default_a07, 23).
vypil(3042, default_a02, 96).
vypil(3043, default_a03, 98).
vypil(3044, default_a06, 89).
vypil(3045, default_a02, 27).
vypil(3046, default_a03, 65).
vypil(3047, default_a07, 31).
vypil(3048, default_a02, 2).
vypil(3049, default_a03, 9).
vypil(3050, default_a06, 59).
vypil(3051, default_a01, 23).
vypil(3052, default_a02, 23).
vypil(3053, default_a10, 10).
vypil(3054, default_a01, 50).
vypil(3055, default_a02, 46).
vypil(3056, default_a12, 50).
vypil(3057, default_a01, 22).
vypil(3058, default_a02, 90).
vypil(3059, default_a03, 53).
vypil(3060, default_a01, 76).
vypil(3061, default_a02, 97).
vypil(3062, default_a12, 39).
vypil(3063, default_a06, 56).
vypil(3064, default_a08, 77).
vypil(3065, default_a12, 91).
vypil(3066, default_a01, 10).
vypil(3067, default_a06, 73).
vypil(3068, default_a08, 58).
vypil(3069, default_a03, 96).
vypil(3070, default_a08, 52).
vypil(3071, default_a12, 7).
vypil(3072, default_a01, 95).
vypil(3073, default_a06, 10).
vypil(3074, default_a08, 96).
vypil(3075, default_a06, 73).
vypil(3076, default_a08, 47).
vypil(3077, default_a12, 57).
vypil(3078, default_a01, 68).
vypil(3079, default_a02, 27).
vypil(3080, default_a03, 52).
vypil(3081, default_a02, 52).
vypil(3082, default_a03, 64).
vypil(3083, default_a12, 38).
vypil(3084, default_a01, 58).
vypil(3085, default_a06, 83).
vypil(3086, default_a08, 88).
vypil(3087, default_a01, 17).
vypil(3088, default_a02, 10).
vypil(3089, default_a12, 79).
vypil(3090, default_a03, 52).
vypil(3091, default_a08, 74).
vypil(3092, default_a12, 78).
vypil(3093, default_a01, 32).
vypil(3094, default_a08, 8).
vypil(3095, default_a12, 89).
vypil(3096, default_a01, 58).
vypil(3097, default_a03, 29).
vypil(3098, default_a12, 87).
vypil(3099, default_a01, 82).
vypil(3100, default_a03, 30).
vypil(3101, default_a08, 78).
vypil(3102, default_a03, 37).
vypil(3103, default_a10, 14).
vypil(3104, default_a11, 14).
vypil(3105, default_a03, 20).
vypil(3106, default_a10, 82).
vypil(3107, default_a11, 78).
vypil(3108, default_a01, 13).
vypil(3109, default_a03, 7).
vypil(3110, default_a08, 38).
vypil(3111, default_a01, 79).
vypil(3112, default_a03, 52).
vypil(3113, default_a09, 21).
vypil(3114, default_a03, 52).
vypil(3115, default_a08, 20).
vypil(3116, default_a09, 89).
vypil(3117, default_a01, 25).
vypil(3118, default_a08, 53).
vypil(3119, default_a09, 68).
vypil(3120, default_a03, 57).
vypil(3121, default_a08, 25).
vypil(3122, default_a10, 56).
vypil(3123, default_a01, 50).
vypil(3124, default_a08, 28).
vypil(3125, default_a10, 94).
vypil(3126, default_a03, 21).
vypil(3127, default_a09, 83).
vypil(3128, default_a10, 87).
vypil(3129, default_a01, 26).
vypil(3130, default_a10, 76).
vypil(3131, default_a11, 97).
vypil(3132, default_a01, 26).
vypil(3133, default_a10, 92).
vypil(3134, default_a11, 45).
vypil(3135, default_a08, 71).
vypil(3136, default_a09, 75).
vypil(3137, default_a11, 33).
vypil(3138, default_a08, 37).
vypil(3139, default_a09, 45).
vypil(3140, default_a10, 39).
vypil(3141, default_a01, 41).
vypil(3142, default_a03, 99).
vypil(3143, default_a10, 11).
vypil(3144, default_a01, 99).
vypil(3145, default_a06, 55).
vypil(3146, default_a11, 87).
vypil(3147, default_a06, 28).
vypil(3148, default_a07, 21).
vypil(3149, default_a11, 32).
vypil(3150, default_a01, 1).
vypil(3151, default_a07, 84).
vypil(3152, default_a11, 22).
vypil(3153, default_a04, 4).
vypil(3154, default_a07, 13).
vypil(3155, default_a09, 46).
vypil(3156, default_a04, 25).
vypil(3157, default_a06, 18).
vypil(3158, default_a09, 88).
vypil(3159, default_a06, 62).
vypil(3160, default_a09, 9).
vypil(3161, default_a11, 70).
vypil(3162, default_a01, 79).
vypil(3163, default_a09, 73).
vypil(3164, default_a11, 8).
vypil(3165, default_a04, 83).
vypil(3166, default_a07, 35).
vypil(3167, default_a11, 34).
vypil(3168, default_a04, 18).
vypil(3169, default_a06, 80).
vypil(3170, default_a11, 92).
vypil(3171, default_a01, 73).
vypil(3172, default_a06, 51).
vypil(3173, default_a07, 83).
vypil(3174, default_a04, 17).
vypil(3175, default_a06, 12).
vypil(3176, default_a07, 89).
vypil(3177, default_a01, 65).
vypil(3178, default_a06, 39).
vypil(3179, default_a09, 51).
vypil(3180, default_a01, 27).
vypil(3181, default_a04, 44).
vypil(3182, default_a06, 19).
vypil(3183, default_a04, 11).
vypil(3184, default_a06, 72).
vypil(3185, default_a09, 20).
vypil(3186, default_a04, 36).
vypil(3187, default_a06, 81).
vypil(3188, default_a11, 21).
vypil(3189, default_a03, 58).
vypil(3190, default_a06, 69).
vypil(3191, default_a10, 22).
vypil(3192, default_a06, 18).
vypil(3193, default_a07, 97).
vypil(3194, default_a11, 42).
vypil(3195, default_a04, 45).
vypil(3196, default_a06, 66).
vypil(3197, default_a07, 40).
vypil(3198, default_a04, 77).
vypil(3199, default_a06, 1).
vypil(3200, default_a11, 27).
vypil(3201, default_a04, 77).
vypil(3202, default_a10, 65).
vypil(3203, default_a11, 16).
vypil(3204, default_a04, 94).
vypil(3205, default_a07, 36).
vypil(3206, default_a10, 95).
vypil(3207, default_a06, 77).
vypil(3208, default_a07, 41).
vypil(3209, default_a11, 21).
vypil(3210, default_a04, 11).
vypil(3211, default_a06, 23).
vypil(3212, default_a10, 98).
vypil(3213, default_a04, 62).
vypil(3214, default_a10, 48).
vypil(3215, default_a11, 76).
vypil(3216, default_a03, 84).
vypil(3217, default_a04, 58).
vypil(3218, default_a10, 69).
vypil(3219, default_a03, 69).
vypil(3220, default_a04, 32).
vypil(3221, default_a10, 54).
vypil(3222, default_a04, 27).
vypil(3223, default_a10, 69).
vypil(3224, default_a11, 97).
vypil(3225, default_a03, 91).
vypil(3226, default_a04, 56).
vypil(3227, default_a06, 97).
vypil(3228, default_a06, 83).
vypil(3229, default_a07, 94).
vypil(3230, default_a10, 25).
vypil(3231, default_a03, 65).
vypil(3232, default_a06, 1).
vypil(3233, default_a10, 83).
vypil(3234, default_a08, 95).
vypil(3235, default_a10, 17).
vypil(3236, default_a12, 17).
vypil(3237, default_a04, 73).
vypil(3238, default_a08, 21).
vypil(3239, default_a10, 31).
vypil(3240, default_a08, 65).
vypil(3241, default_a09, 9).
vypil(3242, default_a12, 34).
vypil(3243, default_a08, 39).
vypil(3244, default_a10, 1).
vypil(3245, default_a12, 80).
vypil(3246, default_a02, 47).
vypil(3247, default_a04, 82).
vypil(3248, default_a12, 73).
vypil(3249, default_a02, 28).
vypil(3250, default_a08, 83).
vypil(3251, default_a09, 95).
vypil(3252, default_a04, 57).
vypil(3253, default_a08, 23).
vypil(3254, default_a09, 59).
vypil(3255, default_a08, 8).
vypil(3256, default_a09, 54).
vypil(3257, default_a10, 23).
vypil(3258, default_a02, 48).
vypil(3259, default_a08, 85).
vypil(3260, default_a12, 36).
vypil(3261, default_a04, 4).
vypil(3262, default_a08, 39).
vypil(3263, default_a12, 61).
vypil(3264, default_a04, 72).
vypil(3265, default_a08, 81).
vypil(3266, default_a12, 14).
vypil(3267, default_a02, 89).
vypil(3268, default_a08, 43).
vypil(3269, default_a12, 92).
vypil(3270, default_a04, 12).
vypil(3271, default_a09, 50).
vypil(3272, default_a12, 11).
vypil(3273, default_a04, 83).
vypil(3274, default_a08, 45).
vypil(3275, default_a12, 39).
vypil(3276, default_a02, 74).
vypil(3277, default_a04, 73).
vypil(3278, default_a12, 85).
vypil(3279, default_a09, 72).
vypil(3280, default_a10, 34).
vypil(3281, default_a11, 75).
vypil(3282, default_a01, 41).
vypil(3283, default_a08, 31).
vypil(3284, default_a11, 69).
vypil(3285, default_a08, 53).
vypil(3286, default_a09, 16).
vypil(3287, default_a11, 58).
vypil(3288, default_a02, 26).
vypil(3289, default_a08, 68).
vypil(3290, default_a09, 28).
vypil(3291, default_a08, 11).
vypil(3292, default_a09, 58).
vypil(3293, default_a10, 34).
vypil(3294, default_a01, 78).
vypil(3295, default_a08, 68).
vypil(3296, default_a11, 9).
vypil(3297, default_a01, 71).
vypil(3298, default_a10, 79).
vypil(3299, default_a11, 79).
vypil(3300, default_a01, 52).
vypil(3301, default_a09, 91).
vypil(3302, default_a10, 11).
vypil(3303, default_a02, 2).
vypil(3304, default_a10, 90).
vypil(3305, default_a11, 2).
vypil(3306, default_a02, 73).
vypil(3307, default_a08, 32).
vypil(3308, default_a10, 21).
vypil(3309, default_a09, 44).
vypil(3310, default_a10, 17).
vypil(3311, default_a11, 37).
vypil(3312, default_a01, 78).
vypil(3313, default_a09, 68).
vypil(3314, default_a10, 28).
vypil(3315, default_a02, 21).
vypil(3316, default_a09, 9).
vypil(3317, default_a10, 19).
vypil(3318, default_a02, 65).
vypil(3319, default_a09, 14).
vypil(3320, default_a10, 71).
vypil(3321, default_a01, 50).
vypil(3322, default_a09, 83).
vypil(3323, default_a11, 94).
vypil(3324, default_a01, 46).
vypil(3325, default_a06, 92).
vypil(3326, default_a11, 37).
vypil(3327, default_a04, 74).
vypil(3328, default_a06, 28).
vypil(3329, default_a11, 84).
vypil(3330, default_a04, 42).
vypil(3331, default_a05, 95).
vypil(3332, default_a07, 65).
vypil(3333, default_a04, 87).
vypil(3334, default_a06, 86).
vypil(3335, default_a07, 55).
vypil(3336, default_a01, 55).
vypil(3337, default_a05, 55).
vypil(3338, default_a06, 85).
vypil(3339, default_a05, 46).
vypil(3340, default_a06, 3).
vypil(3341, default_a07, 56).
vypil(3342, default_a04, 74).
vypil(3343, default_a05, 71).
vypil(3344, default_a06, 4).
vypil(3345, default_a01, 4).
vypil(3346, default_a06, 34).
vypil(3347, default_a11, 1).
vypil(3348, default_a01, 7).
vypil(3349, default_a06, 30).
vypil(3350, default_a11, 32).
vypil(3351, default_a01, 80).
vypil(3352, default_a04, 39).
vypil(3353, default_a07, 58).
vypil(3354, default_a01, 61).
vypil(3355, default_a06, 66).
vypil(3356, default_a11, 79).
vypil(3357, default_a04, 41).
vypil(3358, default_a06, 43).
vypil(3359, default_a07, 93).
vypil(3360, default_a01, 64).
vypil(3361, default_a05, 8).
vypil(3362, default_a11, 93).
vypil(3363, default_a05, 29).
vypil(3364, default_a07, 8).
vypil(3365, default_a11, 10).
vypil(3366, default_a01, 85).
vypil(3367, default_a04, 94).
vypil(3368, default_a06, 63).
vypil(3369, default_a07, 61).
vypil(3370, default_a11, 1).
vypil(3371, default_a12, 39).
vypil(3372, default_a05, 27).
vypil(3373, default_a11, 68).
vypil(3374, default_a12, 99).
vypil(3375, default_a05, 31).
vypil(3376, default_a08, 24).
vypil(3377, default_a12, 70).
vypil(3378, default_a02, 36).
vypil(3379, default_a05, 97).
vypil(3380, default_a07, 82).
vypil(3381, default_a05, 8).
vypil(3382, default_a07, 85).
vypil(3383, default_a12, 8).
vypil(3384, default_a02, 99).
vypil(3385, default_a05, 49).
vypil(3386, default_a07, 15).
vypil(3387, default_a02, 77).
vypil(3388, default_a11, 10).
vypil(3389, default_a12, 62).
vypil(3390, default_a08, 47).
vypil(3391, default_a11, 90).
vypil(3392, default_a12, 69).
vypil(3393, default_a05, 6).
vypil(3394, default_a07, 17).
vypil(3395, default_a12, 77).
vypil(3396, default_a05, 17).
vypil(3397, default_a07, 81).
vypil(3398, default_a11, 59).
vypil(3399, default_a02, 28).
vypil(3400, default_a05, 75).
vypil(3401, default_a07, 81).
vypil(3402, default_a05, 61).
vypil(3403, default_a11, 35).
vypil(3404, default_a12, 48).
vypil(3405, default_a05, 99).
vypil(3406, default_a08, 33).
vypil(3407, default_a12, 4).
vypil(3408, default_a02, 58).
vypil(3409, default_a05, 89).
vypil(3410, default_a12, 64).
vypil(3411, default_a05, 63).
vypil(3412, default_a11, 25).
vypil(3413, default_a12, 68).
vypil(3414, default_a05, 96).
vypil(3415, default_a08, 42).
vypil(3416, default_a12, 19).
vypil(3417, default_a01, 16).
vypil(3418, default_a06, 20).
vypil(3419, default_a07, 74).
vypil(3420, default_a01, 25).
vypil(3421, default_a03, 65).
vypil(3422, default_a09, 47).
vypil(3423, default_a01, 75).
vypil(3424, default_a07, 53).
vypil(3425, default_a08, 67).
vypil(3426, default_a06, 19).
vypil(3427, default_a08, 21).
vypil(3428, default_a09, 42).
vypil(3429, default_a01, 87).
vypil(3430, default_a06, 79).
vypil(3431, default_a09, 20).
vypil(3432, default_a01, 53).
vypil(3433, default_a06, 9).
vypil(3434, default_a09, 47).
vypil(3435, default_a03, 37).
vypil(3436, default_a07, 24).
vypil(3437, default_a08, 40).
vypil(3438, default_a01, 6).
vypil(3439, default_a07, 45).
vypil(3440, default_a09, 57).
vypil(3441, default_a01, 79).
vypil(3442, default_a07, 58).
vypil(3443, default_a09, 48).
vypil(3444, default_a01, 69).
vypil(3445, default_a06, 4).
vypil(3446, default_a07, 82).
vypil(3447, default_a01, 8).
vypil(3448, default_a03, 13).
vypil(3449, default_a06, 8).
vypil(3450, default_a01, 28).
vypil(3451, default_a06, 58).
vypil(3452, default_a09, 72).
vypil(3453, default_a06, 28).
vypil(3454, default_a08, 93).
vypil(3455, default_a09, 67).
vypil(3456, default_a01, 7).
vypil(3457, default_a06, 54).
vypil(3458, default_a07, 100).
vypil(3459, default_a03, 8).
vypil(3460, default_a08, 36).
vypil(3461, default_a09, 63).
vypil(3462, default_a01, 23).
vypil(3463, default_a07, 23).
vypil(3464, default_a09, 47).
vypil(3465, default_a02, 30).
vypil(3466, default_a07, 73).
vypil(3467, default_a10, 6).
vypil(3468, default_a01, 18).
vypil(3469, default_a03, 49).
vypil(3470, default_a07, 41).
vypil(3471, default_a06, 54).
vypil(3472, default_a07, 76).
vypil(3473, default_a10, 20).
vypil(3474, default_a02, 86).
vypil(3475, default_a06, 79).
vypil(3476, default_a07, 49).
vypil(3477, default_a01, 21).
vypil(3478, default_a06, 2).
vypil(3479, default_a10, 99).
vypil(3480, default_a01, 23).
vypil(3481, default_a02, 77).
vypil(3482, default_a10, 65).
vypil(3483, default_a02, 1).
vypil(3484, default_a06, 31).
vypil(3485, default_a10, 78).
vypil(3486, default_a01, 94).
vypil(3487, default_a03, 71).
vypil(3488, default_a06, 80).
vypil(3489, default_a02, 44).
vypil(3490, default_a03, 69).
vypil(3491, default_a07, 47).
vypil(3492, default_a02, 34).
vypil(3493, default_a06, 93).
vypil(3494, default_a07, 68).
vypil(3495, default_a03, 19).
vypil(3496, default_a06, 25).
vypil(3497, default_a07, 81).
vypil(3498, default_a01, 14).
vypil(3499, default_a03, 77).
vypil(3500, default_a06, 78).
vypil(3501, default_a02, 78).
vypil(3502, default_a07, 81).
vypil(3503, default_a10, 70).
vypil(3504, default_a02, 48).
vypil(3505, default_a06, 39).
vypil(3506, default_a07, 44).
vypil(3507, default_a01, 56).
vypil(3508, default_a07, 60).
vypil(3509, default_a10, 26).
vypil(3510, default_a01, 88).
vypil(3511, default_a03, 20).
vypil(3512, default_a06, 42).
vypil(3513, default_a02, 13).
vypil(3514, default_a06, 10).
vypil(3515, default_a12, 73).
vypil(3516, default_a02, 24).
vypil(3517, default_a03, 1).
vypil(3518, default_a08, 5).
vypil(3519, default_a02, 3).
vypil(3520, default_a06, 20).
vypil(3521, default_a12, 90).
vypil(3522, default_a02, 69).
vypil(3523, default_a03, 97).
vypil(3524, default_a08, 80).
vypil(3525, default_a01, 23).
vypil(3526, default_a02, 68).
vypil(3527, default_a06, 63).
vypil(3528, default_a01, 48).
vypil(3529, default_a03, 18).
vypil(3530, default_a08, 97).
vypil(3531, default_a01, 97).
vypil(3532, default_a03, 57).
vypil(3533, default_a06, 63).
vypil(3534, default_a01, 72).
vypil(3535, default_a02, 56).
vypil(3536, default_a08, 52).
vypil(3537, default_a01, 61).
vypil(3538, default_a02, 10).
vypil(3539, default_a03, 70).
vypil(3540, default_a02, 1).
vypil(3541, default_a06, 30).
vypil(3542, default_a08, 15).
vypil(3543, default_a01, 86).
vypil(3544, default_a02, 29).
vypil(3545, default_a06, 9).
vypil(3546, default_a01, 9).
vypil(3547, default_a03, 65).
vypil(3548, default_a08, 35).
vypil(3549, default_a02, 73).
vypil(3550, default_a03, 60).
vypil(3551, default_a06, 95).
vypil(3552, default_a01, 93).
vypil(3553, default_a02, 29).
vypil(3554, default_a03, 84).
vypil(3555, default_a02, 17).
vypil(3556, default_a03, 15).
vypil(3557, default_a08, 78).
vypil(3558, default_a02, 91).
vypil(3559, default_a03, 29).
vypil(3560, default_a08, 48).
vypil(3561, default_a03, 50).
vypil(3562, default_a08, 27).
vypil(3563, default_a09, 32).
vypil(3564, default_a03, 24).
vypil(3565, default_a09, 24).
vypil(3566, default_a10, 7).
vypil(3567, default_a03, 57).
vypil(3568, default_a08, 43).
vypil(3569, default_a10, 75).
vypil(3570, default_a01, 93).
vypil(3571, default_a03, 20).
vypil(3572, default_a08, 44).
vypil(3573, default_a01, 45).
vypil(3574, default_a03, 91).
vypil(3575, default_a08, 99).
vypil(3576, default_a08, 83).
vypil(3577, default_a10, 69).
vypil(3578, default_a11, 46).
vypil(3579, default_a03, 90).
vypil(3580, default_a08, 74).
vypil(3581, default_a11, 42).
vypil(3582, default_a01, 64).
vypil(3583, default_a03, 76).
vypil(3584, default_a08, 43).
vypil(3585, default_a01, 55).
vypil(3586, default_a08, 24).
vypil(3587, default_a10, 57).
vypil(3588, default_a01, 35).
vypil(3589, default_a08, 1).
vypil(3590, default_a10, 62).
vypil(3591, default_a03, 24).
vypil(3592, default_a09, 45).
vypil(3593, default_a10, 73).
vypil(3594, default_a01, 15).
vypil(3595, default_a08, 85).
vypil(3596, default_a11, 20).
vypil(3597, default_a08, 81).
vypil(3598, default_a09, 46).
vypil(3599, default_a11, 59).
vypil(3600, default_a03, 11).
vypil(3601, default_a08, 58).
vypil(3602, default_a10, 39).
vypil(3603, default_a08, 71).
vypil(3604, default_a09, 91).
vypil(3605, default_a10, 78).
vypil(3606, default_a03, 39).
vypil(3607, default_a10, 24).
vypil(3608, default_a11, 25).
vypil(3609, default_a01, 66).
vypil(3610, default_a07, 83).
vypil(3611, default_a11, 24).
vypil(3612, default_a06, 34).
vypil(3613, default_a09, 81).
vypil(3614, default_a11, 59).
vypil(3615, default_a01, 95).
vypil(3616, default_a06, 62).
vypil(3617, default_a07, 34).
vypil(3618, default_a04, 90).
vypil(3619, default_a09, 12).
vypil(3620, default_a11, 93).
vypil(3621, default_a01, 43).
vypil(3622, default_a06, 27).
vypil(3623, default_a07, 81).
vypil(3624, default_a06, 47).
vypil(3625, default_a09, 3).
vypil(3626, default_a11, 24).
vypil(3627, default_a04, 92).
vypil(3628, default_a06, 79).
vypil(3629, default_a07, 40).
vypil(3630, default_a01, 59).
vypil(3631, default_a04, 74).
vypil(3632, default_a06, 31).
vypil(3633, default_a01, 37).
vypil(3634, default_a09, 16).
vypil(3635, default_a11, 42).
vypil(3636, default_a01, 100).
vypil(3637, default_a09, 67).
vypil(3638, default_a11, 39).
vypil(3639, default_a01, 95).
vypil(3640, default_a07, 12).
vypil(3641, default_a09, 87).
vypil(3642, default_a04, 38).
vypil(3643, default_a06, 62).
vypil(3644, default_a09, 35).
vypil(3645, default_a01, 37).
vypil(3646, default_a07, 35).
vypil(3647, default_a11, 21).
vypil(3648, default_a01, 18).
vypil(3649, default_a04, 15).
vypil(3650, default_a06, 88).
vypil(3651, default_a01, 28).
vypil(3652, default_a07, 49).
vypil(3653, default_a11, 99).
vypil(3654, default_a01, 57).
vypil(3655, default_a07, 42).
vypil(3656, default_a09, 91).
vypil(3657, default_a03, 29).
vypil(3658, default_a06, 66).
vypil(3659, default_a11, 97).
vypil(3660, default_a03, 55).
vypil(3661, default_a06, 64).
vypil(3662, default_a07, 64).
vypil(3663, default_a03, 58).
vypil(3664, default_a07, 100).
vypil(3665, default_a10, 73).
vypil(3666, default_a03, 100).
vypil(3667, default_a04, 89).
vypil(3668, default_a10, 8).
vypil(3669, default_a03, 50).
vypil(3670, default_a06, 64).
vypil(3671, default_a11, 45).
vypil(3672, default_a04, 32).
vypil(3673, default_a10, 28).
vypil(3674, default_a11, 67).
vypil(3675, default_a03, 48).
vypil(3676, default_a10, 89).
vypil(3677, default_a11, 40).
vypil(3678, default_a04, 6).
vypil(3679, default_a07, 62).
vypil(3680, default_a10, 62).
vypil(3681, default_a03, 99).
vypil(3682, default_a06, 64).
vypil(3683, default_a10, 94).
vypil(3684, default_a03, 52).
vypil(3685, default_a04, 9).
vypil(3686, default_a10, 42).
vypil(3687, default_a03, 54).
vypil(3688, default_a06, 69).
vypil(3689, default_a11, 28).
vypil(3690, default_a03, 53).
vypil(3691, default_a10, 94).
vypil(3692, default_a11, 72).
vypil(3693, default_a06, 28).
vypil(3694, default_a10, 83).
vypil(3695, default_a11, 10).
vypil(3696, default_a03, 1).
vypil(3697, default_a07, 98).
vypil(3698, default_a11, 35).
vypil(3699, default_a03, 7).
vypil(3700, default_a04, 70).
vypil(3701, default_a11, 45).
vypil(3702, default_a04, 93).
vypil(3703, default_a10, 78).
vypil(3704, default_a11, 12).
vypil(3705, default_a04, 71).
vypil(3706, default_a08, 8).
vypil(3707, default_a10, 97).
vypil(3708, default_a02, 86).
vypil(3709, default_a04, 2).
vypil(3710, default_a12, 19).
vypil(3711, default_a08, 67).
vypil(3712, default_a09, 3).
vypil(3713, default_a12, 19).
vypil(3714, default_a04, 62).
vypil(3715, default_a09, 97).
vypil(3716, default_a10, 69).
vypil(3717, default_a02, 5).
vypil(3718, default_a04, 87).
vypil(3719, default_a09, 77).
vypil(3720, default_a02, 6).
vypil(3721, default_a04, 5).
vypil(3722, default_a09, 53).
vypil(3723, default_a02, 60).
vypil(3724, default_a04, 37).
vypil(3725, default_a09, 80).
vypil(3726, default_a02, 4).
vypil(3727, default_a08, 84).
vypil(3728, default_a12, 40).
vypil(3729, default_a02, 52).
vypil(3730, default_a04, 91).
vypil(3731, default_a09, 57).
vypil(3732, default_a02, 30).
vypil(3733, default_a09, 82).
vypil(3734, default_a12, 79).
vypil(3735, default_a02, 61).
vypil(3736, default_a04, 43).
vypil(3737, default_a09, 13).
vypil(3738, default_a08, 21).
vypil(3739, default_a09, 5).
vypil(3740, default_a12, 88).
vypil(3741, default_a02, 88).
vypil(3742, default_a04, 21).
vypil(3743, default_a12, 81).
vypil(3744, default_a02, 61).
vypil(3745, default_a09, 20).
vypil(3746, default_a12, 88).
vypil(3747, default_a04, 21).
vypil(3748, default_a08, 56).
vypil(3749, default_a10, 76).
vypil(3750, default_a04, 6).
vypil(3751, default_a10, 84).
vypil(3752, default_a12, 51).
vypil(3753, default_a01, 14).
vypil(3754, default_a09, 2).
vypil(3755, default_a11, 19).
vypil(3756, default_a01, 50).
vypil(3757, default_a08, 65).
vypil(3758, default_a09, 100).
vypil(3759, default_a01, 65).
vypil(3760, default_a02, 82).
vypil(3761, default_a08, 73).
vypil(3762, default_a01, 95).
vypil(3763, default_a09, 1).
vypil(3764, default_a10, 26).
vypil(3765, default_a08, 88).
vypil(3766, default_a09, 3).
vypil(3767, default_a11, 56).
vypil(3768, default_a02, 94).
vypil(3769, default_a08, 93).
vypil(3770, default_a10, 14).
vypil(3771, default_a01, 94).
vypil(3772, default_a09, 38).
vypil(3773, default_a11, 23).
vypil(3774, default_a02, 96).
vypil(3775, default_a08, 51).
vypil(3776, default_a09, 93).
vypil(3777, default_a01, 40).
vypil(3778, default_a08, 4).
vypil(3779, default_a11, 77).
vypil(3780, default_a02, 1).
vypil(3781, default_a08, 14).
vypil(3782, default_a11, 40).
vypil(3783, default_a02, 45).
vypil(3784, default_a08, 23).
vypil(3785, default_a09, 72).
vypil(3786, default_a01, 90).
vypil(3787, default_a09, 26).
vypil(3788, default_a11, 54).
vypil(3789, default_a01, 38).
vypil(3790, default_a10, 61).
vypil(3791, default_a11, 42).
vypil(3792, default_a01, 56).
vypil(3793, default_a08, 63).
vypil(3794, default_a10, 9).
vypil(3795, default_a01, 27).
vypil(3796, default_a02, 41).
vypil(3797, default_a09, 71).
vypil(3798, default_a01, 41).
vypil(3799, default_a02, 34).
vypil(3800, default_a11, 36).
vypil(3801, default_a01, 75).
vypil(3802, default_a04, 55).
vypil(3803, default_a07, 60).
vypil(3804, default_a04, 81).
vypil(3805, default_a05, 40).
vypil(3806, default_a11, 52).
vypil(3807, default_a01, 45).
vypil(3808, default_a07, 77).
vypil(3809, default_a11, 45).
vypil(3810, default_a01, 90).
vypil(3811, default_a05, 73).
vypil(3812, default_a11, 48).
vypil(3813, default_a01, 30).
vypil(3814, default_a06, 91).
vypil(3815, default_a07, 32).
vypil(3816, default_a05, 68).
vypil(3817, default_a06, 7).
vypil(3818, default_a07, 68).
vypil(3819, default_a04, 74).
vypil(3820, default_a07, 48).
vypil(3821, default_a11, 66).
vypil(3822, default_a05, 92).
vypil(3823, default_a06, 41).
vypil(3824, default_a07, 56).
vypil(3825, default_a01, 26).
vypil(3826, default_a05, 75).
vypil(3827, default_a06, 77).
vypil(3828, default_a01, 8).
vypil(3829, default_a07, 70).
vypil(3830, default_a11, 92).
vypil(3831, default_a05, 24).
vypil(3832, default_a06, 89).
vypil(3833, default_a11, 11).
vypil(3834, default_a01, 63).
vypil(3835, default_a05, 29).
vypil(3836, default_a11, 66).
vypil(3837, default_a01, 4).
vypil(3838, default_a06, 44).
vypil(3839, default_a11, 55).
vypil(3840, default_a01, 49).
vypil(3841, default_a05, 88).
vypil(3842, default_a06, 27).
vypil(3843, default_a05, 35).
vypil(3844, default_a06, 82).
vypil(3845, default_a11, 54).
vypil(3846, default_a04, 36).
vypil(3847, default_a07, 65).
vypil(3848, default_a11, 77).
vypil(3849, default_a05, 45).
vypil(3850, default_a11, 93).
vypil(3851, default_a12, 28).
vypil(3852, default_a02, 32).
vypil(3853, default_a05, 81).
vypil(3854, default_a12, 75).
vypil(3855, default_a05, 60).
vypil(3856, default_a11, 85).
vypil(3857, default_a12, 30).
vypil(3858, default_a05, 30).
vypil(3859, default_a08, 42).
vypil(3860, default_a12, 9).
vypil(3861, default_a08, 63).
vypil(3862, default_a11, 96).
vypil(3863, default_a12, 41).
vypil(3864, default_a05, 96).
vypil(3865, default_a11, 5).
vypil(3866, default_a12, 8).
vypil(3867, default_a07, 5).
vypil(3868, default_a11, 85).
vypil(3869, default_a12, 19).
vypil(3870, default_a02, 9).
vypil(3871, default_a07, 62).
vypil(3872, default_a11, 22).
vypil(3873, default_a05, 9).
vypil(3874, default_a11, 88).
vypil(3875, default_a12, 91).
vypil(3876, default_a07, 90).
vypil(3877, default_a11, 35).
vypil(3878, default_a12, 70).
vypil(3879, default_a05, 60).
vypil(3880, default_a07, 25).
vypil(3881, default_a12, 93).
vypil(3882, default_a02, 72).
vypil(3883, default_a05, 88).
vypil(3884, default_a08, 66).
vypil(3885, default_a02, 69).
vypil(3886, default_a08, 40).
vypil(3887, default_a12, 82).
vypil(3888, default_a02, 81).
vypil(3889, default_a11, 79).
vypil(3890, default_a12, 95).
vypil(3891, default_a02, 1).
vypil(3892, default_a07, 45).
vypil(3893, default_a08, 65).
vypil(3894, default_a05, 99).
vypil(3895, default_a07, 41).
vypil(3896, default_a08, 60).
vypil(3897, default_a02, 53).
vypil(3898, default_a07, 93).
vypil(3899, default_a08, 70).
vypil(3900, default_a01, 13).
vypil(3901, default_a06, 64).
vypil(3902, default_a09, 64).
vypil(3903, default_a01, 62).
vypil(3904, default_a07, 67).
vypil(3905, default_a09, 76).
vypil(3906, default_a01, 77).
vypil(3907, default_a07, 30).
vypil(3908, default_a09, 84).
vypil(3909, default_a06, 20).
vypil(3910, default_a07, 33).
vypil(3911, default_a08, 82).
vypil(3912, default_a01, 11).
vypil(3913, default_a03, 39).
vypil(3914, default_a08, 24).
vypil(3915, default_a01, 85).
vypil(3916, default_a07, 67).
vypil(3917, default_a09, 35).
vypil(3918, default_a03, 76).
vypil(3919, default_a06, 79).
vypil(3920, default_a09, 12).
vypil(3921, default_a03, 67).
vypil(3922, default_a06, 27).
vypil(3923, default_a07, 90).
vypil(3924, default_a01, 11).
vypil(3925, default_a07, 35).
vypil(3926, default_a08, 29).
vypil(3927, default_a03, 15).
vypil(3928, default_a08, 15).
vypil(3929, default_a09, 69).
vypil(3930, default_a07, 44).
vypil(3931, default_a08, 34).
vypil(3932, default_a09, 26).
vypil(3933, default_a03, 52).
vypil(3934, default_a06, 31).
vypil(3935, default_a08, 29).
vypil(3936, default_a01, 91).
vypil(3937, default_a03, 42).
vypil(3938, default_a08, 38).
vypil(3939, default_a03, 4).
vypil(3940, default_a07, 32).
vypil(3941, default_a09, 17).
vypil(3942, default_a03, 78).
vypil(3943, default_a07, 92).
vypil(3944, default_a08, 91).
vypil(3945, default_a01, 21).
vypil(3946, default_a03, 2).
vypil(3947, default_a08, 5).
vypil(3948, default_a03, 94).
vypil(3949, default_a07, 7).
vypil(3950, default_a08, 90).
vypil(3951, default_a01, 70).
vypil(3952, default_a03, 69).
vypil(3953, default_a06, 14).
vypil(3954, default_a01, 28).
vypil(3955, default_a03, 27).
vypil(3956, default_a07, 78).
vypil(3957, default_a03, 46).
vypil(3958, default_a07, 5).
vypil(3959, default_a10, 64).
vypil(3960, default_a01, 23).
vypil(3961, default_a03, 32).
vypil(3962, default_a06, 14).
vypil(3963, default_a06, 30).
vypil(3964, default_a07, 95).
vypil(3965, default_a10, 44).
vypil(3966, default_a01, 19).
vypil(3967, default_a02, 7).
vypil(3968, default_a03, 45).
vypil(3969, default_a02, 21).
vypil(3970, default_a03, 62).
vypil(3971, default_a07, 64).
vypil(3972, default_a01, 66).
vypil(3973, default_a06, 23).
vypil(3974, default_a10, 73).
vypil(3975, default_a03, 85).
vypil(3976, default_a06, 11).
vypil(3977, default_a10, 10).
vypil(3978, default_a02, 56).
vypil(3979, default_a06, 84).
vypil(3980, default_a07, 98).
vypil(3981, default_a03, 63).
vypil(3982, default_a07, 16).
vypil(3983, default_a10, 82).
vypil(3984, default_a02, 79).
vypil(3985, default_a06, 87).
vypil(3986, default_a07, 14).
vypil(3987, default_a01, 96).
vypil(3988, default_a07, 30).
vypil(3989, default_a10, 76).
vypil(3990, default_a02, 65).
vypil(3991, default_a03, 82).
vypil(3992, default_a06, 53).
vypil(3993, default_a02, 45).
vypil(3994, default_a03, 21).
vypil(3995, default_a07, 92).
vypil(3996, default_a02, 23).
vypil(3997, default_a03, 83).
vypil(3998, default_a06, 9).
vypil(3999, default_a01, 92).
vypil(4000, default_a02, 11).
vypil(4001, default_a07, 5).
vypil(4002, default_a02, 23).
vypil(4003, default_a06, 22).
vypil(4004, default_a12, 81).
vypil(4005, default_a02, 51).
vypil(4006, default_a08, 98).
vypil(4007, default_a12, 69).
vypil(4008, default_a03, 33).
vypil(4009, default_a08, 39).
vypil(4010, default_a12, 78).
vypil(4011, default_a01, 28).
vypil(4012, default_a06, 74).
vypil(4013, default_a12, 10).
vypil(4014, default_a02, 20).
vypil(4015, default_a08, 84).
vypil(4016, default_a12, 53).
vypil(4017, default_a01, 48).
vypil(4018, default_a03, 17).
vypil(4019, default_a06, 40).
vypil(4020, default_a01, 76).
vypil(4021, default_a08, 9).
vypil(4022, default_a12, 38).
vypil(4023, default_a03, 95).
vypil(4024, default_a06, 60).
vypil(4025, default_a08, 59).
vypil(4026, default_a02, 94).
vypil(4027, default_a03, 38).
vypil(4028, default_a12, 52).
vypil(4029, default_a01, 20).
vypil(4030, default_a03, 19).
vypil(4031, default_a06, 44).
vypil(4032, default_a02, 20).
vypil(4033, default_a03, 21).
vypil(4034, default_a12, 63).
vypil(4035, default_a02, 26).
vypil(4036, default_a08, 49).
vypil(4037, default_a12, 51).
vypil(4038, default_a01, 2).
vypil(4039, default_a02, 35).
vypil(4040, default_a12, 4).
vypil(4041, default_a01, 88).
vypil(4042, default_a02, 51).
vypil(4043, default_a12, 93).
vypil(4044, default_a01, 90).
vypil(4045, default_a03, 79).
vypil(4046, default_a06, 75).
vypil(4047, default_a01, 39).
vypil(4048, default_a03, 93).
vypil(4049, default_a08, 15).
vypil(4050, default_a01, 45).
vypil(4051, default_a02, 9).
vypil(4052, default_a08, 94).
vypil(4053, default_a03, 32).
vypil(4054, default_a08, 74).
vypil(4055, default_a11, 82).
vypil(4056, default_a08, 13).
vypil(4057, default_a09, 34).
vypil(4058, default_a11, 98).
vypil(4059, default_a01, 23).
vypil(4060, default_a03, 64).
vypil(4061, default_a10, 32).
vypil(4062, default_a01, 56).
vypil(4063, default_a09, 21).
vypil(4064, default_a10, 59).
vypil(4065, default_a01, 80).
vypil(4066, default_a09, 67).
vypil(4067, default_a11, 84).
vypil(4068, default_a08, 50).
vypil(4069, default_a09, 4).
vypil(4070, default_a10, 5).
vypil(4071, default_a03, 50).
vypil(4072, default_a10, 7).
vypil(4073, default_a11, 60).
vypil(4074, default_a01, 78).
vypil(4075, default_a10, 42).
vypil(4076, default_a11, 64).
vypil(4077, default_a01, 2).
vypil(4078, default_a09, 45).
vypil(4079, default_a10, 63).
vypil(4080, default_a01, 91).
vypil(4081, default_a08, 70).
vypil(4082, default_a09, 8).
vypil(4083, default_a03, 2).
vypil(4084, default_a10, 47).
vypil(4085, default_a11, 52).
vypil(4086, default_a09, 97).
vypil(4087, default_a10, 38).
vypil(4088, default_a11, 38).
vypil(4089, default_a03, 7).
vypil(4090, default_a08, 47).
vypil(4091, default_a10, 17).
vypil(4092, default_a08, 8).
vypil(4093, default_a10, 33).
vypil(4094, default_a11, 20).
vypil(4095, default_a01, 20).
vypil(4096, default_a08, 92).
vypil(4097, default_a11, 13).
vypil(4098, default_a03, 78).
vypil(4099, default_a08, 96).
vypil(4100, default_a10, 60).
vypil(4101, default_a03, 77).
vypil(4102, default_a10, 40).
vypil(4103, default_a11, 26).
vypil(4104, default_a01, 40).
vypil(4105, default_a09, 73).
vypil(4106, default_a11, 26).
vypil(4107, default_a01, 35).
vypil(4108, default_a04, 57).
vypil(4109, default_a06, 95).
vypil(4110, default_a01, 60).
vypil(4111, default_a09, 70).
vypil(4112, default_a11, 52).
vypil(4113, default_a04, 93).
vypil(4114, default_a06, 81).
vypil(4115, default_a09, 33).
vypil(4116, default_a06, 22).
vypil(4117, default_a07, 85).
vypil(4118, default_a09, 60).
vypil(4119, default_a01, 12).
vypil(4120, default_a06, 89).
vypil(4121, default_a07, 72).
vypil(4122, default_a01, 54).
vypil(4123, default_a07, 80).
vypil(4124, default_a09, 76).
vypil(4125, default_a04, 77).
vypil(4126, default_a06, 11).
vypil(4127, default_a11, 89).
vypil(4128, default_a07, 98).
vypil(4129, default_a09, 36).
vypil(4130, default_a11, 21).
vypil(4131, default_a01, 4).
vypil(4132, default_a06, 11).
vypil(4133, default_a09, 96).
vypil(4134, default_a01, 34).
vypil(4135, default_a07, 16).
vypil(4136, default_a09, 81).
vypil(4137, default_a06, 70).
vypil(4138, default_a07, 26).
vypil(4139, default_a09, 30).
vypil(4140, default_a04, 18).
vypil(4141, default_a07, 71).
vypil(4142, default_a11, 27).
vypil(4143, default_a04, 74).
vypil(4144, default_a09, 2).
vypil(4145, default_a11, 95).
vypil(4146, default_a04, 31).
vypil(4147, default_a06, 77).
vypil(4148, default_a07, 23).
vypil(4149, default_a01, 59).
vypil(4150, default_a06, 40).
vypil(4151, default_a09, 39).
vypil(4152, default_a01, 69).
vypil(4153, default_a06, 98).
vypil(4154, default_a07, 99).
vypil(4155, default_a04, 12).
vypil(4156, default_a07, 25).
vypil(4157, default_a11, 18).
vypil(4158, default_a04, 41).
vypil(4159, default_a06, 51).
vypil(4160, default_a07, 78).
vypil(4161, default_a04, 20).
vypil(4162, default_a06, 66).
vypil(4163, default_a11, 34).
vypil(4164, default_a03, 23).
vypil(4165, default_a04, 12).
vypil(4166, default_a07, 43).
vypil(4167, default_a03, 18).
vypil(4168, default_a07, 94).
vypil(4169, default_a11, 77).
vypil(4170, default_a03, 18).
vypil(4171, default_a06, 44).
vypil(4172, default_a07, 33).
vypil(4173, default_a04, 61).
vypil(4174, default_a07, 29).
vypil(4175, default_a11, 12).
vypil(4176, default_a03, 4).
vypil(4177, default_a07, 51).
vypil(4178, default_a11, 24).
vypil(4179, default_a04, 48).
vypil(4180, default_a10, 26).
vypil(4181, default_a11, 84).
vypil(4182, default_a06, 43).
vypil(4183, default_a07, 91).
vypil(4184, default_a11, 4).
vypil(4185, default_a03, 69).
vypil(4186, default_a10, 65).
vypil(4187, default_a11, 30).
vypil(4188, default_a04, 23).
vypil(4189, default_a10, 60).
vypil(4190, default_a11, 4).
vypil(4191, default_a04, 68).
vypil(4192, default_a10, 60).
vypil(4193, default_a11, 36).
vypil(4194, default_a04, 51).
vypil(4195, default_a06, 65).
vypil(4196, default_a10, 43).
vypil(4197, default_a03, 52).
vypil(4198, default_a04, 91).
vypil(4199, default_a11, 97).
vypil(4200, default_a06, 71).
vypil(4201, default_a10, 6).
vypil(4202, default_a11, 58).
vypil(4203, default_a03, 83).
vypil(4204, default_a04, 86).
vypil(4205, default_a10, 48).
vypil(4206, default_a08, 86).
vypil(4207, default_a10, 48).
vypil(4208, default_a12, 67).
vypil(4209, default_a02, 53).
vypil(4210, default_a10, 94).
vypil(4211, default_a12, 42).
vypil(4212, default_a04, 89).
vypil(4213, default_a08, 70).
vypil(4214, default_a09, 13).
vypil(4215, default_a02, 24).
vypil(4216, default_a08, 22).
vypil(4217, default_a12, 88).
vypil(4218, default_a02, 36).
vypil(4219, default_a09, 91).
vypil(4220, default_a10, 87).
vypil(4221, default_a04, 6).
vypil(4222, default_a09, 61).
vypil(4223, default_a12, 69).
vypil(4224, default_a04, 90).
vypil(4225, default_a10, 1).
vypil(4226, default_a12, 42).
vypil(4227, default_a02, 55).
vypil(4228, default_a09, 74).
vypil(4229, default_a10, 88).
vypil(4230, default_a04, 60).
vypil(4231, default_a09, 11).
vypil(4232, default_a12, 55).
vypil(4233, default_a04, 32).
vypil(4234, default_a09, 77).
vypil(4235, default_a12, 24).
vypil(4236, default_a04, 23).
vypil(4237, default_a08, 87).
vypil(4238, default_a10, 82).
vypil(4239, default_a04, 57).
vypil(4240, default_a09, 64).
vypil(4241, default_a10, 5).
vypil(4242, default_a02, 35).
vypil(4243, default_a08, 48).
vypil(4244, default_a12, 49).
vypil(4245, default_a04, 70).
vypil(4246, default_a08, 75).
vypil(4247, default_a12, 57).
vypil(4248, default_a02, 67).
vypil(4249, default_a08, 51).
vypil(4250, default_a12, 33).
vypil(4251, default_a04, 95).
vypil(4252, default_a08, 5).
vypil(4253, default_a12, 77).
vypil(4254, default_a02, 68).
vypil(4255, default_a04, 89).
vypil(4256, default_a08, 32).
vypil(4257, default_a01, 24).
vypil(4258, default_a09, 64).
vypil(4259, default_a11, 23).
vypil(4260, default_a02, 71).
vypil(4261, default_a10, 93).
vypil(4262, default_a11, 27).
vypil(4263, default_a08, 23).
vypil(4264, default_a10, 100).
vypil(4265, default_a11, 65).
vypil(4266, default_a02, 24).
vypil(4267, default_a09, 19).
vypil(4268, default_a10, 41).
vypil(4269, default_a08, 33).
vypil(4270, default_a10, 12).
vypil(4271, default_a11, 78).
vypil(4272, default_a01, 26).
vypil(4273, default_a10, 100).
vypil(4274, default_a11, 25).
vypil(4275, default_a01, 86).
vypil(4276, default_a08, 34).
vypil(4277, default_a09, 31).
vypil(4278, default_a01, 94).
vypil(4279, default_a10, 13).
vypil(4280, default_a11, 12).
vypil(4281, default_a08, 52).
vypil(4282, default_a09, 99).
vypil(4283, default_a10, 99).
vypil(4284, default_a02, 72).
vypil(4285, default_a10, 38).
vypil(4286, default_a11, 15).
vypil(4287, default_a01, 97).
vypil(4288, default_a02, 32).
vypil(4289, default_a08, 64).
vypil(4290, default_a01, 94).
vypil(4291, default_a02, 68).
vypil(4292, default_a09, 43).
vypil(4293, default_a02, 34).
vypil(4294, default_a08, 69).
vypil(4295, default_a11, 68).
vypil(4296, default_a08, 55).
vypil(4297, default_a09, 77).
vypil(4298, default_a10, 12).
vypil(4299, default_a08, 49).
vypil(4300, default_a09, 74).
vypil(4301, default_a11, 11).
vypil(4302, default_a02, 78).
vypil(4303, default_a08, 28).
vypil(4304, default_a10, 85).
vypil(4305, default_a01, 95).
vypil(4306, default_a09, 69).
vypil(4307, default_a11, 88).
vypil(4308, default_a01, 76).
vypil(4309, default_a05, 5).
vypil(4310, default_a11, 83).
vypil(4311, default_a01, 97).
vypil(4312, default_a05, 42).
vypil(4313, default_a06, 28).
vypil(4314, default_a04, 47).
vypil(4315, default_a05, 57).
vypil(4316, default_a11, 7).
vypil(4317, default_a04, 26).
vypil(4318, default_a05, 53).
vypil(4319, default_a06, 54).
vypil(4320, default_a05, 6).
vypil(4321, default_a06, 33).
vypil(4322, default_a07, 67).
vypil(4323, default_a05, 4).
vypil(4324, default_a07, 3).
vypil(4325, default_a11, 78).
vypil(4326, default_a01, 8).
vypil(4327, default_a05, 12).
vypil(4328, default_a06, 51).
vypil(4329, default_a05, 27).
vypil(4330, default_a06, 77).
vypil(4331, default_a11, 70).
vypil(4332, default_a04, 91).
vypil(4333, default_a06, 72).
vypil(4334, default_a07, 28).
vypil(4335, default_a01, 81).
vypil(4336, default_a07, 55).
vypil(4337, default_a11, 45).
vypil(4338, default_a01, 79).
vypil(4339, default_a05, 49).
vypil(4340, default_a11, 61).
vypil(4341, default_a04, 77).
vypil(4342, default_a07, 66).
vypil(4343, default_a11, 29).
vypil(4344, default_a05, 34).
vypil(4345, default_a07, 35).
vypil(4346, default_a11, 80).
vypil(4347, default_a04, 2).
vypil(4348, default_a06, 72).
vypil(4349, default_a11, 77).
vypil(4350, default_a01, 10).
vypil(4351, default_a05, 82).
vypil(4352, default_a06, 28).
vypil(4353, default_a01, 38).
vypil(4354, default_a05, 49).
vypil(4355, default_a11, 96).
vypil(4356, default_a04, 38).
vypil(4357, default_a06, 10).
vypil(4358, default_a11, 78).
vypil(4359, default_a07, 89).
vypil(4360, default_a11, 93).
vypil(4361, default_a12, 93).
vypil(4362, default_a02, 68).
vypil(4363, default_a08, 84).
vypil(4364, default_a11, 70).
vypil(4365, default_a05, 45).
vypil(4366, default_a07, 20).
vypil(4367, default_a12, 16).
vypil(4368, default_a07, 96).
vypil(4369, default_a08, 42).
vypil(4370, default_a11, 87).
vypil(4371, default_a05, 33).
vypil(4372, default_a11, 75).
vypil(4373, default_a12, 45).
vypil(4374, default_a02, 23).
vypil(4375, default_a05, 84).
vypil(4376, default_a07, 55).
vypil(4377, default_a02, 16).
vypil(4378, default_a11, 18).
vypil(4379, default_a12, 12).
vypil(4380, default_a02, 91).
vypil(4381, default_a08, 22).
vypil(4382, default_a11, 8).
vypil(4383, default_a02, 26).
vypil(4384, default_a05, 72).
vypil(4385, default_a07, 90).
vypil(4386, default_a02, 80).
vypil(4387, default_a05, 23).
vypil(4388, default_a08, 44).
vypil(4389, default_a02, 14).
vypil(4390, default_a05, 18).
vypil(4391, default_a12, 57).
vypil(4392, default_a02, 40).
vypil(4393, default_a08, 35).
vypil(4394, default_a11, 84).
vypil(4395, default_a08, 72).
vypil(4396, default_a11, 40).
vypil(4397, default_a12, 72).
vypil(4398, default_a05, 12).
vypil(4399, default_a07, 33).
vypil(4400, default_a12, 79).
vypil(4401, default_a02, 49).
vypil(4402, default_a05, 2).
vypil(4403, default_a08, 44).
vypil(4404, default_a02, 3).
vypil(4405, default_a05, 32).
vypil(4406, default_a08, 3).
vypil(4407, default_a02, 48).
vypil(4408, default_a05, 63).
vypil(4409, default_a12, 76).
vypil(4410, default_a02, 17).
vypil(4411, default_a05, 19).
vypil(4412, default_a08, 48).
vypil(4413, default_a06, 80).
vypil(4414, default_a08, 2).
vypil(4415, default_a09, 50).
vypil(4416, default_a06, 74).
vypil(4417, default_a07, 6).
vypil(4418, default_a09, 52).
vypil(4419, default_a01, 40).
vypil(4420, default_a06, 34).
vypil(4421, default_a07, 71).
vypil(4422, default_a03, 38).
vypil(4423, default_a06, 83).
vypil(4424, default_a07, 46).
vypil(4425, default_a01, 61).
vypil(4426, default_a03, 55).
vypil(4427, default_a07, 41).
vypil(4428, default_a03, 10).
vypil(4429, default_a07, 15).
vypil(4430, default_a08, 99).
vypil(4431, default_a06, 62).
vypil(4432, default_a07, 100).
vypil(4433, default_a09, 63).
vypil(4434, default_a01, 37).
vypil(4435, default_a08, 96).
vypil(4436, default_a09, 60).
vypil(4437, default_a01, 73).
vypil(4438, default_a03, 26).
vypil(4439, default_a08, 65).
vypil(4440, default_a01, 23).
vypil(4441, default_a06, 86).
vypil(4442, default_a07, 20).
vypil(4443, default_a01, 72).
vypil(4444, default_a03, 17).
vypil(4445, default_a07, 7).
vypil(4446, default_a03, 55).
vypil(4447, default_a07, 68).
vypil(4448, default_a08, 46).
vypil(4449, default_a03, 27).
vypil(4450, default_a07, 52).
vypil(4451, default_a09, 22).
vypil(4452, default_a07, 41).
vypil(4453, default_a08, 28).
vypil(4454, default_a09, 100).
vypil(4455, default_a03, 95).
vypil(4456, default_a07, 42).
vypil(4457, default_a08, 10).
vypil(4458, default_a01, 82).
vypil(4459, default_a03, 36).
vypil(4460, default_a08, 82).
vypil(4461, default_a01, 13).
vypil(4462, default_a03, 14).
vypil(4463, default_a06, 70).
vypil(4464, default_a03, 95).
vypil(4465, default_a06, 12).
vypil(4466, default_a07, 63).
vypil(4467, default_a01, 36).
vypil(4468, default_a06, 96).
vypil(4469, default_a07, 96).
vypil(4470, default_a01, 23).
vypil(4471, default_a02, 43).
vypil(4472, default_a06, 52).
vypil(4473, default_a03, 90).
vypil(4474, default_a06, 17).
vypil(4475, default_a07, 55).
vypil(4476, default_a01, 5).
vypil(4477, default_a02, 49).
vypil(4478, default_a03, 12).
vypil(4479, default_a02, 44).
vypil(4480, default_a06, 65).
vypil(4481, default_a10, 55).
vypil(4482, default_a01, 34).
vypil(4483, default_a02, 6).
vypil(4484, default_a06, 5).
vypil(4485, default_a03, 93).
vypil(4486, default_a07, 13).
vypil(4487, default_a10, 52).
vypil(4488, default_a06, 80).
vypil(4489, default_a07, 92).
vypil(4490, default_a10, 20).
vypil(4491, default_a03, 55).
vypil(4492, default_a07, 53).
vypil(4493, default_a10, 75).
vypil(4494, default_a03, 22).
vypil(4495, default_a07, 49).
vypil(4496, default_a10, 86).
vypil(4497, default_a01, 41).
vypil(4498, default_a03, 13).
vypil(4499, default_a07, 88).
vypil(4500, default_a01, 56).
vypil(4501, default_a02, 84).
vypil(4502, default_a10, 42).
vypil(4503, default_a03, 45).
vypil(4504, default_a06, 83).
vypil(4505, default_a10, 28).
vypil(4506, default_a01, 73).
vypil(4507, default_a02, 81).
vypil(4508, default_a03, 57).
vypil(4509, default_a01, 59).
vypil(4510, default_a07, 2).
vypil(4511, default_a10, 38).
vypil(4512, default_a01, 58).
vypil(4513, default_a02, 13).
vypil(4514, default_a10, 90).
vypil(4515, default_a02, 39).
vypil(4516, default_a06, 30).
vypil(4517, default_a10, 31).
vypil(4518, default_a02, 53).
vypil(4519, default_a06, 54).
vypil(4520, default_a10, 9).
vypil(4521, default_a01, 22).
vypil(4522, default_a03, 61).
vypil(4523, default_a12, 39).
vypil(4524, default_a02, 59).
vypil(4525, default_a03, 40).
vypil(4526, default_a06, 70).
vypil(4527, default_a02, 59).
vypil(4528, default_a06, 9).
vypil(4529, default_a08, 90).
vypil(4530, default_a01, 99).
vypil(4531, default_a08, 17).
vypil(4532, default_a12, 1).
vypil(4533, default_a02, 63).
vypil(4534, default_a03, 28).
vypil(4535, default_a08, 7).
vypil(4536, default_a03, 27).
vypil(4537, default_a08, 61).
vypil(4538, default_a12, 97).
vypil(4539, default_a03, 83).
vypil(4540, default_a06, 50).
vypil(4541, default_a12, 39).
vypil(4542, default_a01, 74).
vypil(4543, default_a03, 34).
vypil(4544, default_a06, 19).
vypil(4545, default_a01, 18).
vypil(4546, default_a03, 26).
vypil(4547, default_a06, 55).
vypil(4548, default_a02, 43).
vypil(4549, default_a06, 11).
vypil(4550, default_a08, 65).
vypil(4551, default_a02, 100).
vypil(4552, default_a06, 28).
vypil(4553, default_a08, 37).
vypil(4554, default_a02, 86).
vypil(4555, default_a06, 32).
vypil(4556, default_a12, 76).
vypil(4557, default_a02, 61).
vypil(4558, default_a03, 31).
vypil(4559, default_a06, 27).
vypil(4560, default_a01, 13).
vypil(4561, default_a03, 56).
vypil(4562, default_a06, 50).
vypil(4563, default_a01, 7).
vypil(4564, default_a06, 65).
vypil(4565, default_a08, 81).
vypil(4566, default_a06, 30).
vypil(4567, default_a08, 95).
vypil(4568, default_a12, 3).
vypil(4569, default_a06, 64).
vypil(4570, default_a08, 47).
vypil(4571, default_a12, 29).
vypil(4572, default_a01, 44).
vypil(4573, default_a02, 68).
vypil(4574, default_a06, 88).
vypil(4575, default_a01, 72).
vypil(4576, default_a08, 7).
vypil(4577, default_a11, 1).
vypil(4578, default_a01, 25).
vypil(4579, default_a09, 61).
vypil(4580, default_a11, 7).
vypil(4581, default_a01, 23).
vypil(4582, default_a08, 12).
vypil(4583, default_a10, 13).
vypil(4584, default_a01, 14).
vypil(4585, default_a10, 99).
vypil(4586, default_a11, 97).
vypil(4587, default_a01, 80).
vypil(4588, default_a08, 94).
vypil(4589, default_a09, 90).
vypil(4590, default_a03, 38).
vypil(4591, default_a08, 21).
vypil(4592, default_a09, 87).
vypil(4593, default_a01, 80).
vypil(4594, default_a08, 70).
vypil(4595, default_a11, 100).
vypil(4596, default_a01, 98).
vypil(4597, default_a08, 3).
vypil(4598, default_a11, 68).
vypil(4599, default_a01, 59).
vypil(4600, default_a09, 29).
vypil(4601, default_a11, 29).
vypil(4602, default_a01, 31).
vypil(4603, default_a03, 22).
vypil(4604, default_a11, 54).
vypil(4605, default_a01, 57).
vypil(4606, default_a03, 31).
vypil(4607, default_a10, 28).
vypil(4608, default_a08, 2).
vypil(4609, default_a09, 10).
vypil(4610, default_a11, 72).
vypil(4611, default_a03, 74).
vypil(4612, default_a10, 52).
vypil(4613, default_a11, 18).
vypil(4614, default_a01, 34).
vypil(4615, default_a08, 58).
vypil(4616, default_a10, 90).
vypil(4617, default_a01, 15).
vypil(4618, default_a08, 84).
vypil(4619, default_a10, 55).
vypil(4620, default_a03, 7).
vypil(4621, default_a09, 86).
vypil(4622, default_a10, 6).
vypil(4623, default_a01, 43).
vypil(4624, default_a09, 83).
vypil(4625, default_a11, 82).
vypil(4626, default_a03, 55).
vypil(4627, default_a08, 78).
vypil(4628, default_a11, 40).
vypil(4629, default_a06, 92).
vypil(4630, default_a09, 89).
vypil(4631, default_a11, 80).
vypil(4632, default_a04, 33).
vypil(4633, default_a07, 59).
vypil(4634, default_a09, 52).
vypil(4635, default_a01, 70).
vypil(4636, default_a09, 97).
vypil(4637, default_a11, 84).
vypil(4638, default_a01, 81).
vypil(4639, default_a06, 25).
vypil(4640, default_a09, 45).
vypil(4641, default_a07, 65).
vypil(4642, default_a09, 24).
vypil(4643, default_a11, 45).
vypil(4644, default_a01, 77).
vypil(4645, default_a07, 24).
vypil(4646, default_a09, 58).
vypil(4647, default_a06, 54).
vypil(4648, default_a07, 44).
vypil(4649, default_a11, 55).
vypil(4650, default_a04, 20).
vypil(4651, default_a06, 46).
vypil(4652, default_a07, 19).
vypil(4653, default_a01, 69).
vypil(4654, default_a04, 44).
vypil(4655, default_a09, 33).
vypil(4656, default_a01, 38).
vypil(4657, default_a06, 21).
vypil(4658, default_a11, 46).
vypil(4659, default_a04, 26).
vypil(4660, default_a06, 24).
vypil(4661, default_a07, 84).
vypil(4662, default_a01, 35).
vypil(4663, default_a06, 99).
vypil(4664, default_a07, 62).
vypil(4665, default_a04, 95).
vypil(4666, default_a06, 37).
vypil(4667, default_a11, 96).
vypil(4668, default_a01, 31).
vypil(4669, default_a07, 39).
vypil(4670, default_a11, 92).
vypil(4671, default_a01, 55).
vypil(4672, default_a06, 96).
vypil(4673, default_a07, 18).
vypil(4674, default_a06, 86).
vypil(4675, default_a07, 62).
vypil(4676, default_a09, 18).
vypil(4677, default_a04, 22).
vypil(4678, default_a09, 9).
vypil(4679, default_a11, 2).
vypil(4680, default_a07, 53).
vypil(4681, default_a09, 13).
vypil(4682, default_a11, 74).
vypil(4683, default_a07, 52).
vypil(4684, default_a10, 73).
vypil(4685, default_a11, 30).
vypil(4686, default_a03, 74).
vypil(4687, default_a07, 30).
vypil(4688, default_a10, 11).
vypil(4689, default_a06, 69).
vypil(4690, default_a10, 66).
vypil(4691, default_a11, 41).
vypil(4692, default_a03, 66).
vypil(4693, default_a06, 40).
vypil(4694, default_a07, 11).
vypil(4695, default_a03, 44).
vypil(4696, default_a04, 5).
vypil(4697, default_a10, 30).
vypil(4698, default_a06, 92).
vypil(4699, default_a07, 49).
vypil(4700, default_a10, 38).
vypil(4701, default_a03, 14).
vypil(4702, default_a04, 34).
vypil(4703, default_a06, 56).
vypil(4704, default_a03, 43).
vypil(4705, default_a04, 62).
vypil(4706, default_a10, 53).
vypil(4707, default_a03, 46).
vypil(4708, default_a06, 16).
vypil(4709, default_a10, 67).
vypil(4710, default_a06, 41).
vypil(4711, default_a10, 82).
vypil(4712, default_a11, 22).
vypil(4713, default_a03, 99).
vypil(4714, default_a06, 64).
vypil(4715, default_a10, 48).
vypil(4716, default_a04, 49).
vypil(4717, default_a07, 16).
vypil(4718, default_a11, 26).
vypil(4719, default_a03, 94).
vypil(4720, default_a07, 84).
vypil(4721, default_a10, 40).
vypil(4722, default_a06, 49).
vypil(4723, default_a07, 69).
vypil(4724, default_a11, 15).
vypil(4725, default_a03, 14).
vypil(4726, default_a04, 47).
vypil(4727, default_a10, 20).
vypil(4728, default_a06, 19).
vypil(4729, default_a07, 33).
vypil(4730, default_a10, 22).
vypil(4731, default_a03, 38).
vypil(4732, default_a06, 61).
vypil(4733, default_a07, 70).
vypil(4734, default_a03, 57).
vypil(4735, default_a06, 88).
vypil(4736, default_a07, 43).
vypil(4737, default_a02, 75).
vypil(4738, default_a04, 93).
vypil(4739, default_a12, 44).
vypil(4740, default_a04, 21).
vypil(4741, default_a08, 69).
vypil(4742, default_a12, 55).
vypil(4743, default_a02, 32).
vypil(4744, default_a09, 22).
vypil(4745, default_a12, 78).
vypil(4746, default_a02, 52).
vypil(4747, default_a09, 1).
vypil(4748, default_a10, 83).
vypil(4749, default_a04, 53).
vypil(4750, default_a09, 89).
vypil(4751, default_a10, 12).
vypil(4752, default_a08, 63).
vypil(4753, default_a09, 88).
vypil(4754, default_a10, 60).
vypil(4755, default_a04, 92).
vypil(4756, default_a09, 9).
vypil(4757, default_a10, 32).
vypil(4758, default_a08, 35).
vypil(4759, default_a10, 12).
vypil(4760, default_a12, 6).
vypil(4761, default_a04, 3).
vypil(4762, default_a08, 24).
vypil(4763, default_a10, 33).
vypil(4764, default_a08, 99).
vypil(4765, default_a10, 58).
vypil(4766, default_a12, 74).
vypil(4767, default_a02, 100).
vypil(4768, default_a10, 60).
vypil(4769, default_a12, 64).
vypil(4770, default_a04, 42).
vypil(4771, default_a08, 56).
vypil(4772, default_a10, 79).
vypil(4773, default_a04, 91).
vypil(4774, default_a09, 60).
vypil(4775, default_a10, 14).
vypil(4776, default_a02, 28).
vypil(4777, default_a08, 72).
vypil(4778, default_a12, 14).
vypil(4779, default_a02, 55).
vypil(4780, default_a09, 2).
vypil(4781, default_a10, 25).
vypil(4782, default_a04, 95).
vypil(4783, default_a09, 90).
vypil(4784, default_a12, 6).
vypil(4785, default_a04, 51).
vypil(4786, default_a09, 93).
vypil(4787, default_a12, 54).
vypil(4788, default_a02, 53).
vypil(4789, default_a04, 99).
vypil(4790, default_a08, 58).
vypil(4791, default_a02, 93).
vypil(4792, default_a10, 2).
vypil(4793, default_a11, 31).
vypil(4794, default_a02, 87).
vypil(4795, default_a08, 64).
vypil(4796, default_a10, 63).
vypil(4797, default_a02, 63).
vypil(4798, default_a10, 64).
vypil(4799, default_a11, 93).
vypil(4800, default_a08, 5).
vypil(4801, default_a09, 46).
vypil(4802, default_a10, 6).
vypil(4803, default_a01, 9).
vypil(4804, default_a09, 88).
vypil(4805, default_a11, 72).
vypil(4806, default_a02, 74).
vypil(4807, default_a09, 70).
vypil(4808, default_a10, 9).
vypil(4809, default_a08, 30).
vypil(4810, default_a09, 11).
vypil(4811, default_a10, 37).
vypil(4812, default_a02, 65).
vypil(4813, default_a09, 65).
vypil(4814, default_a10, 14).
vypil(4815, default_a01, 48).
vypil(4816, default_a08, 41).
vypil(4817, default_a10, 2).
vypil(4818, default_a02, 69).
vypil(4819, default_a10, 47).
vypil(4820, default_a11, 94).
vypil(4821, default_a02, 57).
vypil(4822, default_a08, 27).
vypil(4823, default_a09, 20).
vypil(4824, default_a02, 49).
vypil(4825, default_a09, 14).
vypil(4826, default_a10, 38).
vypil(4827, default_a09, 11).
vypil(4828, default_a10, 56).
vypil(4829, default_a11, 10).
vypil(4830, default_a02, 83).
vypil(4831, default_a09, 39).
vypil(4832, default_a10, 87).
vypil(4833, default_a09, 76).
vypil(4834, default_a10, 39).
vypil(4835, default_a11, 42).
vypil(4836, default_a01, 61).
vypil(4837, default_a10, 88).
vypil(4838, default_a11, 74).
vypil(4839, default_a02, 5).
vypil(4840, default_a10, 42).
vypil(4841, default_a11, 49).
vypil(4842, default_a08, 73).
vypil(4843, default_a10, 47).
vypil(4844, default_a11, 47).
vypil(4845, default_a01, 8).
vypil(4846, default_a04, 98).
vypil(4847, default_a06, 45).
vypil(4848, default_a01, 35).
vypil(4849, default_a05, 49).
vypil(4850, default_a06, 67).
vypil(4851, default_a05, 49).
vypil(4852, default_a06, 73).
vypil(4853, default_a07, 78).
vypil(4854, default_a04, 36).
vypil(4855, default_a05, 66).
vypil(4856, default_a07, 12).
vypil(4857, default_a04, 100).
vypil(4858, default_a07, 95).
vypil(4859, default_a11, 45).
vypil(4860, default_a05, 31).
vypil(4861, default_a06, 43).
vypil(4862, default_a07, 79).
vypil(4863, default_a01, 83).
vypil(4864, default_a07, 40).
vypil(4865, default_a11, 10).
vypil(4866, default_a05, 21).
vypil(4867, default_a07, 5).
vypil(4868, default_a11, 79).
vypil(4869, default_a04, 67).
vypil(4870, default_a05, 64).
vypil(4871, default_a06, 26).
vypil(4872, default_a01, 89).
vypil(4873, default_a04, 59).
vypil(4874, default_a11, 50).
vypil(4875, default_a04, 84).
vypil(4876, default_a06, 56).
vypil(4877, default_a07, 7).
vypil(4878, default_a04, 31).
vypil(4879, default_a06, 52).
vypil(4880, default_a07, 80).
vypil(4881, default_a04, 92).
vypil(4882, default_a06, 62).
vypil(4883, default_a11, 94).
vypil(4884, default_a04, 36).
vypil(4885, default_a06, 19).
vypil(4886, default_a07, 19).
vypil(4887, default_a05, 19).
vypil(4888, default_a07, 13).
vypil(4889, default_a11, 4).
vypil(4890, default_a04, 57).
vypil(4891, default_a07, 94).
vypil(4892, default_a11, 9).
vypil(4893, default_a01, 77).
vypil(4894, default_a04, 99).
vypil(4895, default_a11, 91).
vypil(4896, default_a01, 5).
vypil(4897, default_a05, 100).
vypil(4898, default_a06, 81).
vypil(4899, default_a02, 31).
vypil(4900, default_a07, 72).
vypil(4901, default_a08, 83).
vypil(4902, default_a02, 14).
vypil(4903, default_a05, 10).
vypil(4904, default_a11, 55).
vypil(4905, default_a02, 46).
vypil(4906, default_a05, 54).
vypil(4907, default_a11, 79).
vypil(4908, default_a02, 30).
vypil(4909, default_a07, 77).
vypil(4910, default_a11, 87).
vypil(4911, default_a02, 22).
vypil(4912, default_a11, 76).
vypil(4913, default_a12, 97).
vypil(4914, default_a02, 8).
vypil(4915, default_a05, 49).
vypil(4916, default_a11, 25).
vypil(4917, default_a05, 100).
vypil(4918, default_a08, 61).
vypil(4919, default_a11, 33).
vypil(4920, default_a05, 14).
vypil(4921, default_a08, 32).
vypil(4922, default_a12, 36).
vypil(4923, default_a02, 22).
vypil(4924, default_a05, 60).
vypil(4925, default_a07, 88).
vypil(4926, default_a02, 81).
vypil(4927, default_a05, 96).
vypil(4928, default_a08, 13).
vypil(4929, default_a02, 82).
vypil(4930, default_a05, 26).
vypil(4931, default_a12, 25).
vypil(4932, default_a05, 93).
vypil(4933, default_a07, 43).
vypil(4934, default_a12, 64).
vypil(4935, default_a02, 52).
vypil(4936, default_a05, 72).
vypil(4937, default_a12, 92).
vypil(4938, default_a05, 6).
vypil(4939, default_a07, 22).
vypil(4940, default_a08, 19).
vypil(4941, default_a05, 63).
vypil(4942, default_a08, 20).
vypil(4943, default_a12, 49).
vypil(4944, default_a02, 28).
vypil(4945, default_a07, 25).
vypil(4946, default_a08, 13).
vypil(4947, default_a05, 73).
vypil(4948, default_a08, 13).
vypil(4949, default_a11, 32).
vypil(4950, default_a07, 43).
vypil(4951, default_a11, 7).
vypil(4952, default_a12, 100).
vypil(4953, default_a02, 91).
vypil(4954, default_a07, 81).
vypil(4955, default_a08, 43).
vypil(4956, default_a03, 33).
vypil(4957, default_a07, 94).
vypil(4958, default_a08, 64).
vypil(4959, default_a01, 78).
vypil(4960, default_a03, 95).
vypil(4961, default_a08, 33).
vypil(4962, default_a07, 55).
vypil(4963, default_a08, 69).
vypil(4964, default_a09, 37).
vypil(4965, default_a01, 40).
vypil(4966, default_a03, 71).
vypil(4967, default_a09, 52).
vypil(4968, default_a03, 97).
vypil(4969, default_a08, 24).
vypil(4970, default_a09, 93).
vypil(4971, default_a07, 96).
vypil(4972, default_a08, 83).
vypil(4973, default_a09, 93).
vypil(4974, default_a01, 68).
vypil(4975, default_a03, 9).
vypil(4976, default_a09, 28).
vypil(4977, default_a03, 25).
vypil(4978, default_a06, 34).
vypil(4979, default_a08, 31).
vypil(4980, default_a01, 8).
vypil(4981, default_a03, 10).
vypil(4982, default_a09, 44).
vypil(4983, default_a01, 5).
vypil(4984, default_a06, 91).
vypil(4985, default_a07, 93).
vypil(4986, default_a01, 50).
vypil(4987, default_a07, 26).
vypil(4988, default_a08, 33).
vypil(4989, default_a01, 55).
vypil(4990, default_a07, 6).
vypil(4991, default_a09, 83).
vypil(4992, default_a01, 10).
vypil(4993, default_a07, 91).
vypil(4994, default_a08, 50).
vypil(4995, default_a01, 37).
vypil(4996, default_a07, 11).
vypil(4997, default_a09, 74).
vypil(4998, default_a01, 48).
vypil(4999, default_a03, 68).
vypil(5000, default_a08, 26).
vypil(5001, default_a06, 59).
vypil(5002, default_a07, 90).
vypil(5003, default_a09, 30).
vypil(5004, default_a03, 30).
vypil(5005, default_a07, 16).
vypil(5006, default_a09, 63).
vypil(5007, default_a01, 54).
vypil(5008, default_a03, 78).
vypil(5009, default_a06, 56).
vypil(5010, default_a01, 37).
vypil(5011, default_a08, 40).
vypil(5012, default_a09, 96).
vypil(5013, default_a02, 38).
vypil(5014, default_a07, 5).
vypil(5015, default_a10, 81).
vypil(5016, default_a02, 19).
vypil(5017, default_a03, 87).
vypil(5018, default_a06, 5).
vypil(5019, default_a01, 31).
vypil(5020, default_a03, 83).
vypil(5021, default_a07, 92).
vypil(5022, default_a02, 82).
vypil(5023, default_a03, 5).
vypil(5024, default_a06, 97).
vypil(5025, default_a02, 14).
vypil(5026, default_a06, 3).
vypil(5027, default_a07, 49).
vypil(5028, default_a03, 4).
vypil(5029, default_a06, 7).
vypil(5030, default_a07, 58).
vypil(5031, default_a01, 9).
vypil(5032, default_a06, 82).
vypil(5033, default_a10, 71).
vypil(5034, default_a02, 78).
vypil(5035, default_a06, 68).
vypil(5036, default_a10, 13).
vypil(5037, default_a03, 80).
vypil(5038, default_a06, 15).
vypil(5039, default_a10, 83).
vypil(5040, default_a06, 81).
vypil(5041, default_a07, 92).
vypil(5042, default_a10, 37).
vypil(5043, default_a02, 58).
vypil(5044, default_a03, 82).
vypil(5045, default_a10, 96).
vypil(5046, default_a02, 46).
vypil(5047, default_a03, 32).
vypil(5048, default_a10, 90).
vypil(5049, default_a02, 93).
vypil(5050, default_a07, 47).
vypil(5051, default_a10, 69).
vypil(5052, default_a06, 25).
vypil(5053, default_a07, 94).
vypil(5054, default_a10, 25).
vypil(5055, default_a02, 5).
vypil(5056, default_a06, 77).
vypil(5057, default_a10, 3).
vypil(5058, default_a06, 64).
vypil(5059, default_a07, 34).
vypil(5060, default_a10, 10).
vypil(5061, default_a01, 91).
vypil(5062, default_a02, 22).
vypil(5063, default_a06, 8).
vypil(5064, default_a02, 46).
vypil(5065, default_a03, 60).
vypil(5066, default_a10, 51).
vypil(5067, default_a02, 40).
vypil(5068, default_a06, 17).
vypil(5069, default_a07, 12).
vypil(5070, default_a01, 50).
vypil(5071, default_a06, 4).
vypil(5072, default_a08, 73).
vypil(5073, default_a02, 96).
vypil(5074, default_a06, 16).
vypil(5075, default_a12, 59).
vypil(5076, default_a02, 91).
vypil(5077, default_a03, 50).
vypil(5078, default_a12, 65).
vypil(5079, default_a01, 96).
vypil(5080, default_a02, 8).
vypil(5081, default_a12, 69).
vypil(5082, default_a01, 88).
vypil(5083, default_a03, 99).
vypil(5084, default_a08, 90).
vypil(5085, default_a01, 40).
vypil(5086, default_a02, 84).
vypil(5087, default_a08, 96).
vypil(5088, default_a01, 37).
vypil(5089, default_a02, 22).
vypil(5090, default_a08, 84).
vypil(5091, default_a02, 60).
vypil(5092, default_a03, 5).
vypil(5093, default_a08, 29).
vypil(5094, default_a01, 6).
vypil(5095, default_a06, 83).
vypil(5096, default_a12, 93).
vypil(5097, default_a01, 43).
vypil(5098, default_a03, 20).
vypil(5099, default_a08, 28).
vypil(5100, default_a06, 49).
vypil(5101, default_a08, 39).
vypil(5102, default_a12, 88).
vypil(5103, default_a01, 70).
vypil(5104, default_a08, 47).
vypil(5105, default_a12, 48).
vypil(5106, default_a01, 13).
vypil(5107, default_a03, 86).
vypil(5108, default_a12, 71).
vypil(5109, default_a01, 44).
vypil(5110, default_a02, 82).
vypil(5111, default_a08, 86).
vypil(5112, default_a01, 93).
vypil(5113, default_a02, 64).
vypil(5114, default_a06, 14).
vypil(5115, default_a01, 35).
vypil(5116, default_a02, 16).
vypil(5117, default_a12, 47).
vypil(5118, default_a02, 31).
vypil(5119, default_a08, 74).
vypil(5120, default_a12, 50).
vypil(5121, default_a01, 54).
vypil(5122, default_a02, 53).
vypil(5123, default_a03, 48).
vypil(5124, default_a02, 54).
vypil(5125, default_a03, 24).
vypil(5126, default_a12, 62).
vypil(5127, default_a03, 16).
vypil(5128, default_a09, 99).
vypil(5129, default_a10, 19).
vypil(5130, default_a09, 24).
vypil(5131, default_a10, 77).
vypil(5132, default_a11, 99).
vypil(5133, default_a01, 21).
vypil(5134, default_a09, 6).
vypil(5135, default_a11, 72).
vypil(5136, default_a01, 31).
vypil(5137, default_a10, 39).
vypil(5138, default_a11, 6).
vypil(5139, default_a01, 75).
vypil(5140, default_a03, 93).
vypil(5141, default_a11, 14).
vypil(5142, default_a03, 60).
vypil(5143, default_a08, 90).
vypil(5144, default_a09, 61).
vypil(5145, default_a01, 83).
vypil(5146, default_a03, 70).
vypil(5147, default_a08, 76).
vypil(5148, default_a01, 25).
vypil(5149, default_a03, 72).
vypil(5150, default_a11, 51).
vypil(5151, default_a01, 60).
vypil(5152, default_a09, 57).
vypil(5153, default_a10, 62).
vypil(5154, default_a03, 12).
vypil(5155, default_a09, 31).
vypil(5156, default_a11, 31).
vypil(5157, default_a01, 89).
vypil(5158, default_a03, 18).
vypil(5159, default_a08, 4).
vypil(5160, default_a08, 83).
vypil(5161, default_a10, 22).
vypil(5162, default_a11, 84).
vypil(5163, default_a08, 52).
vypil(5164, default_a09, 63).
vypil(5165, default_a10, 97).
vypil(5166, default_a03, 46).
vypil(5167, default_a10, 92).
vypil(5168, default_a11, 57).
vypil(5169, default_a03, 57).
vypil(5170, default_a09, 49).
vypil(5171, default_a11, 1).
vypil(5172, default_a01, 62).
vypil(5173, default_a08, 20).
vypil(5174, default_a11, 28).
vypil(5175, default_a01, 60).
vypil(5176, default_a08, 97).
vypil(5177, default_a10, 72).
vypil(5178, default_a01, 96).
vypil(5179, default_a03, 97).
vypil(5180, default_a10, 61).
vypil(5181, default_a03, 29).
vypil(5182, default_a08, 92).
vypil(5183, default_a11, 39).
vypil(5184, default_a01, 21).
vypil(5185, default_a09, 72).
vypil(5186, default_a11, 75).
vypil(5187, default_a01, 39).
vypil(5188, default_a06, 70).
vypil(5189, default_a11, 58).
vypil(5190, default_a07, 59).
vypil(5191, default_a09, 54).
vypil(5192, default_a11, 18).
vypil(5193, default_a01, 73).
vypil(5194, default_a04, 90).
vypil(5195, default_a09, 71).
vypil(5196, default_a01, 33).
vypil(5197, default_a06, 73).
vypil(5198, default_a07, 78).
vypil(5199, default_a04, 34).
vypil(5200, default_a06, 61).
vypil(5201, default_a11, 47).
vypil(5202, default_a06, 93).
vypil(5203, default_a07, 20).
vypil(5204, default_a11, 88).
vypil(5205, default_a01, 7).
vypil(5206, default_a07, 64).
vypil(5207, default_a09, 80).
vypil(5208, default_a01, 40).
vypil(5209, default_a06, 22).
vypil(5210, default_a07, 51).
vypil(5211, default_a01, 91).
vypil(5212, default_a04, 40).
vypil(5213, default_a11, 71).
vypil(5214, default_a06, 82).
vypil(5215, default_a07, 26).
vypil(5216, default_a09, 20).
vypil(5217, default_a01, 17).
vypil(5218, default_a06, 62).
vypil(5219, default_a07, 13).
vypil(5220, default_a01, 88).
vypil(5221, default_a04, 25).
vypil(5222, default_a11, 98).
vypil(5223, default_a01, 92).
vypil(5224, default_a09, 45).
vypil(5225, default_a11, 40).
vypil(5226, default_a01, 72).
vypil(5227, default_a04, 27).
vypil(5228, default_a09, 100).
vypil(5229, default_a01, 15).
vypil(5230, default_a07, 50).
vypil(5231, default_a11, 70).
vypil(5232, default_a04, 29).
vypil(5233, default_a09, 68).
vypil(5234, default_a11, 93).
vypil(5235, default_a01, 15).
vypil(5236, default_a04, 18).
vypil(5237, default_a06, 37).
vypil(5238, default_a01, 93).
vypil(5239, default_a07, 35).
vypil(5240, default_a09, 51).
vypil(5241, default_a03, 93).
vypil(5242, default_a07, 98).
vypil(5243, default_a11, 71).
vypil(5244, default_a07, 32).
vypil(5245, default_a10, 58).
vypil(5246, default_a11, 7).
vypil(5247, default_a04, 52).
vypil(5248, default_a06, 20).
vypil(5249, default_a10, 58).
vypil(5250, default_a04, 96).
vypil(5251, default_a06, 88).
vypil(5252, default_a11, 51).
vypil(5253, default_a03, 42).
vypil(5254, default_a04, 55).
vypil(5255, default_a07, 83).
vypil(5256, default_a03, 59).
vypil(5257, default_a06, 21).
vypil(5258, default_a07, 25).
vypil(5259, default_a03, 79).
vypil(5260, default_a04, 50).
vypil(5261, default_a10, 33).
vypil(5262, default_a03, 1).
vypil(5263, default_a04, 91).
vypil(5264, default_a10, 1).
vypil(5265, default_a03, 9).
vypil(5266, default_a04, 27).
vypil(5267, default_a11, 46).
vypil(5268, default_a04, 17).
vypil(5269, default_a06, 10).
vypil(5270, default_a11, 51).
vypil(5271, default_a06, 29).
vypil(5272, default_a07, 100).
vypil(5273, default_a10, 96).
vypil(5274, default_a06, 61).
vypil(5275, default_a07, 19).
vypil(5276, default_a10, 61).
vypil(5277, default_a04, 41).
vypil(5278, default_a06, 36).
vypil(5279, default_a10, 74).
vypil(5280, default_a04, 11).
vypil(5281, default_a07, 87).
vypil(5282, default_a10, 29).
vypil(5283, default_a04, 31).
vypil(5284, default_a10, 87).
vypil(5285, default_a11, 87).
vypil(5286, default_a04, 26).
vypil(5287, default_a06, 60).
vypil(5288, default_a07, 55).
vypil(5289, default_a03, 57).
vypil(5290, default_a06, 89).
vypil(5291, default_a10, 96).
vypil(5292, default_a06, 96).
vypil(5293, default_a07, 75).
vypil(5294, default_a11, 4).
vypil(5295, default_a03, 81).
vypil(5296, default_a06, 2).
vypil(5297, default_a11, 55).
vypil(5298, default_a04, 78).
vypil(5299, default_a08, 12).
vypil(5300, default_a09, 93).
vypil(5301, default_a02, 94).
vypil(5302, default_a10, 79).
vypil(5303, default_a12, 56).
vypil(5304, default_a02, 59).
vypil(5305, default_a04, 18).
vypil(5306, default_a10, 87).
vypil(5307, default_a02, 31).
vypil(5308, default_a08, 17).
vypil(5309, default_a09, 45).
vypil(5310, default_a04, 85).
vypil(5311, default_a08, 38).
vypil(5312, default_a09, 1).
vypil(5313, default_a08, 20).
vypil(5314, default_a09, 42).
vypil(5315, default_a10, 2).
vypil(5316, default_a04, 29).
vypil(5317, default_a08, 55).
vypil(5318, default_a10, 17).
vypil(5319, default_a02, 57).
vypil(5320, default_a08, 15).
vypil(5321, default_a09, 84).
vypil(5322, default_a08, 14).
vypil(5323, default_a09, 3).
vypil(5324, default_a12, 94).
vypil(5325, default_a02, 83).
vypil(5326, default_a08, 83).
vypil(5327, default_a09, 48).
vypil(5328, default_a02, 34).
vypil(5329, default_a04, 51).
vypil(5330, default_a12, 7).
vypil(5331, default_a08, 30).
vypil(5332, default_a09, 34).
vypil(5333, default_a10, 72).
vypil(5334, default_a02, 28).
vypil(5335, default_a09, 42).
vypil(5336, default_a10, 11).
vypil(5337, default_a04, 21).
vypil(5338, default_a10, 83).
vypil(5339, default_a12, 82).
vypil(5340, default_a02, 16).
vypil(5341, default_a09, 73).
vypil(5342, default_a10, 35).
vypil(5343, default_a08, 67).
vypil(5344, default_a09, 28).
vypil(5345, default_a10, 57).
vypil(5346, default_a02, 14).
vypil(5347, default_a08, 19).
vypil(5348, default_a12, 59).
vypil(5349, default_a02, 11).
vypil(5350, default_a09, 54).
vypil(5351, default_a10, 99).
vypil(5352, default_a04, 5).
vypil(5353, default_a10, 97).
vypil(5354, default_a12, 61).
vypil(5355, default_a01, 77).
vypil(5356, default_a02, 33).
vypil(5357, default_a10, 48).
vypil(5358, default_a02, 9).
vypil(5359, default_a08, 77).
vypil(5360, default_a11, 30).
vypil(5361, default_a08, 44).
vypil(5362, default_a09, 19).
vypil(5363, default_a10, 87).
vypil(5364, default_a08, 77).
vypil(5365, default_a09, 42).
vypil(5366, default_a11, 16).
vypil(5367, default_a01, 85).
vypil(5368, default_a10, 28).
vypil(5369, default_a11, 28).
vypil(5370, default_a02, 60).
vypil(5371, default_a10, 16).
vypil(5372, default_a11, 7).
vypil(5373, default_a02, 74).
vypil(5374, default_a08, 99).
vypil(5375, default_a11, 94).
vypil(5376, default_a01, 81).
vypil(5377, default_a02, 39).
vypil(5378, default_a11, 52).
vypil(5379, default_a01, 70).
vypil(5380, default_a10, 85).
vypil(5381, default_a11, 39).
vypil(5382, default_a01, 68).
vypil(5383, default_a08, 4).
vypil(5384, default_a10, 90).
vypil(5385, default_a01, 75).
vypil(5386, default_a10, 95).
vypil(5387, default_a11, 13).
vypil(5388, default_a09, 29).
vypil(5389, default_a10, 42).
vypil(5390, default_a11, 77).
vypil(5391, default_a01, 44).
vypil(5392, default_a02, 69).
vypil(5393, default_a09, 9).
vypil(5394, default_a01, 85).
vypil(5395, default_a08, 36).
vypil(5396, default_a11, 3).
vypil(5397, default_a01, 36).
vypil(5398, default_a08, 20).
vypil(5399, default_a10, 7).
vypil(5400, default_a01, 36).
vypil(5401, default_a09, 84).
vypil(5402, default_a11, 87).
vypil(5403, default_a01, 72).
vypil(5404, default_a02, 81).
vypil(5405, default_a08, 58).
vypil(5406, default_a02, 57).
vypil(5407, default_a09, 37).
vypil(5408, default_a11, 87).
vypil(5409, default_a02, 76).
vypil(5410, default_a08, 90).
vypil(5411, default_a11, 52).
vypil(5412, default_a04, 79).
vypil(5413, default_a07, 96).
vypil(5414, default_a11, 50).
vypil(5415, default_a05, 28).
vypil(5416, default_a07, 52).
vypil(5417, default_a11, 89).
vypil(5418, default_a04, 69).
vypil(5419, default_a07, 19).
vypil(5420, default_a11, 1).
vypil(5421, default_a04, 59).
vypil(5422, default_a05, 80).
vypil(5423, default_a11, 45).
vypil(5424, default_a06, 33).
vypil(5425, default_a07, 74).
vypil(5426, default_a11, 12).
vypil(5427, default_a01, 62).
vypil(5428, default_a07, 22).
vypil(5429, default_a11, 4).
vypil(5430, default_a01, 1).
vypil(5431, default_a04, 55).
vypil(5432, default_a05, 96).
vypil(5433, default_a01, 24).
vypil(5434, default_a04, 44).
vypil(5435, default_a06, 43).
vypil(5436, default_a04, 22).
vypil(5437, default_a06, 87).
vypil(5438, default_a07, 39).
vypil(5439, default_a01, 23).
vypil(5440, default_a04, 8).
vypil(5441, default_a05, 73).
vypil(5442, default_a01, 48).
vypil(5443, default_a06, 2).
vypil(5444, default_a07, 22).
vypil(5445, default_a04, 55).
vypil(5446, default_a05, 65).
vypil(5447, default_a11, 90).
vypil(5448, default_a06, 31).
vypil(5449, default_a07, 68).
vypil(5450, default_a11, 98).
vypil(5451, default_a04, 70).
vypil(5452, default_a06, 11).
vypil(5453, default_a11, 41).
vypil(5454, default_a05, 48).
vypil(5455, default_a06, 32).
vypil(5456, default_a11, 90).
vypil(5457, default_a05, 99).
vypil(5458, default_a06, 48).
vypil(5459, default_a11, 51).
vypil(5460, default_a01, 79).
vypil(5461, default_a04, 42).
vypil(5462, default_a07, 60).
vypil(5463, default_a05, 1).
vypil(5464, default_a07, 64).
vypil(5465, default_a11, 48).
vypil(5466, default_a05, 65).
vypil(5467, default_a06, 27).
vypil(5468, default_a07, 56).
vypil(5469, default_a02, 78).
vypil(5470, default_a05, 87).
vypil(5471, default_a08, 72).
vypil(5472, default_a02, 33).
vypil(5473, default_a05, 89).
vypil(5474, default_a07, 98).
vypil(5475, default_a02, 86).
vypil(5476, default_a08, 85).
vypil(5477, default_a12, 45).
vypil(5478, default_a07, 59).
vypil(5479, default_a11, 59).
vypil(5480, default_a12, 37).
vypil(5481, default_a07, 39).
vypil(5482, default_a11, 55).
vypil(5483, default_a12, 69).
vypil(5484, default_a02, 31).
vypil(5485, default_a07, 51).
vypil(5486, default_a08, 28).
vypil(5487, default_a07, 56).
vypil(5488, default_a08, 99).
vypil(5489, default_a11, 69).
vypil(5490, default_a07, 64).
vypil(5491, default_a08, 19).
vypil(5492, default_a11, 3).
vypil(5493, default_a05, 40).
vypil(5494, default_a11, 46).
vypil(5495, default_a12, 78).
vypil(5496, default_a02, 52).
vypil(5497, default_a07, 73).
vypil(5498, default_a11, 86).
vypil(5499, default_a02, 35).
vypil(5500, default_a07, 100).
vypil(5501, default_a11, 60).
vypil(5502, default_a02, 61).
vypil(5503, default_a05, 74).
vypil(5504, default_a07, 19).
vypil(5505, default_a02, 94).
vypil(5506, default_a11, 19).
vypil(5507, default_a12, 74).
vypil(5508, default_a05, 14).
vypil(5509, default_a08, 72).
vypil(5510, default_a11, 87).
vypil(5511, default_a07, 8).
vypil(5512, default_a11, 57).
vypil(5513, default_a12, 54).
vypil(5514, default_a02, 35).
vypil(5515, default_a05, 82).
vypil(5516, default_a07, 6).
vypil(5517, default_a08, 11).
vypil(5518, default_a11, 21).
vypil(5519, default_a12, 17).
vypil(5520, default_a07, 5).
vypil(5521, default_a08, 19).
vypil(5522, default_a12, 53).
vypil(5523, default_a07, 57).
vypil(5524, default_a08, 74).
vypil(5525, default_a12, 73).
vypil(5526, default_a05, 2).
vypil(5527, default_a07, 48).
vypil(5528, default_a12, 66).
vypil(5529, default_a02, 82).
vypil(5530, default_a05, 98).
vypil(5531, default_a07, 38).
vypil(5532, default_a05, 35).
vypil(5533, default_a07, 70).
vypil(5534, default_a11, 60).
vypil(5535, default_a05, 10).
vypil(5536, default_a07, 8).
vypil(5537, default_a08, 66).
vypil(5538, default_a02, 18).
vypil(5539, default_a05, 46).
vypil(5540, default_a08, 82).
vypil(5541, default_a02, 67).
vypil(5542, default_a05, 13).
vypil(5543, default_a07, 45).
vypil(5544, default_a07, 70).
vypil(5545, default_a11, 1).
vypil(5546, default_a12, 85).
vypil(5547, default_a02, 6).
vypil(5548, default_a05, 78).
vypil(5549, default_a07, 4).
vypil(5550, default_a07, 64).
vypil(5551, default_a08, 70).
vypil(5552, default_a12, 7).
vypil(5553, default_a08, 63).
vypil(5554, default_a11, 17).
vypil(5555, default_a12, 41).
vypil(5556, default_a02, 54).
vypil(5557, default_a05, 82).
vypil(5558, default_a08, 16).
vypil(5559, default_a07, 84).
vypil(5560, default_a08, 84).
vypil(5561, default_a11, 66).
vypil(5562, default_a02, 93).
vypil(5563, default_a07, 51).
vypil(5564, default_a08, 81).
vypil(5565, default_a02, 19).
vypil(5566, default_a05, 76).
vypil(5567, default_a07, 6).
vypil(5568, default_a05, 20).
vypil(5569, default_a07, 69).
vypil(5570, default_a08, 18).
vypil(5571, default_a07, 37).
vypil(5572, default_a08, 43).
vypil(5573, default_a11, 80).
vypil(5574, default_a05, 50).
vypil(5575, default_a08, 2).
vypil(5576, default_a12, 47).
vypil(5577, default_a02, 50).
vypil(5578, default_a05, 51).
vypil(5579, default_a11, 59).
vypil(5580, default_a05, 27).
vypil(5581, default_a07, 72).
vypil(5582, default_a11, 71).
vypil(5583, default_a02, 29).
vypil(5584, default_a08, 35).
vypil(5585, default_a12, 93).
vypil(5586, default_a08, 65).
vypil(5587, default_a11, 30).
vypil(5588, default_a12, 79).
vypil(5589, default_a02, 89).
vypil(5590, default_a05, 60).
vypil(5591, default_a08, 56).
vypil(5592, default_a05, 44).
vypil(5593, default_a08, 84).
vypil(5594, default_a11, 44).
vypil(5595, default_a07, 67).
vypil(5596, default_a08, 50).
vypil(5597, default_a12, 15).
vypil(5598, default_a05, 2).
vypil(5599, default_a07, 57).
vypil(5600, default_a08, 51).
vypil(5601, default_a05, 87).
vypil(5602, default_a08, 18).
vypil(5603, default_a12, 37).
vypil(5604, default_a02, 42).
vypil(5605, default_a07, 56).
vypil(5606, default_a11, 84).
vypil(5607, default_a05, 25).
vypil(5608, default_a07, 52).
vypil(5609, default_a11, 55).
vypil(5610, default_a02, 100).
vypil(5611, default_a07, 93).
vypil(5612, default_a08, 12).
vypil(5613, default_a02, 71).
vypil(5614, default_a08, 42).
vypil(5615, default_a11, 70).
vypil(5616, default_a08, 78).
vypil(5617, default_a11, 38).
vypil(5618, default_a12, 75).
vypil(5619, default_a01, 4).
vypil(5620, default_a02, 7).
vypil(5621, default_a03, 7).
vypil(5622, default_a04, 6).
vypil(5623, default_a05, 4).
vypil(5624, default_a06, 5).
vypil(5625, default_a07, 7).
vypil(5626, default_a08, 6).
vypil(5627, default_a09, 2).
vypil(5628, default_a10, 9).
vypil(5629, default_a11, 6).
vypil(5630, default_a12, 3).
vypil(5631, default_a01, 1).
vypil(5632, default_a01, 2).
vypil(5633, default_a01, 2).
vypil(5634, default_a01, 2).
vypil(5635, default_a01, 2).
vypil(5636, default_a01, 3).
vypil(5637, default_a01, 4).
vypil(5638, default_a01, 4).
vypil(5639, default_a01, 4).
vypil(5640, default_a01, 5).
vypil(5641, default_a01, 6).
vypil(5642, default_a01, 6).
vypil(5643, default_a01, 6).
vypil(5644, default_a01, 7).
vypil(5645, default_a01, 7).
vypil(5646, default_a01, 7).
vypil(5647, default_a01, 7).
vypil(5648, default_a01, 7).
vypil(5649, default_a01, 8).
vypil(5650, default_a01, 9).
vypil(5651, default_a01, 10).
vypil(5652, default_a01, 10).
vypil(5653, default_a01, 11).
vypil(5654, default_a01, 11).
vypil(5655, default_a01, 12).
vypil(5656, default_a01, 12).
vypil(5657, default_a01, 13).
vypil(5658, default_a01, 14).
vypil(5659, default_a01, 14).
vypil(5660, default_a01, 14).
vypil(5661, default_a01, 14).
vypil(5662, default_a01, 14).
vypil(5663, default_a01, 14).
vypil(5664, default_a01, 15).
vypil(5665, default_a01, 16).
vypil(5666, default_a01, 17).
vypil(5667, default_a01, 17).
vypil(5668, default_a01, 18).
vypil(5669, default_a01, 18).
vypil(5670, default_a01, 18).
vypil(5671, default_a01, 19).
vypil(5672, default_a01, 19).
vypil(5673, default_a01, 19).
vypil(5674, default_a01, 19).
vypil(5675, default_a01, 19).
vypil(5676, default_a01, 19).
vypil(5677, default_a01, 20).
vypil(5678, default_a01, 20).
vypil(5679, default_a01, 21).
vypil(5680, default_a01, 22).
vypil(5681, default_a01, 23).
vypil(5682, default_a01, 23).
vypil(5683, default_a01, 24).
vypil(5684, default_a01, 25).
vypil(5685, default_a01, 26).
vypil(5686, default_a01, 27).
vypil(5687, default_a01, 27).
vypil(5688, default_a01, 27).
vypil(5689, default_a01, 27).
vypil(5690, default_a01, 28).
vypil(5691, default_a05, 47).
vypil(5692, default_a04, 47).
vypil(5693, default_a03, 47).
vypil(5694, default_a08, 47).
vypil(5695, default_a04, 47).
vypil(5696, default_a02, 195).
vypil(5697, default_a02, 177).
vypil(5698, default_a02, 187).
vypil(5699, default_a02, 110).
vypil(5700, default_a02, 158).
vypil(5701, default_a04, 175).
vypil(5702, default_a04, 113).
vypil(5703, default_a04, 168).
vypil(5704, default_a04, 181).
vypil(5705, default_a07, 193).
vypil(5706, default_a07, 141).
vypil(5707, default_a07, 192).
vypil(5708, default_a07, 162).
vypil(5709, default_a07, 143).
vypil(5710, default_a07, 168).
vypil(5711, default_a10, 199).
vypil(5712, default_a10, 193).
vypil(5713, default_a10, 104).
vypil(5714, default_a10, 109).
vypil(5715, default_a10, 120).
vypil(5716, default_a11, 158).
vypil(5717, default_a11, 158).
vypil(5718, default_a11, 135).
vypil(5719, default_a11, 172).
vypil(5720, default_a11, 194).
vypil(5721, default_a11, 108).
vypil(5722, default_a12, 112).
vypil(5723, default_a12, 117).
vypil(5724, default_a12, 137).
vypil(5725, default_a06, 99).
vypil(5726, default_a06, 144).
vypil(5727, default_a06, 170).
vypil(5728, default_a06, 106).
vypil(5729, default_a06, 117).
vypil(5730, default_a06, 170).
vypil(5731, default_a07, 156).
vypil(5732, default_a07, 145).
vypil(5733, default_a07, 137).
vypil(5734, default_a07, 127).
vypil(5735, default_a07, 105).
vypil(5736, default_a07, 190).
vypil(5737, default_a08, 194).
vypil(5738, default_a08, 132).
vypil(5739, default_a08, 159).
vypil(5740, default_a08, 196).
vypil(5741, default_a08, 112).
vypil(5742, default_a08, 180).
vypil(5743, default_a09, 128).
vypil(5744, default_a09, 137).
vypil(5745, default_a09, 186).
vypil(5746, default_a09, 175).
vypil(5747, default_a09, 197).
vypil(5748, default_a11, 172).
vypil(5749, default_a11, 176).
vypil(5750, default_a11, 171).
vypil(5751, default_a11, 184).
vypil(5752, default_a11, 151).
vypil(5753, default_a11, 138).
vypil(5754, default_a12, 196).
vypil(5755, default_a12, 143).
vypil(5756, default_a12, 189).
